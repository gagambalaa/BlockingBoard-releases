// Blocking Board: the film's episodes and scenes. A pill at the top left names the open scene (EP01 › SC03) with
// previous / next arrows; it opens the navigator: every episode with its scenes (thumbnails), + Scene, + Episode,
// copy a scene, rename (double-click). Alt+← → steps through the scenes in film order, Alt+↑ ↓ jumps episodes.
// Each scene is its own document on the server (scenes/library/<Episode>/<Scene>.json); opening one saves the
// open scene first and takes a thumbnail of its shot.

import { h, icon, toast } from './ui/kit.js';
import { store } from './store.js';
import { shotList } from '/core/doc.js';

export function mountLibrary(hud, { viewport }) {
  let lib = { current: {}, episodes: [] };
  const open = new Set(JSON.parse(localStorage.getItem('bb.openEps') || '[]')); // episodes shown expanded
  const keepOpen = () => localStorage.setItem('bb.openEps', JSON.stringify([...open]));

  // ---------- the pill ----------
  const where = h('span.lib-where');
  const prev = h('button.cc-btn.cc-btn--ghost.lib-step', { type: 'button', title: 'Previous scene (Alt ←)', onClick: () => step(-1) }, icon('chevronLeft'));
  const next = h('button.cc-btn.cc-btn--ghost.lib-step', { type: 'button', title: 'Next scene (Alt →)', onClick: () => step(1) }, icon('chevronRight'));
  const pill = h('div.cc-panel.lib-pill', {}, prev,
    h('button.cc-btn.cc-btn--ghost.lib-name', { type: 'button', title: 'Episodes and scenes', onClick: () => toggle() }, icon('layers'), where), next);
  hud.prepend(pill);

  // ---------- the navigator ----------
  const list = h('div.lib-list');
  const locBox = h('div.lib-loc');
  const nav = h('div.cc-panel.lib-nav', { hidden: true }, locBox,
    h('div.lib-head', {}, h('span.lib-title', {}, 'Film'),
      h('button.cc-btn.cc-btn--ghost.lib-add', { type: 'button', title: 'New episode', onClick: () => newEpisode() }, icon('plus'), 'Episode')),
    list);
  document.body.append(nav);
  function toggle(on = nav.hidden) { nav.hidden = !on; pill.classList.toggle('is-open', on); if (on) { thumb(); render(); loadLocations(); } }

  // ---------- the open scene's location (a set shared by scenes, with states) ----------
  let locs = [];
  async function loadLocations() {
    try { locs = (await fetch('/api/locations').then((r) => r.json())).locations || []; } catch { locs = []; }
    renderLoc();
  }
  function renderLoc() {
    const ref = store.doc?.meta?.location || null, L = ref && locs.find((x) => x.name === ref.name);
    const sel = (value, options, onChange, title) => {
      const el = h('select.cc-select.lib-loc-sel', { title, onChange: () => onChange(el.value) }, options.map(([v, label]) => h('option', { value: v }, label)));
      el.value = value; el.addEventListener('keydown', (e) => e.stopPropagation());
      return el;
    };
    const rows = [h('div.lib-loc-row', {}, h('span.lib-loc-label', {}, 'Location'),
      sel(ref?.name || '', [['', 'None (this scene only)'], ...locs.map((x) => [x.name, `${x.name} · ${x.scenes.length} scene${x.scenes.length === 1 ? '' : 's'}`]), ['+', '+ New from this set…']], async (v) => {
        if (v === '+') {
          const n = await askName('New location from this set (everything but people becomes the shared set)', lib.current.sc || 'Location');
          if (n?.trim()) await post('/api/location/new', { name: n.trim() });
        } else await post('/api/location/use', { name: v || null });
        loadLocations();
      }, 'The set this scene stands in, shared with other scenes'))];
    if (ref?.name) {
      rows.push(h('div.lib-loc-row', {}, h('span.lib-loc-label', {}, 'State'),
        sel(ref.state || '', [['', 'Base'], ...(L?.states || []).map((x) => [x, x]), ['+', '+ New state…']], async (v) => {
          if (v === '+') { const n = await askName(`New state of ${ref.name} (starts as a copy of ${ref.state || 'the base'})`, 'Night'); if (n?.trim()) await post('/api/location/state', { state: n.trim() }); }
          else await post('/api/location/use', { name: ref.name, state: v || null });
          loadLocations();
        }, 'A variant of the location (day, night, wrecked...): only what differs from the base')));
      const edit = ref.edit === 'location';
      rows.push(h('div.lib-loc-row', {}, h('span.lib-loc-label', {}, 'Edit'),
        h('div.lib-loc-seg', {},
          h('button.lib-loc-opt', { type: 'button', class: edit ? '' : 'is-on', title: 'Work on this scene: the location is locked', onClick: () => post('/api/location/edit', { edit: 'scene' }) }, 'Scene'),
          h('button.lib-loc-opt', { type: 'button', class: edit ? 'is-on' : '', title: `Change the location itself (${ref.state ? `its ${ref.state} state` : 'its base'}): every scene using it follows`, onClick: () => post('/api/location/edit', { edit: 'location' }) }, 'Location'))));
      const users = L?.scenes?.length || 0;
      rows.push(h('div.lib-loc-note', {}, edit ? `Editing ${ref.name}${ref.state ? ` · ${ref.state}` : ' (base)'}: ${users} scene${users === 1 ? '' : 's'} follow` : `Shared by ${users} scene${users === 1 ? '' : 's'} · locked here`));
    }
    locBox.replaceChildren(...rows);
  }
  store.on('doc', () => { if (!nav.hidden) renderLoc(); });
  addEventListener('pointerdown', (e) => { if (!nav.hidden && !nav.contains(e.target) && !pill.contains(e.target)) toggle(false); }, true);

  const flat = () => lib.episodes.flatMap((ep) => ep.scenes.map((sc) => ({ ep: ep.name, sc: sc.name })));
  const isCur = (ep, sc) => lib.current.ep === ep && (sc == null || lib.current.sc === sc);

  function render() {
    const { ep, sc } = lib.current;
    where.replaceChildren(ep ? h('span.lib-ep', {}, ep) : '', ep ? h('span.lib-sep', {}, '›') : '', h('span.lib-sc', {}, sc || 'no scene'));
    const all = flat(), i = all.findIndex((x) => x.ep === ep && x.sc === sc);
    prev.disabled = i <= 0; next.disabled = i < 0 || i >= all.length - 1;
    if (nav.hidden) return;
    if (ep) open.add(ep);
    list.replaceChildren(...lib.episodes.map((e) => {
      const shown = open.has(e.name);
      const head = h('div.lib-ep-row', { class: isCur(e.name) ? 'is-current' : '' },
        h('button.lib-ep-btn', { type: 'button', onClick: () => { shown ? open.delete(e.name) : open.add(e.name); keepOpen(); render(); },
          onDblclick: () => rename(e.name) , title: 'Click to show or hide · double-click to rename' },
          icon(shown ? 'chevronDown' : 'chevronRight'), h('span.lib-ep-name', {}, e.name), h('span.lib-count', {}, String(e.scenes.length))),
        h('button.cc-btn.cc-btn--ghost.lib-mini', { type: 'button', title: `New scene in ${e.name}`, onClick: () => newScene(e.name) }, icon('plus')));
      if (!shown) return h('div.lib-ep', {}, head);
      const scenes = e.scenes.map((s) => h('div.lib-sc-row', { class: isCur(e.name, s.name) ? 'is-current' : '' },
        h('button.lib-sc-btn', { type: 'button', title: `${s.name} · ${s.shots} shot${s.shots === 1 ? '' : 's'} · ${s.objects} objects\nDouble-click to rename`,
          onClick: () => go(e.name, s.name), onDblclick: () => rename(e.name, s.name) },
          s.thumb ? h('img.lib-thumb', { src: s.thumb, alt: '' }) : h('span.lib-thumb'),
          h('span.lib-sc-name', {}, s.name), h('span.lib-count', {}, `${s.shots}`)),
        isCur(e.name, s.name) ? null : h('button.cc-btn.cc-btn--ghost.lib-mini', { type: 'button', title: `Merge ${s.name} into the open scene (its set and shots; its camera carries on from this scene's end)`, onClick: () => merge(e.name, s.name) }, icon('film')),
        h('button.cc-btn.cc-btn--ghost.lib-mini', { type: 'button', title: `Copy ${s.name} (same set, new scene)`, onClick: () => copyScene(e.name, s.name) }, icon('copy'))));
      return h('div.lib-ep', {}, head, ...scenes, e.scenes.length ? null : h('div.lib-empty', {}, 'No scenes yet'));
    }));
    if (!lib.episodes.length) list.append(h('div.lib-empty', {}, 'No episodes yet'));
  }

  // a name box of our own (window.prompt is blocked in some app windows): resolves with the text, or null
  function askName(title, value = '') {
    return new Promise((done) => {
      const input = h('input.cc-input.lib-ask-input', { value, spellcheck: false });
      const end = (v) => { box.remove(); removeEventListener('pointerdown', outside, true); done(v); };
      const box = h('div.cc-panel.lib-ask', {}, h('div.lib-ask-title', {}, title), input,
        h('div.lib-ask-row', {}, h('button.cc-btn.cc-btn--ghost', { type: 'button', onClick: () => end(null) }, 'Cancel'),
          h('button.cc-btn.cc-btn--primary', { type: 'button', onClick: () => end(input.value) }, 'OK')));
      const outside = (e) => { if (!box.contains(e.target)) end(null); };
      input.addEventListener('keydown', (e) => { e.stopPropagation(); if (e.key === 'Enter') end(input.value); if (e.key === 'Escape') end(null); });
      document.body.append(box);
      setTimeout(() => { addEventListener('pointerdown', outside, true); input.focus(); input.select(); }, 0);
    });
  }

  // ---------- actions ----------
  const post = (url, body) => store.post(url, body).then((r) => { if (!r.ok) toast(r.error, { kind: 'error' }); return r; });
  // a frame of the open scene's shot camera, kept as its thumbnail
  let lastThumbRev = -1;
  async function thumb() {
    if (!store.doc || !lib.current.sc || lastThumbRev === store.rev) return;
    try {
      await viewport.loaded();
      const c = viewport.renderShot(0, 240, Math.round(240 * store.doc.meta.height / store.doc.meta.width), { view: 'shot', grid: false, timeline: store.doc.timeline });
      const blob = await new Promise((r) => c.toBlob(r, 'image/png'));
      lastThumbRev = store.rev;
      await fetch('/api/library/thumb', { method: 'POST', body: blob });
    } catch (e) { console.warn('thumbnail', e); }
  }
  // ---------- frames for KAI's Blocking Board cards: the main keyframe and every shot's start (and end, when it moves) ----------
  let framesRev = -1;
  async function frames(force = false) {
    if (!store.doc || !lib.current.sc || (!force && framesRev === store.rev)) return 0;
    const rev = store.rev, d = store.doc, A = d.meta.width / d.meta.height;
    await viewport.loaded();
    const send = async (name, tl, t, w) => {
      const c = viewport.renderShot(t, w, Math.round(w / A), { view: 'shot', grid: false, timeline: tl });
      const blob = await new Promise((r) => c.toBlob(r, 'image/png'));
      await fetch(`/api/frames?name=${encodeURIComponent(name)}`, { method: 'POST', body: blob });
    };
    const shots = shotList(d).filter((s) => s.timeline.keys?.length);
    if (!shots.length) return 0;
    let n = 0;
    await send('main', shots[0].timeline, 0, 1280); n++;
    for (const [i, s] of shots.entries()) {
      const tag = `${String(i + 1).padStart(2, '0')}_${s.name.replace(/[^\w.-]+/g, '-')}`;
      await send(`${tag}_start`, s.timeline, 0, 960); n++;
      if (s.timeline.keys.length > 1) { await send(`${tag}_end`, s.timeline, s.timeline.duration, 960); n++; }
    }
    framesRev = rev;
    return n;
  }
  async function go(ep, sc) {
    if (isCur(ep, sc)) return;
    store.set({ playing: false });
    await thumb();
    await frames().catch((e) => console.warn('frames', e));
    await window.canvas.slate?.writePrompts().catch(() => {});
    const r = await post('/api/library/open', { ep, sc });
    if (r.ok) store.set({ selection: null, key: null, time: 0 });
  }
  function step(d) {
    const all = flat(), i = all.findIndex((x) => isCur(x.ep, x.sc)), t = all[i + d];
    if (t) go(t.ep, t.sc);
  }
  function stepEpisode(d) {
    const eps = lib.episodes.filter((e) => e.scenes.length), i = eps.findIndex((e) => e.name === lib.current.ep), t = eps[i + d];
    if (t) go(t.name, t.scenes[0].name);
  }
  // "SC03" -> "SC04", "EP1" -> "EP2"; anything else gets a number
  const nextName = (names, fallback) => {
    const last = [...names].sort((a, b) => a.localeCompare(b, undefined, { numeric: true })).pop();
    const m = last?.match(/^(.*?)(\d+)$/);
    let n = m ? `${m[1]}${String(+m[2] + 1).padStart(m[2].length, '0')}` : fallback;
    while (names.includes(n)) n = n.replace(/(\d+)$/, (d) => String(+d + 1).padStart(d.length, '0'));
    return n;
  };
  async function newScene(ep) {
    const names = lib.episodes.find((e) => e.name === ep)?.scenes.map((s) => s.name) || [];
    const sc = await askName(`New scene in ${ep}`, nextName(names, 'SC01'));
    if (!sc?.trim()) return;
    await thumb();
    const r = await post('/api/library/new', { ep, sc: sc.trim() });
    if (r.ok) { store.set({ selection: null, key: null, time: 0 }); open.add(ep); keepOpen(); }
  }
  async function copyScene(ep, sc) {
    const names = lib.episodes.find((e) => e.name === ep)?.scenes.map((s) => s.name) || [];
    const to = await askName(`Copy ${sc} as (the same set, cameras and shots)`, nextName(names, `${sc} copy`));
    if (!to?.trim()) return;
    await thumb();
    const r = await post('/api/library/new', { ep, sc: to.trim(), copy: { ep, sc } });
    if (r.ok) store.set({ selection: null, key: null, time: 0 });
  }
  // another scene into the open one: its set and shots come in, and its camera carries on from this scene's end
  async function merge(ep, sc) {
    const gap = await askName(`Merge ${sc} into ${lib.current.sc}: seconds for the camera to travel from ${lib.current.sc}'s last key to ${sc}'s first`, '2');
    if (gap == null) return;
    const r = await post('/api/library/merge', { ep, sc, gap: Number(gap) || 0 });
    if (r.ok) toast(`${sc} merged in: its camera starts at ${r.joinedAt} s${Object.keys(r.renamed).length ? ` (renamed: ${Object.entries(r.renamed).map(([a, b]) => `${a} → ${b}`).join(', ')})` : ''}`, { ms: 6000 });
  }
  async function newEpisode() {
    const ep = await askName('New episode', nextName(lib.episodes.map((e) => e.name), 'EP01'));
    if (!ep?.trim()) return;
    const r = await post('/api/library/episode', { ep: ep.trim() });
    if (r.ok) { open.add(r.ep); keepOpen(); newScene(r.ep); }
  }
  async function rename(ep, sc) {
    const to = await askName(sc ? `Rename scene ${sc}` : `Rename episode ${ep}`, sc || ep);
    if (!to?.trim() || to.trim() === (sc || ep)) return;
    const r = await post('/api/library/rename', { ep, sc, to: to.trim() });
    if (r.ok && !sc && open.delete(ep)) { open.add(to.trim()); keepOpen(); }
  }

  // Alt + arrows: scenes and episodes (before the timeline's own arrow keys)
  addEventListener('keydown', (e) => {
    if (!e.altKey || e.ctrlKey || e.metaKey || e.target.closest?.('input, select, textarea')) return;
    const d = { ArrowLeft: [step, -1], ArrowRight: [step, 1], ArrowUp: [stepEpisode, -1], ArrowDown: [stepEpisode, 1] }[e.key];
    if (!d) return;
    e.preventDefault(); e.stopImmediatePropagation();
    d[0](d[1]);
  }, true);

  store.on('library', (l) => { lib = l; render(); });
  // a thumbnail now and then while you work, so the navigator shows the scene as it is; KAI's frames a little less often
  setInterval(() => { if (!store.state.playing && document.visibilityState === 'visible') thumb(); }, 30000);
  setInterval(() => { if (!store.state.playing && document.visibilityState === 'visible') frames().catch(() => {}); }, 120000);
  addEventListener('pagehide', () => { frames().catch(() => {}); });
  // opened from KAI at a scene: #ep=EP01&sc=SC03
  let deep = (() => { const q = new URLSearchParams(location.hash.slice(1)); return q.get('ep') && q.get('sc') ? { ep: q.get('ep'), sc: q.get('sc') } : null; })();
  if (deep) history.replaceState(null, '', location.pathname);
  addEventListener('hashchange', () => {
    const q = new URLSearchParams(location.hash.slice(1));
    if (q.get('ep') && q.get('sc')) { history.replaceState(null, '', location.pathname); go(q.get('ep'), q.get('sc')); }
  });
  store.on('library', () => {
    if (!deep) return;
    const want = deep; deep = null;
    if (lib.episodes.some((e) => e.name === want.ep && e.scenes.some((s) => s.name === want.sc))) go(want.ep, want.sc);
    else toast(`No scene ${want.sc} in ${want.ep}`, { kind: 'error' });
  });
  render();
  return { go, step, stepEpisode, toggle, frames, get library() { return lib; } };
}
