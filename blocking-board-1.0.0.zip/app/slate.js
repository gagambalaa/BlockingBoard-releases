// Blocking Board: the slate, the checks and the prompt writers (brought over from the Blocking Board).
// Slate = what each shot is meant to be (doc.slate: type, seconds, frame, action, acting, camera, light, dialogue; the
// scene's title and location; its 180° line). Checks read the set as it is through each shot's camera (who is in
// frame, blocked, cut off; camera inside something; walks through walls; the slate's shot size; the 180° line, screen
// sides, jump cuts and screen direction between shots). The writers turn the measured blocking into text for the
// models: a keyframe prompt (start and end frame), Flare blocking (a still) and Seedance blocking (motion).

import * as THREE from 'three';
import { h, icon, toast } from './ui/kit.js';
import { store } from './store.js';
import { shotList, objectHeight } from '/core/doc.js';
import { sampleObject, fovToLens } from '/core/curves.js';
import { shotBrief } from '/core/brief.js';

const DEG = Math.PI / 180, R2D = 180 / Math.PI;
const SIZES = ['extreme close-up', 'close-up', 'medium close-up', 'medium shot', 'medium wide', 'full shot', 'wide shot'];
const SIZE_CUT = [0.17, 0.32, 0.52, 0.78, 1.15, 1.9];               // frame height / person height, per size
const BODY_LM = [[0.98, 'top of the head'], [0.93, 'eyes'], [0.89, 'mouth'], [0.86, 'chin'], [0.81, 'shoulders'], [0.72, 'chest'],
  [0.6, 'waist'], [0.5, 'hips'], [0.28, 'knees'], [0.03, 'feet']];
const FIELDS = [['type', 'Type', 'CU, MCU, WIDE, INSERT…'], ['sec', 'Seconds', ''], ['frame', 'Frame', 'What the frame shows (names of people and props here are checked)'],
  ['action', 'Action', ''], ['acting', 'Acting', ''], ['camera', 'Camera', ''], ['light', 'Light', ''], ['dialogue', 'Dialogue', '']];
const wrapA = (a) => ((((a + 180) % 360) + 360) % 360) - 180;
const escRe = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
const nameRe = (n) => new RegExp(`(^|[^\\p{L}\\p{N}])${escRe(n).replace(/[-_\s]+/g, '[\\s_-]+')}($|[^\\p{L}\\p{N}])`, 'iu');
const up1 = (s) => s.charAt(0).toUpperCase() + s.slice(1);

function slateRank(t) {
  t = (t || '').toUpperCase();
  if (/EXTREME|ECU|INSERT|MACRO/.test(t)) return 0;
  if (/MED(IUM)?\s*CLOSE|MCU/.test(t)) return 2;
  if (/CLOSE|\bCU\b/.test(t)) return 1;
  if (/MED(IUM)?\s*WIDE|MWS/.test(t)) return 4;
  if (/MED(IUM)?|\bMS\b|\bMED\b/.test(t)) return 3;
  if (/FULL|\bFS\b/.test(t)) return 5;
  if (/WIDE|\bWS\b|ESTABLISH|LONG/.test(t)) return 6;
  return null;
}

export function mountSlate(hud, { viewport }) {
  let tab = localStorage.getItem('bb.slateTab') || 'checks', cache = null, cacheKey = '';

  // ---------- what the scene holds ----------
  const doc = () => store.doc;
  const isCast = (o) => o.type === 'person' || (o.type === 'card' && o.params.lit !== false && (o.params.h || 0) * (o.scale?.[1] || 1) >= 1);
  const cast = () => doc().objects.filter(isCast);
  const shots = () => shotList(doc());
  const slateOf = (s) => doc().slate?.shots?.[s.id] || {};
  const sceneSlate = () => doc().slate?.scene || {};
  const secOf = (s) => slateOf(s).sec || s.timeline.duration;
  const NAME = (o) => o.name.replace(/[-_]+/g, ' ').toUpperCase();

  // the set as it stands (everything that isn't a person, a lamp or a backdrop), for sight lines and collisions
  function setMeshes() {
    const out = [];
    for (const [id, m] of viewport.meshes) {
      const o = store.object(id);
      if (!o || isCast(o) || o.type === 'light' || (o.type === 'card' && o.params.lit === false)) continue;
      out.push(m.mesh); m.model?.traverse((c) => { if (c.isMesh) out.push(c); });
    }
    return out;
  }
  const idOf = (obj) => { while (obj && !obj.userData?.id) obj = obj.parent; return obj?.userData?.id; };
  const objName = (obj) => store.object(idOf(obj))?.name || 'the set';
  // rays that also see the inside of a surface (to tell when a point is inside something)
  function rayAll(from, dir, far, meshes) {
    const keep = meshes.map((m) => [m, m.material?.side]);
    for (const [m] of keep) if (m.material) m.material.side = THREE.DoubleSide;
    const r = new THREE.Raycaster(from, dir, 0.001, far).intersectObjects(meshes, false);
    for (const [m, side] of keep) if (m.material) m.material.side = side;
    return r;
  }
  function insideOf(p, meshes) {
    let n = 0, name = null;
    for (const d of [[1, 0, 0], [0, 0, 1], [0, 1, 0]]) {
      const dir = new THREE.Vector3(...d), hit = rayAll(p, dir, 30, meshes)[0];
      if (hit && hit.face && hit.face.normal.clone().transformDirection(hit.object.matrixWorld).dot(dir) > 0) { n++; name = objName(hit.object); }
    }
    return n >= 2 ? name : null;
  }

  // a shot's camera at shot time t
  function camAt(tl, t) {
    const cam = new THREE.PerspectiveCamera(40, doc().meta.width / doc().meta.height, 0.05, 2000);
    if (!viewport.poseCamera(cam, t, null, tl)) return null;
    cam.aspect = doc().meta.width / doc().meta.height; cam.updateProjectionMatrix(); cam.updateMatrixWorld(true);
    return cam;
  }
  const tOf = (tl, moment) => (moment === 'end' ? tl.duration : typeof moment === 'number' ? moment * tl.duration : 0);

  // ---------- measuring one shot at one moment ----------
  function analyse(i, moment = 'start') {
    const sh = shots()[i]; if (!sh) return null;
    const tl = sh.timeline, t = tOf(tl, moment), cam = camAt(tl, t);
    if (!cam) return null;
    const fwd = cam.getWorldDirection(new THREE.Vector3()), meshes = setMeshes(), chars = {};
    const proj = (v) => { const e = v.clone().applyMatrix4(cam.matrixWorldInverse), q = v.clone().project(cam); return { x: q.x, y: q.y, front: e.z < 0, in: e.z < 0 && Math.abs(q.x) <= 1 && Math.abs(q.y) <= 1 }; };
    for (const o of cast()) {
      const s = sampleObject(o, tl, t), H = objectHeight(o) * (s.scale?.[1] || 1), P = new THREE.Vector3(...s.position);
      const at = (f) => P.clone().add(new THREE.Vector3(0, H * f, 0));
      const head = at(0.93), chest = at(0.72), ph = proj(head), pc = proj(chest);
      const dist = cam.position.distanceTo(head), depth = chest.clone().sub(cam.position).dot(fwd);
      // the set between the camera and their head
      const hit = new THREE.Raycaster(cam.position, head.clone().sub(cam.position).normalize(), 0.05, Math.max(0.05, dist - 0.2)).intersectObjects(meshes, false)[0];
      const frameH = 2 * Math.tan((cam.fov * DEG) / 2) * Math.max(0.05, depth);
      const r = frameH / Math.max(0.2, H), size = SIZE_CUT.findIndex((c) => r < c);
      // which way they face, seen from the camera (a card that faces the camera always faces it)
      let yaw = s.rotation[1];
      if (o.type === 'card' && o.params.face !== 'fixed') yaw = Math.atan2(cam.position.x - P.x, cam.position.z - P.z) * R2D;
      const f = new THREE.Vector3(Math.sin(yaw * DEG), 0, Math.cos(yaw * DEG)), toCam = cam.position.clone().sub(P).setY(0).normalize();
      const ang = Math.acos(Math.max(-1, Math.min(1, f.dot(toCam)))) * R2D, side = proj(head.clone().add(f)).x - ph.x;
      const lms = BODY_LM.map(([fr, n]) => ({ n, ...proj(at(fr)) }));
      chars[o.id] = { o, name: NAME(o), P, H, head, headIn: ph.in, chestIn: pc.in, behind: !ph.front, sx: ph.x, sy: ph.y, dist, depth,
        occl: hit ? objName(hit.object) : null, size: size < 0 ? 6 : size, ang, gaze: Math.sign(side), lms, pose: o.params.pose || 'stand', yaw };
    }
    return { i, sh, tl, t, cam, fwd, chars, meshes };
  }
  const visible = (a) => a && (a.headIn || a.chestIn);
  const thirdWord = (x) => (x < -0.33 ? 'frame left' : x > 0.33 ? 'frame right' : 'centre frame');
  const depthWord = (d) => (d < 1.6 ? 'close to the camera' : d < 4 ? 'in the middle ground' : 'in the background');
  const facingWord = (a) => (a.ang < 35 ? 'facing the camera' : a.ang < 80 ? `three-quarter to the camera, turned frame ${a.gaze > 0 ? 'right' : 'left'}`
    : a.ang < 110 ? `in profile, facing frame ${a.gaze > 0 ? 'right' : 'left'}` : a.ang < 150 ? 'three-quarter away from the camera' : 'back to the camera');
  const POSE = { stand: 'standing', walk: 'walking', run: 'running', sit: 'sitting', 'sit-floor': 'sitting on the floor', crouch: 'crouching', kneel: 'kneeling', lie: 'lying down', lean: 'leaning', point: 'pointing', wave: 'waving', 'arms-crossed': 'arms crossed', 'hands-on-hips': 'hands on hips', 'reach-up': 'reaching up', phone: 'on the phone' };
  const heightWord = (y) => (y < 0.8 ? 'low, near the floor' : y < 1.3 ? 'at chest height' : y < 1.85 ? 'at eye level' : y < 3 ? 'high' : 'very high, looking down');
  const tiltWord = (p) => (p < -35 ? 'angled steeply down' : p < -10 ? 'tilted down' : p > 10 ? 'tilted up' : 'level');
  const lensOf = (cam) => Math.round(fovToLens(cam.fov));
  const mainOf = (A) => Object.values(A?.chars || {}).filter(visible).sort((x, y) => x.dist - y.dist)[0] || null;
  function lineOf() {
    const names = cast().map((o) => o.id), L = doc().slate?.line;
    if (L && L.every((n) => names.includes(n)) && L[0] !== L[1]) return L;
    return names.length >= 2 ? [names[0], names[1]] : null;
  }
  function sideOf(i) {
    const L = lineOf(), A = analyse(i, 'start'); if (!L || !A) return 0;
    const a = A.chars[L[0]].P, b = A.chars[L[1]].P, c = A.cam.position;
    return Math.sign((b.x - a.x) * (c.z - a.z) - (b.z - a.z) * (c.x - a.x));
  }
  // a person's moves in a shot: their positions at the shot's key moments (action time = shot time + start)
  function walkKeys(o, tl) {
    const st = tl.start || 0, dur = tl.duration, ks = (o.anim || []).map((k) => k.t - st).filter((t) => t > 0 && t < dur);
    return [0, ...ks, dur].map((t) => ({ t, p: sampleObject(o, tl, t).position, yaw: sampleObject(o, tl, t).rotation[1] }));
  }
  const moves = (o, tl) => o.anim?.length && walkKeys(o, tl).some((k, j, a) => j && Math.hypot(k.p[0] - a[j - 1].p[0], k.p[2] - a[j - 1].p[2]) >= 0.25);

  // ---------- checks ----------
  function checks(i) {
    const out = [], list = shots(), sh = list[i], sl = slateOf(sh), C = cast();
    if (!sh.timeline.keys?.length) return [['bad', 'This shot has no camera key yet: press K to key the view.']];
    const named = C.filter((o) => nameRe(o.name.replace(/[-_]+/g, ' ')).test(`${sl.frame || ''}`));
    const hasMove = sh.timeline.keys.length > 1;
    for (const moment of hasMove ? ['start', 'end'] : ['start']) {
      const A = analyse(i, moment), tag = moment === 'end' ? ' at the end' : '';
      for (const o of C) {
        const a = A.chars[o.id];
        if (moment === 'start' && named.includes(o) && !visible(a)) out.push(['bad', `${a.name} is named in the slate frame but is not in frame${tag}.`]);
        else if (visible(a) && a.occl) out.push(['bad', `${a.name} is blocked by ${a.occl}${tag}.`]);
        else if (a.chestIn && !a.headIn && !a.behind) out.push(['bad', `${a.name}'s head is cut off by the frame edge${tag}.`]);
        else if (visible(a)) out.push(['ok', `${a.name}: ${thirdWord(a.sx)}, ${depthWord(a.dist)}, ${facingWord(a)}${tag}.`]);
        if (a.dist < 0.45) out.push(['bad', `The camera is inside or touching ${a.name}${tag}.`]);
      }
      const inside = insideOf(A.cam.position, A.meshes);
      if (inside) out.push(['bad', `The ${moment === 'end' ? 'end ' : ''}camera is inside ${inside}.`]);
      if (moment === 'start') {
        const m = mainOf(A), sr = slateRank(sl.type);
        if (m && sr != null) out.push(Math.abs(m.size - sr) >= 2
          ? ['bad', `Slate says ${sl.type}, but on ${m.name} this frames as a ${SIZES[m.size]}. Move the camera or change the lens.`]
          : ['ok', `Shot size matches the slate (${SIZES[m.size]} on ${m.name}).`]);
      }
    }
    // walks through the set
    const meshes = setMeshes();
    for (const o of C) {
      if (!o.anim?.length) continue;
      const tl = sh.timeline, step = 0.2;
      for (let t = 0; t < tl.duration; t += step) {
        const a = new THREE.Vector3(...sampleObject(o, tl, t).position), b = new THREE.Vector3(...sampleObject(o, tl, Math.min(tl.duration, t + step)).position);
        const d = a.distanceTo(b); if (d < 0.02) continue;
        const hit = [0.3, 1.0].map((y) => rayAll(a.clone().setY(a.y + y), b.clone().sub(a).normalize(), d, meshes)[0]).find(Boolean);
        if (hit) { out.push(['bad', `${NAME(o)}'s walk goes through ${objName(hit.object)} (at ${t.toFixed(1)} s).`]); break; }
      }
    }
    // the 180° line, screen sides, jump cuts, screen direction
    const L = lineOf();
    if (L) {
      const side = sideOf(i), ref = list.findIndex((_, k) => sideOf(k) !== 0);
      if (ref >= 0 && ref !== i && side && side !== sideOf(ref)) out.push(['bad', `The camera is across the 180° line (${NAME(store.object(L[0]))}–${NAME(store.object(L[1]))}) from ${list[ref].name}. Their screen sides flip.`]);
    }
    if (i > 0) {
      const prev = list[i - 1], A0 = analyse(i - 1, 'end'), A1 = analyse(i, 'start');
      if (A0 && A1) {
        if (L) { const ok = (n) => A0.chars[n]?.headIn && A1.chars[n]?.headIn;
          if (ok(L[0]) && ok(L[1]) && Math.sign(A0.chars[L[0]].sx - A0.chars[L[1]].sx) !== Math.sign(A1.chars[L[0]].sx - A1.chars[L[1]].sx))
            out.push(['bad', `${A1.chars[L[0]].name} and ${A1.chars[L[1]].name} swap screen sides from ${prev.name}.`]); }
        const m0 = mainOf(A0), m1 = mainOf(A1);
        if (m0 && m1 && m0.o.id === m1.o.id) {
          const s = m1.head, bear = (c) => Math.atan2(c.x - s.x, c.z - s.z) * R2D, dA = Math.abs(wrapA(bear(A1.cam.position) - bear(A0.cam.position)));
          if (dA < 30 && Math.abs(m0.size - m1.size) < 2) out.push(['bad', `Jump cut risk: ${prev.name} and this shot both frame ${m1.name} as a ${SIZES[m1.size]} from almost the same angle (${dA.toFixed(0)}° apart). Change the angle by 30°+ or the shot size.`]);
        }
        for (const o of C) {
          if (!moves(o, prev.timeline) || !moves(o, sh.timeline)) continue;
          const dir = (k) => { const a = analyse(k, 'start')?.chars[o.id], b = analyse(k, 'end')?.chars[o.id]; if (!visible(a) || !visible(b)) return 0; const d = b.sx - a.sx; return Math.abs(d) < 0.15 ? 0 : Math.sign(d); };
          const d0 = dir(i - 1), d1 = dir(i);
          if (d0 && d1 && d0 !== d1) out.push(['bad', `${NAME(o)} moves frame ${d0 > 0 ? 'right' : 'left'} in ${prev.name} but frame ${d1 > 0 ? 'right' : 'left'} here. Screen direction flips.`]);
        }
      }
    }
    // props named in the slate that aren't in frame
    const A = analyse(i, 'start'), txt = `${sl.frame || ''} ${sl.action || ''}`;
    for (const o of doc().objects) {
      if (isCast(o) || ['wall', 'plane', 'light'].includes(o.type) || !nameRe(o.name.replace(/[-_]+/g, ' ')).test(txt)) continue;
      const m = viewport.meshes.get(o.id); if (!m) continue;
      const c = new THREE.Box3().setFromObject(m.mesh).getCenter(new THREE.Vector3()), e = c.clone().applyMatrix4(A.cam.matrixWorldInverse), q = c.clone().project(A.cam);
      if (e.z >= 0 || Math.abs(q.x) > 1 || Math.abs(q.y) > 1) out.push(['bad', `The slate mentions the ${o.name}, but it is not in frame.`]);
    }
    if (!C.length) out.push(['info', 'No people in this scene yet: add a Person or a character Card.']);
    return out;
  }

  // ---------- words ----------
  function framingWords(a) {
    const vis = a.lms.filter((l) => l.in), top = vis[0], bot = vis[vis.length - 1];
    if (!top) return '';
    if (top.n === 'top of the head' && bot.n === 'feet') return 'head to feet in frame';
    if (top.n === 'top of the head') return `framed from the ${bot.n} up`;
    return `cropped at the ${top.n} by the top of the frame${bot.n !== 'feet' ? `, the frame bottom at the ${bot.n}` : ''}`;
  }
  function inFrameSet(A) { // set pieces and props seen in frame (not walls, floors, lamps)
    const names = [];
    for (const o of doc().objects) {
      if (isCast(o) || ['wall', 'plane', 'light', 'roof'].includes(o.type) || (o.type === 'card' && o.params.lit === false)) continue;
      const m = viewport.meshes.get(o.id); if (!m) continue;
      const c = new THREE.Box3().setFromObject(m.mesh).getCenter(new THREE.Vector3()), e = c.clone().applyMatrix4(A.cam.matrixWorldInverse), q = c.clone().project(A.cam);
      if (e.z < 0 && Math.abs(q.x) <= 1 && Math.abs(q.y) <= 1) names.push(o.name.replace(/[-_]+/g, ' '));
    }
    return names.slice(0, 10);
  }
  function setWords(A) {
    const loc = doc().meta?.location, sc = sceneSlate();
    const place = [sc.location || loc?.name, loc?.state].filter(Boolean).join(', ');
    const seen = inFrameSet(A);
    return `SET: ${place || doc().meta?.sc || 'the set'}${seen.length ? `. In frame: ${seen.join(', ')}` : ''}.`;
  }
  function camWords(A) {
    const pitch = Math.asin(A.fwd.y) * R2D, m = mainOf(A);
    return `${heightWord(A.cam.position.y)}, ${tiltWord(pitch)}, ${lensOf(A.cam)} mm lens${m ? `, a ${SIZES[m.size]} on ${m.name}` : ''}`;
  }
  function moveWords(sh) {
    try {
      const b = shotBrief(doc(), sh.id), segs = (b.segments || []).filter((g) => g.kind !== 'hold');
      return segs.length ? segs.map((g) => `${g.from.toFixed(1)}–${g.to.toFixed(1)} s ${g.text}`).join('; then ') : '';
    } catch { return ''; }
  }
  function personLine(a, withPose = true) {
    const pose = withPose && a.pose !== 'stand' ? `, ${POSE[a.pose] || a.pose}` : '';
    return `${a.name} ${thirdWord(a.sx)}, ${depthWord(a.dist)}, ${facingWord(a)}${pose}`;
  }
  function blockingLine(i, moment = 'start') {
    const A = analyse(i, moment); if (!A) return '';
    const people = Object.values(A.chars).filter(visible).sort((x, y) => x.sx - y.sx);
    return `BLOCKING${moment === 'end' ? ' (end)' : ''}: ${people.length ? people.map((a) => personLine(a)).join('; ') : 'no one in frame'}. Camera ${camWords(A)}.`;
  }
  function flare(i, moment = 'start') {
    const A = analyse(i, moment); if (!A) return '';
    const lines = [`BLOCKING (still frame, ${doc().meta.width}x${doc().meta.height}${moment === 'end' ? ', end frame' : ''}):`];
    for (const a of Object.values(A.chars).filter(visible).sort((x, y) => x.sx - y.sx)) lines.push(`- ${personLine(a)}; ${framingWords(a)}.`);
    if (lines.length === 1) lines.push('- No one in frame.');
    lines.push(`- Camera: ${camWords(A)}.`);
    return lines.join('\n');
  }
  function seedance(i) {
    const sh = shots()[i], tl = sh.timeline, sec = tl.duration, A0 = analyse(i, 'start'), A1 = analyse(i, 'end');
    if (!A0) return '';
    const lines = [`BLOCKING (motion, ${sec.toFixed(1)} s, start frame → end frame):`];
    for (const o of cast()) {
      const a0 = A0.chars[o.id], a1 = A1.chars[o.id]; if (!visible(a0) && !visible(a1)) continue;
      const steps = [];
      if (!visible(a0) && visible(a1)) steps.push(`enters from frame ${a1.sx > 0 ? 'right' : 'left'}`);
      const ks = walkKeys(o, tl);
      for (let k = 1; k < ks.length; k++) {
        const p = ks[k - 1], q = ks[k], d = Math.hypot(q.p[0] - p.p[0], q.p[2] - p.p[2]); if (d < 0.25) continue;
        const v = d / Math.max(0.2, q.t - p.t), verb = v < 0.6 ? 'walks slowly' : v < 1.5 ? 'walks' : v < 3 ? 'hurries' : 'runs';
        const ak = k === ks.length - 1 ? a1 : analyse(i, q.t / tl.duration)?.chars[o.id];
        steps.push(`${verb} to ${visible(ak) ? `${thirdWord(ak.sx)}, ${depthWord(ak.dist)}` : 'out of frame'} (${p.t.toFixed(1)}–${q.t.toFixed(1)} s)`);
      }
      if (!steps.some((s) => / to /.test(s)) && Math.abs(wrapA(ks[ks.length - 1].yaw - ks[0].yaw)) >= 25 && visible(a1)) steps.push(`turns to end ${facingWord(a1)}`);
      if (visible(a0) && !visible(a1)) steps.push(`exits frame ${a1 && a1.sx > 0 ? 'right' : 'left'}`);
      if (!steps.length) steps.push(`stays in place, ${facingWord(a0)}, small natural movement only`);
      lines.push(`- ${a0.name}: ${steps.join(', then ')}.`);
    }
    for (const o of doc().objects) { // props and vehicles that move
      if (isCast(o) || !moves(o, tl)) continue;
      const m = viewport.meshes.get(o.id); if (!m) continue;
      const scr = (A, t) => { const p = new THREE.Vector3(...sampleObject(o, tl, t).position).add(new THREE.Vector3(0, 0.5, 0)), e = p.clone().applyMatrix4(A.cam.matrixWorldInverse), q = p.clone().project(A.cam); return { x: q.x, in: e.z < 0 && Math.abs(q.x) <= 1 && Math.abs(q.y) <= 1 }; };
      const a = scr(A0, 0), b = scr(A1, tl.duration), dir = b.x > a.x ? ['left', 'right'] : ['right', 'left'];
      const what = !a.in && b.in ? `into frame from the ${dir[0]}` : a.in && !b.in ? `out of frame to the ${dir[1]}` : a.in && b.in ? `across the frame from ${dir[0]} to ${dir[1]}` : `past the frame from ${dir[0]} to ${dir[1]}`;
      lines.push(`- THE ${NAME(o)}: moves ${what} (0.0–${sec.toFixed(1)} s).`);
    }
    const mv = moveWords(sh);
    lines.push(mv ? `- Camera: ${mv}.` : '- Camera: locked off, no movement.');
    return lines.join('\n');
  }
  function keyframe(i, moment = 'start') {
    const sh = shots()[i], sl = slateOf(sh), sc = sceneSlate(), A = analyse(i, moment), end = moment === 'end';
    if (!A) return '';
    const title = sc.title || [doc().meta?.ep, doc().meta?.sc].filter(Boolean).join(' ');
    const mv = moveWords(sh);
    return [
      `${title} · ${sh.name}${sl.type && !sh.name.toUpperCase().includes(sl.type.toUpperCase()) ? ` · ${sl.type}` : ''} · ${secOf(sh).toFixed(1)}s · ${doc().meta.width}x${doc().meta.height}${end ? ' · END FRAME' : ''}`,
      sl.frame ? `FRAME: ${sl.frame}` : '',
      sl.action ? `ACTION: ${sl.action}` : '',
      sl.acting && !end ? `ACTING: ${sl.acting}` : '',
      setWords(A),
      blockingLine(i, moment),
      `CAMERA: ${!end && sl.camera ? `${sl.camera} ` : ''}${up1(camWords(A))}.`,
      !end && mv ? `CAMERA MOVE (start → end frame): ${mv}.` : '',
      sl.light ? `LIGHT: ${sl.light}` : '',
      sl.dialogue ? `DIALOGUE: ${sl.dialogue}` : '',
    ].filter(Boolean).join('\n');
  }

  // ---------- panel ----------
  const btn = h('button.cc-btn.st-add', { type: 'button', title: 'Slate, checks and prompts for this shot', onClick: () => toggle() }, icon('film'), 'Slate');
  hud.append(btn);
  const tabs = h('div.el-tabs'), head = h('div.sl-head'), body = h('div.sl-body');
  const panel = h('div.cc-panel.sl-panel', { hidden: true }, head, tabs, body);
  document.body.append(panel);
  function toggle(on = panel.hidden) { panel.hidden = !on; btn.classList.toggle('is-open', on); if (on) render(true); }
  const copy = (t) => navigator.clipboard.writeText(t).then(() => toast('Copied'), () => toast('Copy failed', { kind: 'error' }));
  const curIndex = () => Math.max(0, shots().findIndex((s) => s.active));

  function render(force) {
    if (panel.hidden || !doc()) return;
    const list = shots(), i = curIndex(), sh = list[i], key = `${store.rev}|${sh.id}|${tab}`;
    if (!force && key === cacheKey && panel.contains(document.activeElement)) return;
    cacheKey = key;
    let res;
    try { res = checks(i); } catch (e) { res = [['bad', `Couldn't check this shot: ${e.message}`]]; console.error(e); }
    const bad = res.filter((r) => r[0] === 'bad').length;
    head.replaceChildren(h('div.sl-title', {}, sceneSlate().title || `${doc().meta?.ep || ''} ${doc().meta?.sc || ''}`), h('div.sl-shot', {}, `${sh.name}${slateOf(sh).type ? ` · ${slateOf(sh).type}` : ''} · ${secOf(sh).toFixed(1)} s`));
    tabs.replaceChildren(...[['slate', 'Slate'], ['checks', `Checks${bad ? ` (${bad})` : ' ✓'}`], ['prompts', 'Prompts']].map(([k, label]) =>
      h('button.el-tab', { type: 'button', class: `${tab === k ? 'is-on' : ''}${k === 'checks' && bad ? ' has-bad' : ''}`, onClick: () => { tab = k; localStorage.setItem('bb.slateTab', k); render(true); } }, label)));
    if (tab === 'checks') body.replaceChildren(h('ul.sl-checks', {}, ...res.map(([k, t]) => h(`li.sl-${k}`, {}, t))));
    else if (tab === 'slate') body.replaceChildren(...slateForm(sh));
    else body.replaceChildren(...prompts(i, sh));
  }
  function slateForm(sh) {
    const sl = slateOf(sh), sc = sceneSlate(), names = cast(), L = doc().slate?.line || lineOf() || [];
    const set = (patch, label) => store.op({ op: 'slate', ...patch }, label).catch((e) => toast(e.message, { kind: 'error' }));
    const field = (k, label, ph) => {
      const el = k === 'type' || k === 'sec'
        ? h('input.cc-input.sl-in', { value: sl[k] ?? '', placeholder: ph || (k === 'sec' ? `${sh.timeline.duration}` : ''), type: k === 'sec' ? 'number' : 'text' })
        : h('textarea.cc-input.sl-ta', { placeholder: ph, rows: k === 'frame' || k === 'action' ? 3 : 2 }, sl[k] || '');
      el.addEventListener('keydown', (e) => e.stopPropagation());
      el.addEventListener('change', () => set({ shot: sh.id, [k]: el.value }, `slate ${k}`));
      return h('label.sl-f', {}, h('span', {}, label), el);
    };
    const sceneIn = (k, label) => { const el = h('input.cc-input.sl-in', { value: sc[k] || '' }); el.addEventListener('keydown', (e) => e.stopPropagation());
      el.addEventListener('change', () => set({ scene: { [k]: el.value } }, `scene ${k}`)); return h('label.sl-f', {}, h('span', {}, label), el); };
    const pick = (v, onChange) => { const s = h('select.cc-select', { onChange: () => onChange(s.value) }, names.map((o) => h('option', { value: o.id }, o.name))); s.value = v || ''; return s; };
    return [
      h('div.sl-sec', {}, 'Scene'), sceneIn('title', 'Title'), sceneIn('location', 'Location'),
      h('div.sl-f', {}, h('span', {}, '180° line'), names.length >= 2 ? h('div.sl-line', {}, pick(L[0], (v) => set({ line: [v, L[1] || names.find((o) => o.id !== v)?.id] }, '180 line')), '–',
        pick(L[1], (v) => set({ line: [L[0] || names.find((o) => o.id !== v)?.id, v] }, '180 line'))) : h('span.sl-note', {}, 'Needs two people')),
      h('div.sl-sec', {}, `Shot · ${sh.name}`), ...FIELDS.map(([k, label, ph]) => field(k, label, ph)),
      h('div.sl-row', {},
        h('button.cc-btn.cc-btn--ghost', { type: 'button', title: 'Render this scene\'s main keyframe and every shot\'s start / end frame for its cards in KAI', onClick: async () => {
          try { const n = await window.canvas.library.frames(true); toast(n ? `${n} frames updated for KAI` : 'No shot has a camera key yet'); } catch (e) { toast(e.message, { kind: 'error' }); } } }, icon('image'), 'Update KAI frames'),
        h('button.cc-btn.cc-btn--ghost', { type: 'button', title: 'Fill this scene\'s shots from a Blocking Board file (.html) or a slate export (.json)', onClick: () => importSlate() }, icon('folder'), 'Import slate…')),
    ];
  }
  function prompts(i, sh) {
    const n = shots().length, moving = sh.timeline.keys.length > 1;
    const blk = (title, text, all) => h('div.sl-blk', {},
      h('div.sl-blk-head', {}, h('strong', {}, title), h('button.cc-btn.cc-btn--ghost', { type: 'button', onClick: () => copy(text) }, 'Copy'),
        all && n > 1 ? h('button.cc-btn.cc-btn--ghost', { type: 'button', title: `Every shot of this scene, in order (${n})`, onClick: () => copy(shots().map((_, k) => all(k)).join('\n\n')) }, 'All shots') : null),
      h('pre.sl-pre', {}, text));
    return [
      blk('Keyframe prompt', keyframe(i), (k) => keyframe(k)),
      moving ? blk('End frame prompt', keyframe(i, 'end')) : null,
      blk('Flare · still', flare(i), (k) => `${shots()[k].name}\n${flare(k)}`),
      moving ? blk('Flare · end frame', flare(i, 'end')) : null,
      blk('Seedance · motion', seedance(i), (k) => `${shots()[k].name}\n${seedance(k)}`),
      blk('Blocking line', blockingLine(i), (k) => `${shots()[k].name}: ${blockingLine(k)}`),
    ].filter(Boolean);
  }

  // ---------- importing a slate (Blocking Board file or Blender slate export) ----------
  async function importSlate() {
    const f = await new Promise((ok) => { const inp = h('input', { type: 'file', accept: '.json,.html,application/json,text/html', onChange: () => ok(inp.files[0] || null) }); inp.click(); });
    if (!f) return;
    let data;
    try {
      const text = await f.text();
      const m = text.match(/<script type="application\/json" id="slateData">([\s\S]*?)<\/script>/);
      data = JSON.parse(m ? m[1] : text);
    } catch (e) { return toast(`Not a slate file: ${e.message}`, { kind: 'error' }); }
    const scenes = (data.scenes || []).filter((s) => s.shots?.length);
    if (!scenes.length) return toast('No scenes with shots in that file', { kind: 'error' });
    // pick one of its scenes
    const sel = h('select.cc-select', {}, scenes.map((s, k) => h('option', { value: k }, `${s.title || s.id} (${s.shots.length})`)));
    const box = h('div.cc-panel.sl-pick', {}, h('div.sl-sec', {}, `Fill ${doc().meta?.sc || 'this scene'} from:`), sel,
      h('div.sl-row', {}, h('button.cc-btn.cc-btn--ghost', { type: 'button', onClick: () => box.remove() }, 'Cancel'),
        h('button.cc-btn.cc-btn--primary', { type: 'button', onClick: () => { box.remove(); apply(scenes[+sel.value]); } }, 'Fill')));
    body.prepend(box);
  }
  async function apply(sc) {
    const P = (sh) => sh.props || {};
    try {
      await store.op({ op: 'slate', scene: { title: sc.title || sc.id, location: P(sc.shots[0]).slate_location || sc.location || '' } }, 'slate scene');
      for (let k = 0; k < sc.shots.length; k++) {
        const p = P(sc.shots[k]), name = p.slate_shot ? `${p.slate_shot}${p.slate_type ? ` ${p.slate_type}` : ''}` : sc.shots[k].name;
        let list = shots();
        if (k >= list.length) { // (a new shot goes after the active one: moved to its place in the slate's order)
          const [r] = await store.op({ op: 'shot.add', name, switch: false }, 'slate shot');
          await store.op({ op: 'shot.move', id: r.id, to: k + 1 }, 'slate shot order');
          list = shots();
        }
        const s = list[k], sec = parseFloat(p.slate_sec);
        if (s.name !== name) await store.op({ op: 'shot.update', id: s.id, name }, 'slate shot name');
        await store.op({ op: 'slate', shot: s.id, type: p.slate_type || '', ...(sec > 0 ? { sec } : {}), frame: p.slate_frame || '', action: p.slate_action || '',
          acting: p.slate_acting || '', camera: p.slate_camera || '', light: p.slate_light || '', dialogue: p.slate_dialogue || '' }, 'slate');
        if (sec > 0 && Math.abs(s.timeline.duration - sec) > 0.01) await store.op({ op: 'timeline', shot: s.id, duration: sec }, 'shot length');
      }
      toast(`Slate filled: ${sc.shots.length} shot${sc.shots.length === 1 ? '' : 's'}`);
      tab = 'slate'; render(true);
    } catch (e) { toast(e.message, { kind: 'error' }); }
  }

  // ---------- the scene's prompt document (KAI): prompts/<Episode>/PROMPTS - <Scene>.md, kept up to date ----------
  function promptDoc() {
    const d = doc(); if (!d?.meta?.ep || !d.meta.sc) return '';
    const sc = sceneSlate(), FB = '`'.repeat(3), fence = (t) => t ? `\n${FB}\n${t}\n${FB}\n` : '\n(no camera key yet)\n';
    const out = [`# ${d.meta.ep} · ${d.meta.sc}${sc.title ? ` · ${sc.title}` : ''} - prompts`, '',
      `Written by Blocking Board from the slate and the blocking (${new Date().toLocaleString()}). Change the slate in Blocking Board, not here.`];
    shots().forEach((sh, i) => {
      const sl = slateOf(sh), moving = sh.timeline.keys.length > 1;
      out.push('', `## ${i + 1}. ${sh.name}${sl.type && !sh.name.toUpperCase().includes(sl.type.toUpperCase()) ? ` · ${sl.type}` : ''} · ${secOf(sh).toFixed(1)} s`);
      out.push('', '### Keyframe - start', fence(keyframe(i, 'start')));
      if (moving) out.push('### Keyframe - end', fence(keyframe(i, 'end')));
      out.push('### Flare still', fence(flare(i, 'start')));
      if (moving) out.push('### Flare end', fence(flare(i, 'end')));
      out.push('### Seedance motion', fence(seedance(i)));
      out.push('### Blocking line', fence(blockingLine(i)));
    });
    return out.join('\n').replace(/\n{3,}/g, '\n\n') + '\n';
  }
  let promptsSent = '', promptsTimer = null;
  const promptBody = () => { try { return promptDoc(); } catch (e) { console.warn('prompt document', e); return ''; } };
  // (the date line changes every time: only what's under it decides whether the file needs writing)
  const sig = (t) => t.replace(/^Written by (Blocking Board|Blocking Board).*$/m, '');
  async function writePrompts() {
    clearTimeout(promptsTimer); promptsTimer = null;
    const text = promptBody(); if (!text || sig(text) === promptsSent) return;
    promptsSent = sig(text);
    await fetch('/api/prompts', { method: 'POST', body: text, keepalive: text.length < 60000 }).catch(() => { promptsSent = ''; });
  }
  store.on('doc', () => { clearTimeout(promptsTimer); promptsTimer = setTimeout(() => viewport.loaded().then(writePrompts), 4000); });
  addEventListener('pagehide', () => { if (promptsTimer) { const text = promptBody(); if (text) navigator.sendBeacon('/api/prompts', new Blob([text], { type: 'text/plain' })); } });

  let t = null;
  store.on('doc', () => { clearTimeout(t); t = setTimeout(() => render(), 250); });
  return { toggle, checks, analyse, keyframe, flare, seedance, blockingLine, fill: apply, promptDoc, writePrompts };
}
