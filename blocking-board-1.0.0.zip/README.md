# Blocking Board

3D blocking for films and series: build each scene's set, place people and props, block the camera shot by shot, and
get every shot's keyframe and motion prompts out of it. Blocking Board is a KAI plugin: installed with KAI, it opens
inside KAI's window, keeps one board per KAI project (in the project's `KAI\Blocking Board\` folder) and puts its
scenes on KAI's canvases as cards.

- **Episodes and scenes** - jump between them (Alt + arrows), merge scenes with camera continuity.
- **Sets** - walls, rooms, floors, ceilings, roofs, windows and doors, stairs, textures, sky and backdrop cards;
  shared Locations with states (Day, Night...) used by many scenes.
- **Plan view (P)** - a measured, metric blueprint with a section cut; drag and turn things to exact positions.
- **Slate, checks and prompts** - per-shot slate, continuity checks (180° line, jump cuts, framing...) and keyframe,
  Flare, Seedance and blocking prompts, kept in `prompts\<Episode>\PROMPTS - <Scene>.md`.
- **Elements** - the KAI project's Higgsfield elements as cards and textures.
- **Nothing lost** - every change is saved as you make it.

## Running it

Normally KAI installs, updates and starts it (KAI → Plugins). To work on it on its own:

```
npm install
node bin/canvas.mjs up        # server + browser tab at http://127.0.0.1:5317
npm test
```

Releases: raise the version in package.json, then `node tools/release.mjs --publish` builds
`release/blocking-board-<version>.zip` and `latest.json` and pushes them to the public
[BlockingBoard-releases](https://github.com/gagambalaa/BlockingBoard-releases) repo; every KAI with Blocking Board
installed offers the update.

Developers: read `AGENTS.md`.

## Credit

Built on [Blockout](https://github.com/shrimbly/blockout) by shrimbly (MIT); its licence is in `LICENSE`.
