// Blocking Board: the board layout, as on the first Blocking Board - the floor plan (the main view: Plan or 3D) on the
// left, the camera in a column on the right with the settings panels (Object, Floor plan) under it, the timeline
// along the bottom. The line between the two drags (the split is kept per PC). A narrow window stacks them, plan on
// top. The Layout button in the top bar switches to the full-screen layout (one view fills the window, the camera in
// a small window) and back; that is kept per PC too. The board layout opens on the Plan view.
import { h, icon } from './ui/kit.js';
import { store } from './store.js';

const STACK_BELOW = 820;   // px: narrower windows stack the plan over the camera
const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
const read = (k) => { try { return localStorage.getItem(k); } catch { return null; } };
const write = (k, v) => { try { localStorage.setItem(k, v); } catch {} };

export function mountBoardLayout(hud, { viewport, camView }) {
  let on = read('bb.layout') !== 'full';
  let split = clamp(parseFloat(read('bb.split')) || 0.55, 0.3, 0.75);   // the plan's share of the width
  const dock = document.getElementById('dock'), home = { parent: dock.parentNode, next: dock.nextSibling };
  const btn = h('button.cc-btn.st-add', { type: 'button', onClick: () => toggle() }, icon('columns'), 'Layout');
  hud.append(btn);
  const bar = h('div.bb-divider', { title: 'Drag to give the plan or the camera more room' });
  document.body.append(bar);

  // where everything goes: area = the main view, col = the camera column (px, window coordinates)
  function geom() {
    const W = innerWidth, tl = document.getElementById('timeline')?.getBoundingClientRect();
    const bottom = Math.round((tl ? tl.top : innerHeight) - 10);
    if (W < STACK_BELOW) {
      const top = Math.round(bottom * 0.5);
      return { stack: true, area: { x: 0, y: 0, w: W, h: top }, col: { x: 12, y: top + 6, w: W - 24, h: bottom - top - 6 } };
    }
    const lw = Math.round(W * split);
    // (the column starts under the top-right corner menu)
    return { stack: false, area: { x: 0, y: 0, w: lw, h: bottom }, col: { x: lw + 6, y: 52, w: W - lw - 18, h: bottom - 52 } };
  }

  function apply() {
    document.body.classList.toggle('bb-board', on);
    btn.classList.toggle('is-open', on);
    btn.title = on ? 'Layout: plan and camera side by side. Click for one full-screen view.' : 'Layout: one full-screen view. Click for the plan and the camera side by side.';
    const root = document.documentElement.style;
    if (on) {
      const g = geom();
      document.body.classList.toggle('bb-stack', g.stack);
      for (const [k, v] of Object.entries({ x: g.col.x, y: g.col.y, w: g.col.w, h: g.col.h })) root.setProperty(`--bb-col-${k}`, `${v}px`);
      root.setProperty('--bb-right', `${innerWidth - g.area.w}px`);
      if (dock.parentNode !== camView.panel) camView.panel.append(dock);   // the settings go under the camera
      viewport.areaOf = () => geom().area;
    } else {
      document.body.classList.remove('bb-stack');
      if (dock.parentNode !== home.parent) home.parent.insertBefore(dock, home.next);
      viewport.areaOf = null;
    }
    viewport.layout();
    camView.place();
  }
  function toggle(v = !on) {
    on = v; write('bb.layout', on ? 'board' : 'full');
    if (on && store.state.view === 'free') store.set({ view: 'plan' });
    apply();
  }

  // dragging the line between the plan and the camera
  let drag = null;
  bar.addEventListener('pointerdown', (e) => { drag = true; bar.setPointerCapture(e.pointerId); bar.classList.add('is-drag'); e.preventDefault(); });
  bar.addEventListener('pointermove', (e) => {
    if (!drag) return;
    split = clamp(e.clientX / innerWidth, 0.3, 0.75);
    if (drag === true) drag = requestAnimationFrame(() => { drag = drag && true; apply(); }); // (once a frame)
  });
  const end = () => { if (!drag) return; drag = null; bar.classList.remove('is-drag'); write('bb.split', String(Math.round(split * 1000) / 1000)); apply(); };
  bar.addEventListener('pointerup', end);
  bar.addEventListener('pointercancel', end);
  bar.addEventListener('dblclick', () => { split = 0.55; write('bb.split', '0.55'); apply(); });

  addEventListener('resize', apply);
  const tl = document.getElementById('timeline');
  if (tl) new ResizeObserver(() => on && apply()).observe(tl);   // (the timeline grows with the audio lane)
  // the board layout opens on the floor plan
  if (on && store.state.view === 'free') store.set({ view: 'plan' });
  apply();
  return { toggle, get on() { return on; } };
}
