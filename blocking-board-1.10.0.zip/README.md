# Blocking Board

3D blocking for films and series: build each scene's set, place people and props, block the camera shot by shot, and
get every shot's keyframe and motion prompts out of it. Blocking Board is a KAI plugin: installed with KAI, it opens
inside KAI's window, keeps one board per KAI project (in the project's `KAI\Blocking Board\` folder) and puts its
scenes on KAI's canvases as cards.

- **Episodes and scenes** - jump between them (Alt + arrows), merge scenes with camera continuity.
- **Sets** - walls, rooms, floors, ceilings, roofs, windows and doors, stairs, textures, sky and backdrop cards;
  shared Locations with states (Day, Night...) used by many scenes.
- **Plan view (P)** - a measured, metric blueprint with a section cut; drag and turn things to exact positions.
- **Board layout** - the floor plan on the left and the camera on the right, side by side, with the settings under the
  camera; drag the line between them.
- **Main view and Cam view** - plan or 3D as the main view, with a live picture of what the shot camera sees beside it.
- **Slate, checks and prompts** - per-shot slate, continuity checks (180° line, jump cuts, framing...) and a Prompts
  tab of prompt blocks (keyframe, Flare, Seedance, blocking line), kept in `prompts\<Episode>\` as a document and as
  data other plugins read (`docs/PLUGIN_DATA.md`).
- **Elements** - the KAI project's Higgsfield elements as cards and textures.
- **Nothing lost** - every change is saved as you make it.

## Which app holds the truth

Each part of a scene has one home. Change it there; the other app reads it from there.

| What | Truth in |
| --- | --- |
| Style blocks | Scene Slate |
| Scene description and action | Scene Slate |
| Dialogue | Scene Slate |
| Constraints | Scene Slate |
| Camera and framing | Scene Slate as the starting intent; Blocking Board once the scene is staged |
| Lighting | Scene Slate as the starting light; Blocking Board only where someone set it there |
| Blocking of characters and props | Blocking Board |

Never copy one app's version over the other's, and never change what a scene says by editing a card on KAI's canvas.

## Running it

Normally KAI installs, updates and starts it (KAI → Plugins). To work on it on its own:

```
npm install
node bin/canvas.mjs up        # server + browser tab at http://127.0.0.1:5317
npm test
```

## For its developers

You change this plugin and publish it yourself; KAI's owner doesn't have to do anything. Every KAI that has it then
shows that an update is there (a dot on its tab, an Update button) and installs it when the artist says so.

**Set up (once)**

1. Install [Node.js](https://nodejs.org) 20 or newer and Git. Accept the two GitHub invitations (this repo, and
   `BlockingBoard-releases`).
2. `git clone https://github.com/gagambalaa/BlockingBoard.git`, then `npm install` in it.
3. To see your working copy inside KAI on your PC: close KAI, add the folder to KAI's `config.json` -
   `"plugins": ["C:\\path\\to\\BlockingBoard"]` - and start KAI again. Its tab now runs your copy (Settings → App → Plugins
   says "developer copy"). Changes to the screen show when you reopen it; after changing `server/`, press
   **Restart** next to it in Settings → App → Plugins.

**The film's frame:** the picker in the Cam view's header sets one aspect for every scene (9:16 for a vertical show;
it follows Scene Slate's format until one is picked). The camera, the prompts and the frames on KAI's cards follow it.

**Change, test, publish**

0. `git pull` first, every time (someone may have published since). A conflict, or old changes not
   pushed: stop and sort it out with the others before going on.
1. Make the change. `npm test` must pass.
2. Raise the version: `npm version patch --no-git-tag-version` (`minor` for something new, `major` when data changes
   shape) - higher than the version in the releases repo's `latest.json`. `git pull` again, then commit and `git push`.
3. `node tools/release.mjs --publish` - builds the package and pushes it to `BlockingBoard-releases`. Within a few minutes every
   KAI offers the update.

A release can't be taken back once artists have installed it: publish a fixed one with a higher version instead.
Never put keys, passwords or a project's files in either repo. Read `AGENTS.md` before changing how data is stored
or shared - other artists' work and the other plugin depend on it.

## Credit

Built on [Blockout](https://github.com/shrimbly/blockout) by shrimbly (MIT); its licence is in `LICENSE`.
