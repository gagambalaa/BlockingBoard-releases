// Blocking Board: things don't pass through things. When a person or a prop is moved by hand (dragged on the plan,
// the gizmo in 3D), the move is swept from where it was to where it's going: rays across the floor at a few heights
// (feet, knees, waist, chest, head for a person; bottom and middle for a prop), at its middle and both sides, against
// the set (the visible parts of imported models, walls, boxes, roofs), the other people and the other props. It stops
// just short of the first thing it would go into, and slides along it (the x and z parts of the move tried on their
// own) instead of sticking. Super-thin things - paper, banners, strings, cloth: under 3 cm through their thinnest side -
// never block, and a super-thin thing never gets blocked. Typed numbers (the Object panel) are taken as they are.
import * as THREE from 'three';
import { store } from './store.js';
import { objectHeight } from '/core/doc.js';

const THIN = 0.03, GAP = 0.02;
const ray = new THREE.Raycaster(), box = new THREE.Box3(), size = new THREE.Vector3();
const thinBox = (o3) => { box.setFromObject(o3, false); if (box.isEmpty()) return true; box.getSize(size); return Math.min(size.x, size.y, size.z) < THIN; };

export function mountCollide(viewport) {
  /** The movers's footprint (its radius across the floor) and the heights its rays run at, above its feet. */
  function shapeOf(id) {
    const o = store.object(id), m = viewport.meshes.get(id);
    if (!o || !m) return null;
    if (o.type === 'person') {
      const h = objectHeight(o) * (o.scale?.[1] || 1);
      return { r: 0.2 * (o.scale?.[0] || 1), heights: [0.12, 0.45, 0.9, 1.3, 0.95 * h].map((y) => Math.min(y, h)) };
    }
    if (['model', 'wall', 'plane', 'roof', 'light'].includes(o.type)) return null;   // (the set itself moves freely)
    box.setFromObject(m.mesh, false); if (box.isEmpty()) return null;
    box.getSize(size);
    if (Math.min(size.x, size.y, size.z) < THIN) return null;   // (paper, a banner: never blocked)
    return { r: Math.max(0.03, Math.max(size.x, size.z) / 2), heights: [Math.min(0.05, size.y / 2), size.y / 2, size.y * 0.9], base: box.min.y - m.mesh.position.y };
  }
  /** Everything that blocks the mover: visible, not super-thin, not the mover or what it's holding / held by. */
  function obstacles(id) {
    const out = [], skip = new Set([id]);
    const sh = store.doc?.shots?.find((s) => s.id === store.doc.shot);
    for (const [pid, hd] of Object.entries(sh?.hold || {})) { if (pid === id) skip.add(hd.by); if (hd.by === id) skip.add(pid); }
    for (const [oid, m] of viewport.meshes) {
      if (skip.has(oid) || !m.mesh.visible) continue;
      const o = store.object(oid); if (!o || o.type === 'light' || o.type === 'plane' || (sh?.off || []).includes(oid)) continue;
      if (m.model) {
        m.model.traverse((c) => {
          if (!c.isMesh || c.isSkinnedMesh || !c.visible || c.userData.cropped || m.planFlat?.includes(c)) return;
          if (c.userData.thin ?? (c.userData.thin = thinBox(c))) return;
          out.push(c);
        });
      } else if (!thinBox(m.mesh)) {
        out.push(m.mesh);
        m.mesh.traverse((c) => { if (c !== m.mesh && c.isMesh && !c.userData.noHit) out.push(c); });
      }
    }
    return out;
  }
  /** How far along from -> to (0..1) the mover gets before it would go into something. */
  function sweep(shape, list, from, to, y0) {
    const dx = to.x - from.x, dz = to.z - from.z, L = Math.hypot(dx, dz);
    if (L < 1e-4) return 1;
    const dir = new THREE.Vector3(dx / L, 0, dz / L), side = new THREE.Vector3(-dir.z, 0, dir.x);
    let best = L;
    for (const hgt of shape.heights) for (const s of [0, 1, -1]) {
      const o = new THREE.Vector3(from.x, y0 + hgt, from.z).addScaledVector(side, s * shape.r * 0.9);
      ray.set(o, dir); ray.near = 0; ray.far = L + shape.r + GAP;
      // (the first face it would go into: a back face - the inside of something it's standing in - doesn't stop it
      // walking out)
      const hit = ray.intersectObjects(list, false).find((x) => !x.face || x.face.normal.clone().transformDirection(x.object.matrixWorld).dot(dir) < 0);
      if (hit) best = Math.min(best, Math.max(0, hit.distance - (s ? shape.r * 0.45 : shape.r) - GAP));
    }
    return best / L;
  }
  let cache = null;   // the obstacles for one drag (made once when it starts)
  /** Where a move from -> to ends up (THREE.Vector3s, world): the same point when nothing is in the way. */
  function solve(id, from, to, { keep = false } = {}) {
    const shape = shapeOf(id); if (!shape) return to.clone();
    if (!cache || cache.id !== id) cache = { id, list: obstacles(id) };
    const list = cache.list, y0 = from.y + (shape.base || 0);
    const f = sweep(shape, list, from, to, y0);
    if (f >= 1) return to.clone();
    // blocked: slide along it (the x part, then the z part, from where it stopped)
    const at = from.clone().lerp(to, f), out = at.clone();
    for (const axis of ['x', 'z']) {
      const next = out.clone(); next[axis] = to[axis];
      const g = sweep(shape, list, out, next, y0);
      out[axis] += (to[axis] - out[axis]) * g;
    }
    out.y = to.y;
    if (!keep) cache = null;
    return out;
  }
  return {
    solve,
    /** A drag starts / ends: the obstacles are gathered once per drag. */
    begin(id) { cache = { id, list: obstacles(id) }; },
    end() { cache = null; },
    get on() { try { return localStorage.getItem('bb.collide') !== 'off'; } catch { return true; } },
    set on(v) { try { localStorage.setItem('bb.collide', v ? 'on' : 'off'); } catch {} },
  };
}
