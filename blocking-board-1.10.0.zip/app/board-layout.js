// Blocking Board: the board layout, as on the first Blocking Board - the floor plan (the main view: Plan or 3D) on the
// left, the camera in a column next to it, and the settings panels (Objects, Object, Floor plan) in their own column at
// the right edge (under the camera in a narrow window), the timeline along the bottom. The line between the two drags (the split is kept per PC). A narrow window stacks them, plan on
// top. There is no other layout (the old full-screen one, with the camera in a small window, was removed). The board layout opens on the Plan view.
import { h, icon } from './ui/kit.js';
import { store } from './store.js';

const STACK_BELOW = 820;   // px: narrower windows stack the plan over the camera
const DOCK_W = 290;        // px: the settings column (Objects, Object, Floor plan) at the right edge
const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
const read = (k) => { try { return localStorage.getItem(k); } catch { return null; } };
const write = (k, v) => { try { localStorage.setItem(k, v); } catch {} };

export function mountBoardLayout(hud, { viewport, camView }) {
  const on = true;   // (the only layout: the old full-screen one, camera in a small window at the bottom left, is gone)
  let split = clamp(parseFloat(read('bb.split')) || 0.55, 0.3, 0.75);   // the plan's share of the width
  const dock = document.getElementById('dock'), home = { parent: dock.parentNode, next: dock.nextSibling };
  const bar = h('div.bb-divider', { title: 'Drag to give the plan or the camera more room' });
  document.body.append(bar);

  // where everything goes: area = the main view, col = the camera column (px, window coordinates)
  function geom() {
    const W = innerWidth, tl = document.getElementById('timeline')?.getBoundingClientRect();
    const bottom = Math.round((tl ? tl.top : innerHeight) - 10);
    if (W < STACK_BELOW) {
      const top = Math.round(bottom * 0.5);
      return { stack: true, area: { x: 0, y: 0, w: W, h: top }, col: { x: 12, y: top + 6, w: W - 24, h: bottom - top - 6 } };
    }
    const rest = W - DOCK_W - 12, lw = Math.round(rest * split);
    // (the columns start at the top: nothing sits in the top-right corner any more)
    return { stack: false, area: { x: 0, y: 0, w: lw, h: bottom }, col: { x: lw + 6, y: 12, w: rest - lw - 12, h: bottom - 12 },
      dock: { x: rest, y: 12, w: DOCK_W, h: bottom - 12 } };
  }

  function apply() {
    document.body.classList.toggle('bb-board', on);
    const root = document.documentElement.style;
    if (on) {
      const g = geom();
      document.body.classList.toggle('bb-stack', g.stack);
      for (const [k, v] of Object.entries({ x: g.col.x, y: g.col.y, w: g.col.w, h: g.col.h })) root.setProperty(`--bb-col-${k}`, `${v}px`);
      root.setProperty('--bb-right', `${innerWidth - g.area.w}px`);
      if (g.dock) {   // the settings in their own column at the right edge
        for (const [k, v] of Object.entries(g.dock)) root.setProperty(`--bb-dock-${k}`, `${v}px`);
        if (dock.parentNode !== home.parent) home.parent.insertBefore(dock, home.next);
      } else if (dock.parentNode !== camView.panel) camView.panel.append(dock);   // (a narrow window: under the camera)
      document.body.classList.toggle('bb-dockcol', !!g.dock);
      viewport.areaOf = () => geom().area;
    } else {
      document.body.classList.remove('bb-stack', 'bb-dockcol');
      if (dock.parentNode !== home.parent) home.parent.insertBefore(dock, home.next);
      viewport.areaOf = null;
    }
    viewport.layout();
    camView.place();
  }
  const toggle = () => {};   // (one layout now: kept so callers don't break)

  // dragging the line between the plan and the camera
  let drag = null;
  bar.addEventListener('pointerdown', (e) => { drag = true; bar.setPointerCapture(e.pointerId); bar.classList.add('is-drag'); e.preventDefault(); });
  bar.addEventListener('pointermove', (e) => {
    if (!drag) return;
    split = clamp(e.clientX / Math.max(1, innerWidth - DOCK_W - 12), 0.3, 0.75);
    if (drag === true) drag = requestAnimationFrame(() => { drag = drag && true; apply(); }); // (once a frame)
  });
  const end = () => { if (!drag) return; drag = null; bar.classList.remove('is-drag'); write('bb.split', String(Math.round(split * 1000) / 1000)); apply(); };
  bar.addEventListener('pointerup', end);
  bar.addEventListener('pointercancel', end);
  bar.addEventListener('dblclick', () => { split = 0.55; write('bb.split', '0.55'); apply(); });

  addEventListener('resize', apply);
  const tl = document.getElementById('timeline');
  if (tl) new ResizeObserver(() => on && apply()).observe(tl);   // (the timeline grows with the audio lane)
  // the board layout opens on the floor plan
  if (on && store.state.view === 'free') store.set({ view: 'plan' });
  apply();
  return { toggle, get on() { return on; } };
}
