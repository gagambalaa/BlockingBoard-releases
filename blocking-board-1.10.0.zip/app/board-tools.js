// Blocking Board tools for people (no agent needed): the ＋ Add menu, wall drawing on the floor plan, the inspector for the
// selected object (colour, texture, its own settings) and pictures dropped on the set (on an object = its texture,
// on the floor = a picture card: a generated character or prop standing in the set).

import * as THREE from 'three';
import { h, icon, toast, panel, row, number, color, select, button, affix, segmented } from './ui/kit.js';
import { objectHeight, HOLD_MODES, PERSON_POSES } from '/core/doc.js';
import { store } from './store.js';
import { importAny, isModelFile, MODEL_ACCEPT } from './models.js';
import { DEFAULT_COLOR } from '/core/doc.js';

const r2 = (v) => Math.round(v * 100) / 100;
const isImage = (f) => /^image\/(png|jpeg|webp)$/.test(f.type) || /\.(png|jpe?g|webp)$/i.test(f.name);

/** A model's crop for this scene: what the shot cameras see (viewport.partsInFrame - start and end of every shot, a
 * little wider than the lens) + everything within r (default 3 m) of the people - or of the cameras when there are
 * none - so the plan still shows the room round them. */
async function aroundScene(id, r) {
  const d = store.doc, pts = d.objects.filter((o) => o.type === 'person').map((o) => o.position);
  if (!pts.length) for (const tl of [d.timeline, ...(d.shots || []).map((sh) => sh.timeline)]) for (const k of tl?.keys || []) pts.push(k.position);
  const x = pts.length ? pts.reduce((a, p) => a + p[0], 0) / pts.length : 0, z = pts.length ? pts.reduce((a, p) => a + p[2], 0) / pts.length : 0;
  const parts = await window.canvas.viewport.partsInFrame(id);
  return { x: Math.round(x * 10) / 10, z: Math.round(z * 10) / 10, r: r || 3, parts };
}

export function mountBoardTools(hud, { viewport }) {
  const at = () => { const p = viewport.focusPoint(); return [r2(p.x), 0, r2(p.z)]; };
  // while the scene edits its location, what is added becomes part of the location
  const locFlag = () => (store.doc?.meta?.location?.edit === 'location' ? { loc: true } : {});
  const add = async (op, label) => {
    try { const [r] = await store.op({ ...op, ...locFlag() }, label); store.set({ selection: r.id }); return r; } catch (e) { toast(e.message, { kind: 'error' }); return null; }
  };

  // ---------- pictures: upload, size ----------
  async function upload(file) {
    const res = await fetch(`/api/texture?name=${encodeURIComponent(file.name)}`, { method: 'POST', body: file });
    const r = await res.json();
    if (!r.ok) throw new Error(r.error);
    return r;
  }
  const aspectOf = (url) => new Promise((ok) => { const i = new Image(); i.onload = () => ok(i.naturalWidth / i.naturalHeight || 1); i.onerror = () => ok(1); i.src = url; });
  const pick = () => new Promise((ok) => {
    const inp = h('input', { type: 'file', accept: 'image/png,image/jpeg,image/webp', onChange: () => ok(inp.files[0] || null) });
    inp.click();
  });
  async function addCard(file, pos = at()) {
    try {
      const up = await upload(file);
      const aspect = r2(await aspectOf(up.url));
      const name = file.name.replace(/\.[a-z0-9]+$/i, '').replace(/[^a-z0-9]+/gi, '-').slice(0, 30) || 'card';
      return add({ op: 'add', type: 'card', name, file: up.file, aspect, h: aspect > 1.4 ? 1 : 1.8, position: pos }, `card ${name}`);
    } catch (e) { toast(e.message, { kind: 'error' }); }
  }
  async function texture(id, file) {
    try {
      const up = await upload(file);
      const o = store.object(id);
      await store.op({ op: 'update', id, texture: { file: up.file, scale: o?.texture?.scale ?? (o?.type === 'wall' || o?.type === 'plane' ? 2 : 1) } }, `texture ${id}`);
    } catch (e) { toast(e.message, { kind: 'error' }); }
  }

  // ---------- ＋ Add menu ----------
  const ITEMS = [
    ['Wall', 'Click points on the floor; double-click or Enter to finish', () => draw.start()],
    ['Room', '4 × 5 m, four walls', () => add({ op: 'add', type: 'wall', name: 'room', points: [[0, 0], [4, 0], [4, 5], [0, 5]], closed: true, position: at() }, 'room')],
    ['Floor', '6 × 6 m plane', () => add({ op: 'add', type: 'plane', name: 'floor', w: 6, d: 6, position: at() }, 'floor')],
    ['Ceiling', '6 × 6 m slab at 2.7 m', () => { const p = at(); p[1] = 2.65; return add({ op: 'add', type: 'box', name: 'ceiling', w: 6, h: 0.05, d: 6, position: p, color: '#f4f1ea' }, 'ceiling'); }],
    ['Roof', 'Gable roof, eaves at 2.7 m', () => { const p = at(); p[1] = 2.7; return add({ op: 'add', type: 'roof', name: 'roof', position: p, color: '#b5651d' }, 'roof'); }],
    ['Box', '', () => add({ op: 'add', type: 'box', position: at() }, 'box')],
    ['Stairs', '', () => add({ op: 'add', type: 'stairs', position: at() }, 'stairs')],
    ['Doorway', 'An arch', () => add({ op: 'add', type: 'arch', name: 'doorway', position: at() }, 'doorway')],
    ['Person', '', () => add({ op: 'add', type: 'person', position: at() }, 'person')],
    ['3D model…', 'A .glb, .gltf, .obj, .fbx, .dae, .stl, .ply, .3mf or .3ds file - pick it together with its textures and .mtl / .bin files', async () => {
      const files = await new Promise((ok) => { const inp = h('input', { type: 'file', accept: MODEL_ACCEPT, multiple: true, onChange: () => ok([...inp.files]) }); inp.click(); });
      if (!files.length) return;
      if (!files.some(isModelFile)) return toast('Pick the model file too (.glb .gltf .obj .fbx …), not only its textures', { kind: 'error' });
      const p = at(); importAny(files, { x: p[0], y: p[1], z: p[2] });
    }],
    ['Card…', 'A character or prop picture (transparent PNG)', async () => { const f = await pick(); if (f) addCard(f); }],
    ['Sky (360°)…', 'A 360° sky picture all round the set', async () => { const f = await pick(); if (!f) return;
      try { const up = await upload(f); await store.op({ op: 'env', sky: { file: up.file } }, 'sky'); } catch (e) { toast(e.message, { kind: 'error' }); } }],
    ['Remove sky', '', () => store.op({ op: 'env', sky: null }, 'no sky').catch(() => {})],
    ['BG card…', 'A big backdrop picture far behind the set (unlit)', async () => {
      const f = await pick(); if (!f) return;
      try {
        const up = await upload(f), aspect = r2(await aspectOf(up.url)), p = at(), cam = viewport.activeCam.position;
        // 60 m beyond the focus point, away from the camera, facing it
        const dx = p[0] - cam.x, dz = p[2] - cam.z, L = Math.hypot(dx, dz) || 1, x = r2(p[0] + (dx / L) * 60), z = r2(p[2] + (dz / L) * 60);
        const turn = Math.round(Math.atan2(-dx, -dz) * 180 / Math.PI);
        await add({ op: 'add', type: 'card', name: 'bg-card', file: up.file, aspect, h: 30, face: 'fixed', lit: false, position: [x, -2, z], rotation: [0, turn, 0] }, 'bg card');
      } catch (e) { toast(e.message, { kind: 'error' }); }
    }],
    ['Lamp', 'Point light', () => { const p = at(); p[1] = 2.4; return add({ op: 'add', type: 'light', name: 'lamp', color: '#ffd9a8', position: p }, 'lamp'); }],
    ['Spotlight', '', () => { const p = at(); p[1] = 3; return add({ op: 'add', type: 'light', name: 'spot', kind: 'spot', color: '#ffffff', position: p }, 'spot'); }],
  ];
  const menu = h('div.cc-panel.st-menu', { hidden: true }, ...ITEMS.map(([label, note, fn]) =>
    h('button.st-item', { type: 'button', title: note, onClick: () => { toggle(false); fn(); } }, label, note ? h('span.st-note', {}, note) : null)));
  const addBtn = h('button.cc-btn.cc-panel.st-add', { type: 'button', title: 'Add to the set', onClick: () => toggle() }, icon('plus'), 'Add');
  hud.append(addBtn);
  document.body.append(menu);
  function toggle(on = menu.hidden) {
    menu.hidden = !on; addBtn.classList.toggle('is-open', on);
    if (on) { const r = addBtn.getBoundingClientRect(); menu.style.left = `${r.left}px`; menu.style.top = `${r.bottom + 6}px`; }
  }
  addEventListener('pointerdown', (e) => { if (!menu.hidden && !menu.contains(e.target) && !addBtn.contains(e.target)) toggle(false); }, true);

  // ---------- drawing walls on the floor ----------
  const draw = (() => {
    const ray = new THREE.Raycaster(), floor = new THREE.Plane(new THREE.Vector3(0, 1, 0), 0);
    let pts = null, hover = null;
    const line = new THREE.Line(new THREE.BufferGeometry(), new THREE.LineBasicMaterial({ color: 0xff5a1f, depthTest: false }));
    line.renderOrder = 999;
    const hint = h('div.cc-panel.st-hint', { hidden: true });
    document.body.append(hint);
    const ground = (e) => {
      const r = viewport.canvas.getBoundingClientRect();
      ray.setFromCamera(new THREE.Vector2(((e.clientX - r.left) / r.width) * 2 - 1, -((e.clientY - r.top) / r.height) * 2 + 1), viewport.activeCam);
      const p = ray.ray.intersectPlane(floor, new THREE.Vector3());
      if (!p) return null;
      const snap = e.shiftKey ? 0.01 : store.state.view === 'plan' ? 0.05 : 0.25;
      let q = [Math.round(p.x / snap) * snap, Math.round(p.z / snap) * snap];
      // onto a wall end nearby (or this wall's first point, to close it), so corners meet exactly
      const ends = [...(pts?.length > 2 ? [pts[0]] : []), ...wallEnds()];
      const near = ends.map((w) => [w, Math.hypot(w[0] - p.x, w[1] - p.z)]).sort((a, b) => a[1] - b[1])[0];
      if (near && near[1] < 0.2 && !e.shiftKey) return near[0].map(r2);
      // Ctrl: keep the segment straight (0° / 90°)
      const last = pts?.at(-1);
      if (last && (e.ctrlKey || e.metaKey)) q = Math.abs(q[0] - last[0]) > Math.abs(q[1] - last[1]) ? [q[0], last[1]] : [last[0], q[1]];
      return q.map(r2);
    };
    // every wall's corner points in world x, z (for snapping)
    const wallEnds = () => (store.doc?.objects || []).filter((o) => o.type === 'wall').flatMap((o) => {
      const a = (o.rotation[1] || 0) * DEG, c = Math.cos(a), s = Math.sin(a);
      return o.params.points.map(([x, z]) => [o.position[0] + x * c + z * s, o.position[2] - x * s + z * c]);
    });
    const show = () => {
      const all = hover ? [...pts, hover] : pts;
      line.geometry.dispose();
      line.geometry = new THREE.BufferGeometry().setFromPoints(all.map(([x, z]) => new THREE.Vector3(x, 0.02, z)));
      const seg = hover && pts.length ? Math.hypot(hover[0] - pts.at(-1)[0], hover[1] - pts.at(-1)[1]) : 0;
      hint.textContent = `Wall: click points · double-click or Enter to finish · Esc to cancel · Shift free · Ctrl straight${seg ? ` · ${seg.toFixed(2)} m` : ''}`;
    };
    function start() {
      if (pts) return;
      pts = []; hover = null;
      viewport.scene.add(line); hint.hidden = false; show();
      document.body.classList.add('st-drawing');
    }
    async function finish() {
      const p = pts; stop();
      if (!p || p.length < 2) return;
      const [ox, oz] = p[0], closed = p.length > 3 && Math.hypot(p.at(-1)[0] - ox, p.at(-1)[1] - oz) < 0.3;
      const points = (closed ? p.slice(0, -1) : p).map(([x, z]) => [r2(x - ox), r2(z - oz)]);
      await add({ op: 'add', type: 'wall', name: 'wall', points, closed, position: [ox, 0, oz] }, 'wall');
    }
    function stop() { pts = null; viewport.scene.remove(line); hint.hidden = true; document.body.classList.remove('st-drawing'); }
    let down = null;
    viewport.canvas.addEventListener('pointerdown', (e) => { if (pts) down = { x: e.clientX, y: e.clientY }; }, true);
    viewport.canvas.addEventListener('pointerup', (e) => {
      if (!pts || e.button !== 0) return;
      e.stopImmediatePropagation(); // (no camera aiming while drawing)
      if (!down || Math.hypot(e.clientX - down.x, e.clientY - down.y) > 4) return; // a drag orbits as usual
      const q = ground(e);
      if (!q) return;
      const last = pts.at(-1);
      if (!last || Math.hypot(q[0] - last[0], q[1] - last[1]) > 0.05) pts.push(q);
      show();
    }, true);
    viewport.canvas.addEventListener('pointermove', (e) => { if (pts) { hover = ground(e); show(); } });
    viewport.canvas.addEventListener('dblclick', (e) => { if (pts) { e.stopImmediatePropagation(); finish(); } }, true);
    addEventListener('keydown', (e) => {
      if (!pts) return;
      if (e.key === 'Enter') { e.preventDefault(); e.stopImmediatePropagation(); finish(); }
      if (e.key === 'Escape') { e.preventDefault(); e.stopImmediatePropagation(); stop(); }
      if (e.key === 'Backspace') { e.preventDefault(); e.stopImmediatePropagation(); pts.pop(); show(); }
    }, true);
    return { start, get on() { return !!pts; } };
  })();

  // ---------- moving and turning: plan drags, R, exact numbers ----------
  const DEG = Math.PI / 180;
  // put an object where it is now drawn (an animated one gets a key at the playhead, like the gizmo does)
  function place(id, { position, rotation }, label) {
    const o = store.object(id); if (!o) return;
    const anim = o.anim?.length;
    return store.op({ ...(anim ? { op: 'anim.key', t: +store.state.time.toFixed(3) } : { op: 'update' }), id, position, rotation }, label)
      .catch((e) => toast(e.message, { kind: 'error' }));
  }
  const yawOf = (o) => o.rotation[1];
  function turn(id, by) {
    const o = store.object(id); if (!o) return;
    let y = Math.round((yawOf(o) + by) * 100) / 100;
    y = ((y + 180) % 360 + 360) % 360 - 180; // (kept within -180..180)
    place(id, { position: o.position, rotation: [o.rotation[0], y, o.rotation[2]] }, `turn ${id}`);
  }
  // R turns the selection 15° (Shift: back), in any view
  addEventListener('keydown', (e) => {
    if (e.ctrlKey || e.metaKey || e.altKey || e.key.toLowerCase() !== 'r' || e.target.closest?.('input, select, textarea')) return;
    const id = store.state.selection; if (!id) return;
    e.preventDefault(); turn(id, e.shiftKey ? -15 : 15);
  });
  // What moves when it's dragged on the plan: people, character cards and props - not the set (see below).
  const box = new THREE.Box3(), size = new THREE.Vector3();
  function planDraggable(id) {
    const o = store.object(id); if (!o || o.loc) return false;
    if (['wall', 'plane', 'roof', 'light'].includes(o.type) || (o.type === 'card' && o.params.lit === false)) return false;
    const m = viewport.meshes.get(id); if (!m) return false;
    box.setFromObject(m.mesh).getSize(size);
    return Math.max(size.x, size.z) <= 6;
  }
  window.canvas.planDraggable = planDraggable;   // (the plan's camera and turn dots use it too: app/plan-tools.js)
  // In the plan, dragging an object moves it across the floor (5 cm steps, Shift free); Alt+drag turns it
  // (15° steps, Shift free). Dragging empty space pans the plan as before.
  (() => {
    const ray = new THREE.Raycaster(), floor = new THREE.Plane(new THREE.Vector3(0, 1, 0), 0);
    const ndc = (e) => { const r = viewport.canvas.getBoundingClientRect(); return new THREE.Vector2(((e.clientX - r.left) / r.width) * 2 - 1, -((e.clientY - r.top) / r.height) * 2 + 1); };
    const ground = (e) => { ray.setFromCamera(ndc(e), viewport.planCam); return ray.ray.intersectPlane(floor, new THREE.Vector3()); };
    let drag = null;
    viewport.canvas.addEventListener('pointerdown', (e) => {
      if (store.state.view !== 'plan' || e.button !== 0 || draw.on || viewport.gizmo.axis) return;
      ray.setFromCamera(ndc(e), viewport.planCam);
      // the topmost person, character card or prop under the pointer. The set itself - walls, floors, roofs, lamps,
      // backdrops and anything over 6 m across (an imported map) - never drags here: a drag over it pans the plan.
      const id = ray.intersectObjects(viewport._pickables(), false).map((x) => { let o = x.object; while (o && !o.userData.id) o = o.parent; return o?.userData.id; })
        .find((i) => i && planDraggable(i));
      if (!id || !store.object(id)) return;
      const mesh = viewport.meshes.get(id).mesh, p0 = ground(e);
      if (!p0) return;
      store.set({ selection: id });
      drag = { id, mesh, p0, pos0: mesh.position.clone(), yaw0: mesh.rotation.y, turn: e.altKey, moved: false, x: e.clientX, y: e.clientY, pid: e.pointerId };
      if (viewport.collide?.on) viewport.collide.begin(id);
      viewport.planOrbit.enabled = false; viewport.dragging = true;
    }, true);
    addEventListener('pointermove', (e) => {
      if (!drag) return;
      if (!drag.moved && Math.hypot(e.clientX - drag.x, e.clientY - drag.y) < 4) return;
      drag.moved = true;
      const p = ground(e); if (!p) return;
      const { mesh, p0, pos0 } = drag;
      if (drag.turn) {
        const a0 = Math.atan2(p0.x - pos0.x, p0.z - pos0.z), a1 = Math.atan2(p.x - pos0.x, p.z - pos0.z);
        let y = (drag.yaw0 + a1 - a0) / DEG;
        if (!e.shiftKey) y = Math.round(y / 15) * 15;
        mesh.rotation.y = y * DEG;
        hint(`Turn ${(((y + 180) % 360 + 360) % 360 - 180).toFixed(e.shiftKey ? 1 : 0)}°`);
      } else {
        const step = e.shiftKey ? 0.001 : 0.05;
        let x = Math.round((pos0.x + p.x - p0.x) / step) * step, z = Math.round((pos0.z + p.z - p0.z) / step) * step;
        // (Solid: it stops at walls, counters, people and props instead of going through - from where it is now)
        if (viewport.collide?.on) { const q = viewport.collide.solve(drag.id, mesh.position, new THREE.Vector3(x, pos0.y, z), { keep: true }); x = q.x; z = q.z; }
        mesh.position.set(x, pos0.y, z);
        hint(`x ${x.toFixed(2)} m · z ${z.toFixed(2)} m`);
      }
    });
    addEventListener('pointerup', () => {
      if (!drag) return;
      const d = drag; drag = null;
      viewport.collide?.end();
      viewport.planOrbit.enabled = store.state.view === 'plan'; viewport.dragging = false;
      hint(null);
      if (!d.moved) return;
      const o = store.object(d.id); if (!o) return;
      const r3 = (v) => Math.round(v * 1000) / 1000;
      place(d.id, { position: d.mesh.position.toArray().map(r3), rotation: [o.rotation[0], Math.round((d.mesh.rotation.y / DEG) * 100) / 100, o.rotation[2]] }, d.turn ? `turn ${d.id}` : `move ${d.id}`);
    });
    const tip = h('div.cc-panel.st-hint.st-readout', { hidden: true });
    document.body.append(tip);
    function hint(t) { tip.hidden = !t; if (t) tip.textContent = t; }
  })();

  // ---------- Objects: every object in the scene, by kind (the layer list) ----------
  // click = select it (the Object panel below shows it, the gizmo is on it), double-click = frame it; the eye = in or
  // off this shot; the lock = can't be selected in the views (the town under everything is locked by default)
  const objP = panel({ title: 'Objects', collapsible: true });
  objP.classList.add('st-objs');
  const objFilter = h('input.cc-input.st-objs-find', { placeholder: 'Find…', spellcheck: false, onInput: () => listObjects(true) });
  objFilter.addEventListener('keydown', (e) => e.stopPropagation());
  const objList = h('div.st-objs-list');
  const solidBox = h('input', { type: 'checkbox', onChange: () => { if (viewport.collide) viewport.collide.on = solidBox.checked; } });
  solidBox.checked = viewport.collide?.on ?? true;
  objP.body.append(objFilter, h('label.st-objs-solid', { title: "Solid: people and props moved by hand stop at walls, counters and each other instead of going through (paper, banners and strings don't count). Typed positions are taken as they are." }, solidBox, 'Solid (no clipping)'), objList);
  document.getElementById('dock').prepend(objP);   // (first in the column)
  const KINDS = [['People', (o) => o.type === 'person'], ['Props', (o) => !['person', 'model', 'wall', 'roof', 'plane', 'light', 'card'].includes(o.type)],
    ['Cards', (o) => o.type === 'card'], ['Lights', (o) => o.type === 'light'], ['Set', () => true]];
  const ICON = { person: 'person', model: 'cube', light: 'sun', card: 'image', wall: 'columns', plane: 'square', roof: 'columns' };
  const locked = (o) => o.locked ?? (o.type === 'model' && (o.params?.h > 6 || o.params?.crop));
  let listed = '';
  function listObjects(force) {
    const d = store.doc; if (!d) return;
    const sh = d.shots?.find((s) => s.id === d.shot), off = new Set(sh?.off || []);
    const q = objFilter.value.trim().toLowerCase();
    const sig = JSON.stringify([d.objects.map((o) => [o.id, o.name, o.type, o.locked]), [...off], store.state.selection, q]);
    if (sig === listed && !force) return;
    listed = sig;
    const seen = new Set(), groups = [];
    for (const [title, test] of KINDS) {
      const items = d.objects.filter((o) => !seen.has(o.id) && test(o) && (!q || `${o.name} ${o.id}`.toLowerCase().includes(q)));
      items.forEach((o) => seen.add(o.id));
      if (items.length) groups.push(h('div.st-objs-group', {}, `${title} · ${items.length}`), ...items.map((o) => {
        const isOff = off.has(o.id), lk = locked(o);
        return h('div.st-objs-row', { class: `${store.state.selection === o.id ? 'is-sel' : ''}${isOff ? ' is-off' : ''}`, title: `${o.name} (${o.type})
Click: select · double-click: frame it`,
            onClick: () => store.set({ selection: o.id }), onDblclick: () => window.canvas.viewport.frame(o.id) },
          icon(ICON[o.type] || 'cube'), h('span.st-objs-name', {}, o.name || o.id),
          h('button.st-objs-btn', { type: 'button', title: isOff ? 'Off this shot: click to put it in' : 'In this shot: click to take it out',
            onClick: (e) => { e.stopPropagation(); store.op({ op: 'shot.off', ids: [o.id], off: !isOff }, isOff ? 'in this shot' : 'off this shot').catch((er) => toast(er.message, { kind: 'error' })); } }, icon(isOff ? 'eyeOff' : 'eye')),
          h('button.st-objs-btn', { type: 'button', class: lk ? 'is-on' : '', title: lk ? 'Locked: not picked in the views (select it here). Click to unlock' : 'Click to lock: not picked in the views',
            onClick: (e) => { e.stopPropagation(); set(o.id, { locked: !lk }, lk ? 'unlocked' : 'locked'); } }, icon(lk ? 'lock' : 'unlock')));
      }));
    }
    objList.replaceChildren(...(groups.length ? groups : [h('div.st-objs-empty', {}, q ? 'Nothing by that name' : 'No objects yet - Add puts them in')]));
    objList.querySelector('.is-sel')?.scrollIntoView({ block: 'nearest' });
  }
  store.on('doc', () => listObjects());
  store.on('state', (c) => { if ('selection' in c) listObjects(); });
  setTimeout(() => listObjects(true), 0);
  window.canvas.isLocked = (id) => { const o = store.object(id); return !!o && !!locked(o); };

  // ---------- inspector: the selected object ----------
  const insp = panel({ title: 'Object', collapsible: true });
  insp.classList.add('st-insp');
  insp.hidden = true;
  document.getElementById('dock').append(insp);
  const set = (id, patch, label) => store.op({ op: 'update', id, ...patch }, label).catch((e) => toast(e.message, { kind: 'error' }));
  let shown = '';
  function inspect() {
    const o = store.state.selection && store.object(store.state.selection);
    insp.hidden = !o;
    if (!o) { shown = ''; return; }
    const shotNow = store.doc.shots.find((s) => s.id === store.doc.shot);
    const sig = JSON.stringify([o.id, o.type, o.params, o.color, o.texture, o.position, o.rotation, shotNow?.id, shotNow?.off, shotNow?.hold, store.doc.objects.map((x) => x.name).join()]);
    if (sig === shown && insp.contains(document.activeElement)) return; // (don't rebuild under a field being typed in)
    shown = sig;
    const p = o.params, rows = [];
    // (metric: lengths in metres, turns in degrees - every field shows its unit)
    const at3 = (i) => affix(number({ value: o.position[i], step: 0.05, precision: 2, title: ['x (east)', 'y (height)', 'z (south)'][i], onChange: (v) => { const pos = [...o.position]; pos[i] = v; place(o.id, { position: pos, rotation: o.rotation }, 'position'); } }), 'm');
    rows.push(row('Position', at3(0), at3(1), at3(2)));
    rows.push(row('Turn', affix(number({ value: o.rotation[1], step: 5, precision: 1, onChange: (v) => place(o.id, { position: o.position, rotation: [o.rotation[0], v, o.rotation[2]] }, 'turn') }), '°')));
    const sc3 = (i) => number({ value: o.scale[i], step: 0.05, min: 0.01, precision: 2, title: ['width (x)', 'height (y)', 'depth (z)'][i] + ' - 1 = its own size',
      onChange: (v) => { const sc = [...o.scale]; sc[i] = v; set(o.id, { scale: sc }, 'scale'); } });
    rows.push(row('Scale', sc3(0), sc3(1), sc3(2)));
    const tilt3 = (i) => affix(number({ value: o.rotation[i], step: 5, precision: 1, title: ['tilt forward / back (x)', '', 'lean left / right (z)'][i],
      onChange: (v) => { const r = [...o.rotation]; r[i] = v; place(o.id, { position: o.position, rotation: r }, 'tilt'); } }), '°');
    if (o.type !== 'person') rows.push(row('Tilt', tilt3(0), tilt3(2)));
    rows.push(row('Colour', color({ value: o.color, onChange: (v) => set(o.id, { color: v }, 'colour') })));
    // a person, a character card or a prop: in this shot, or off set for it (left out of its camera and prompts).
    // Not the set itself: walls, floors, roofs, lights, backdrop / sky cards.
    const isSet = ['wall', 'plane', 'roof', 'light'].includes(o.type) || (o.type === 'card' && p.lit === false);
    if (!isSet && shotNow) {
      rows.push(row('In this shot', segmented({
        title: `On: in ${shotNow.name}'s camera and prompts. Off: off set for ${shotNow.name} only (faded on the board).`,
        options: [{ value: 'on', label: 'On' }, { value: 'off', label: 'Off' }],
        value: shotNow.off?.includes(o.id) ? 'off' : 'on',
        onChange: (v) => store.op({ op: 'shot.off', id: o.id, off: v === 'off' }, v === 'off' ? 'off set' : 'on set')
          .then(() => toast(v === 'off' ? `${o.name} is off set for ${shotNow.name}` : `${o.name} is in ${shotNow.name}`))
          .catch((e) => toast(e.message, { kind: 'error' })),
      })));
    }
    // a prop held in this shot: it follows its holder the way it's held (Blocking Board: shots[].hold)
    const cast = o.type === 'person' || (o.type === 'card' && p.lit !== false && (p.h || 0) * (o.scale?.[1] || 1) >= 1);
    if (!isSet && !cast && shotNow) {
      const hd = shotNow.hold?.[o.id], holders = store.doc.objects.filter((x) => x.type === 'person' || (x.type === 'card' && x.params.lit !== false && (x.params.h || 0) * (x.scale?.[1] || 1) >= 1));
      const hold = (patch, label) => store.op({ op: 'shot.hold', id: o.id, ...patch }, label).catch((e) => toast(e.message, { kind: 'error' }));
      if (holders.length) rows.push(row('Held by', select({
        title: `Who holds it in ${shotNow.name} (this shot only). Held, it follows them.`,
        options: [{ value: '', label: 'Nobody' }, ...holders.map((x) => ({ value: x.id, label: x.name }))],
        value: hd?.by || '',
        onChange: (v) => hold({ by: v || null }, v ? 'hold' : 'let go'),
      })));
      if (hd) {
        rows.push(row('How', select({ options: Object.entries(HOLD_MODES).map(([value, m]) => ({ value, label: m.label })), value: hd.how, onChange: (v) => hold({ by: hd.by, how: v }, 'hold how') })));
        rows.push(h('div.st-insp-name', {}, `Follows ${store.object(hd.by)?.name || hd.by} in this shot; its position below is where it stands when not held.`));
      }
    }
    if (o.type === 'person') rows.push(row('Look', select({
      title: 'Mannequin: the jointed figure (the default). Simple box: a box body with a drawn face, for crowds',
      options: [{ value: 'high', label: 'Mannequin' }, { value: 'low', label: 'Simple box' }],
      value: p.detail ?? store.doc.env.people ?? 'high',
      onChange: (v) => set(o.id, { detail: v }, 'person look'),
    })));
    if (o.type === 'person') rows.push(row('Pose', select({
      title: 'Carry: hands together in front, for a held prop. Push: arms forward, for a cart.',
      options: Object.keys(PERSON_POSES).map((value) => ({ value, label: value.replace(/-/g, ' ') })),
      value: p.pose || 'stand',
      onChange: (v) => set(o.id, { pose: v }, 'pose'),
    })));
    if (o.type !== 'card' && o.type !== 'light' && o.type !== 'model' && o.type !== 'person') {
      const tx = o.texture;
      rows.push(row('Texture',
        button({ label: tx ? tx.file.replace(/-[0-9a-f]{8}\.\w+$/, '') : 'Choose…', kind: 'ghost', title: 'A picture for its surfaces (or drop one on the object)', onClick: async () => { const f = await pick(); if (f) texture(o.id, f); } }),
        tx ? button({ icon: 'close', kind: 'ghost', title: 'Remove the texture', onClick: () => set(o.id, { texture: null }, 'no texture') }) : null));
      if (tx) rows.push(row('Tile size', affix(number({ value: tx.scale, min: 0.05, step: 0.25, title: 'How much of the surface one copy of the picture covers', onChange: (v) => set(o.id, { texture: { ...tx, scale: v } }, 'texture size') }), 'm')));
    }
    const num = (label, key, { value: fallback, ...opts } = {}, unit = 'm') => { const f = number({ value: p[key] ?? fallback ?? 0, step: 0.05, min: 0, ...opts, onChange: (v) => set(o.id, { [key]: v }, label) });
      rows.push(row(label, unit ? affix(f, unit) : f)); };
    if (o.type === 'wall') {
      num('Height', 'h'); num('Thickness', 't', { step: 0.01 });
      rows.push(row('Openings', button({ label: '+ Door', kind: 'ghost', onClick: () => opening(o, 0) }), button({ label: '+ Window', kind: 'ghost', onClick: () => opening(o, 0.9) })));
      if (p.openings?.length) rows.push(row('', button({ label: `Clear ${p.openings.length}`, kind: 'ghost', onClick: () => set(o.id, { openings: [] }, 'openings') })));
      if (p.openings?.some((x) => x.sill > 0)) rows.push(row('Window pic',
        button({ label: p.glass ? p.glass.replace(/-[0-9a-f]{8}\.\w+$/, '') : 'Glass', kind: 'ghost', title: 'A picture for every window pane in this wall (else plain glass)',
          onClick: async () => { const f = await pick(); if (!f) return; try { const up = await upload(f); set(o.id, { glass: up.file }, 'window picture'); } catch (e) { toast(e.message, { kind: 'error' }); } } }),
        p.glass ? button({ icon: 'close', kind: 'ghost', title: 'Plain glass', onClick: () => set(o.id, { glass: null }, 'plain glass') }) : null));
    }
    if (o.type === 'roof') {
      rows.push(row('Kind', select({ options: ['gable', 'shed', 'flat'], value: p.kind, onChange: (v) => set(o.id, { kind: v }, 'roof kind') })));
      num('Width', 'w'); num('Depth', 'd'); if (p.kind !== 'flat') num('Rise', 'rise'); else num('Thickness', 't', { step: 0.01 }); num('Overhang', 'overhang');
    }
    if (o.type === 'person') num('Height', 'h', { value: Math.round(objectHeight({ ...o, params: { ...p, pose: 'stand' } }) * 100) / 100, step: 0.01, title: 'Standing height' });
    if (o.type === 'person') {
      // (as on the first Blocking Board) Lift raises them off the floor - on a step, a box, a counter; Size scales how they
      // look without changing their real height (Height is what goes into the prompts)
      rows.push(row('Lift', affix(number({ value: Math.round(o.position[1] * 100), step: 1, precision: 0, title: 'Raise them off the floor (on a step, a box, a counter)',
        onChange: (v) => place(o.id, { position: [o.position[0], v / 100, o.position[2]], rotation: o.rotation }, 'lift') }), 'cm')));
      rows.push(row('Size', affix(number({ value: Math.round((o.scale[1] || 1) * 100), min: 10, step: 1, precision: 0, title: 'How big they look (their Height for the prompts stays)',
        onChange: (v) => set(o.id, { scale: [v / 100, v / 100, v / 100] }, 'size') }), '%'),
        button({ label: 'Reset', kind: 'ghost', title: 'Back on the floor at 100%', onClick: () => { set(o.id, { scale: [1, 1, 1] }, 'size reset'); place(o.id, { position: [o.position[0], 0, o.position[2]], rotation: o.rotation }, 'lift reset'); } })));
    }
    if (o.type === 'model') {
      // a whole town as one model: show only its part round this scene's cameras (the rest isn't drawn anywhere)
      rows.push(row('Show', segmented({ title: 'Draw the whole model, or only what the shot cameras see and the room round the people (lighter, and a cleaner plan)',
        options: [{ value: 'all', label: 'Whole model' }, { value: 'crop', label: 'Around the scene' }], value: p.crop ? 'crop' : 'all',
        onChange: async (v) => set(o.id, { crop: v === 'crop' ? await aroundScene(o.id, p.crop?.r) : null }, 'model crop') })));
      if (p.crop) rows.push(row('Around people', affix(number({ value: p.crop.r, min: 1, step: 1, precision: 0, title: 'Also drawn: everything this close to the people (for the plan)',
        onChange: (v) => set(o.id, { crop: { ...p.crop, r: v } }, 'crop radius') }), 'm'),
        button({ label: 'Re-pick', kind: 'ghost', title: 'Pick again what the shot cameras see (after reframing them)', onClick: async () => set(o.id, { crop: await aroundScene(o.id, p.crop.r) }, 'crop re-picked') })));
    }
    if (o.type === 'card') {
      num('Height', 'h');
      rows.push(row('Faces', select({ options: [{ value: 'camera', label: 'Camera' }, { value: 'fixed', label: 'Fixed' }], value: p.face, onChange: (v) => set(o.id, { face: v }, 'card faces') })));
      rows.push(row('Lit', select({ options: [{ value: 'yes', label: 'By the lights' }, { value: 'no', label: 'As it is (sky, backdrop)' }], value: p.lit === false ? 'no' : 'yes', onChange: (v) => set(o.id, { lit: v === 'yes' }, 'card lit') })));
    }
    if (o.type === 'light') {
      rows.push(row('Light', segmented({ title: 'Switch the light on or off (its settings are kept)', options: [{ value: 'on', label: 'On' }, { value: 'off', label: 'Off' }],
        value: p.on === false ? 'off' : 'on', onChange: (v) => set(o.id, { on: v === 'on' }, v === 'on' ? 'light on' : 'light off') })));
      rows.push(row('Kind', select({ options: [{ value: 'point', label: 'Point' }, { value: 'spot', label: 'Spot' }], value: p.kind, onChange: (v) => set(o.id, { kind: v }, 'light kind') })));
      num('Power', 'power', { step: 0.1 }, ''); num('Range', 'range', { step: 0.5 });
      if (p.kind === 'spot') num('Angle', 'angle', { step: 1, max: 85 }, '°');
    }
    insp.setTitle?.(o.name);
    insp.body.replaceChildren(h('div.st-insp-name.cc-mono', {}, `${o.name} · ${o.type}`), ...rows);
  }
  // a door (sill 0) or a window (sill 0.9 m) in the middle of the wall's first segment that has room
  function opening(o, sill) {
    const pts = o.params.closed ? [...o.params.points, o.params.points[0]] : o.params.points;
    const used = (o.params.openings || []).length;
    const segs = pts.slice(1).map((b, i) => ({ i, len: Math.hypot(b[0] - pts[i][0], b[1] - pts[i][1]) })).filter((s) => s.len > 1.2);
    const s = segs[used % Math.max(1, segs.length)];
    if (!s) return toast('This wall is too short for an opening', { kind: 'error' });
    const op = sill ? { seg: s.i, at: r2(s.len / 2), w: 1.2, h: 1.2, sill } : { seg: s.i, at: r2(s.len / 2), w: 0.9, h: 2.1, sill: 0 };
    set(o.id, { openings: [...(o.params.openings || []), op] }, sill ? 'window' : 'door');
  }
  store.on('state', (c) => { if ('selection' in c) inspect(); });
  store.on('doc', () => inspect());

  // ---------- plan view: the floor-plan picture under the set ----------
  try { const c = parseFloat(localStorage.getItem('bb.planCut')); if (Number.isFinite(c)) store.set({ planCut: c }); } catch {}
  const planP = panel({ title: 'Floor plan', collapsible: true });
  planP.classList.add('st-plan');
  document.getElementById('dock').append(planP);   // (after Objects and Object)
  const env = (patch, label) => store.op({ op: 'env', ...patch }, label).catch((e) => toast(e.message, { kind: 'error' }));
  let planSig = '';
  function planPanel() {
    planP.hidden = store.state.view !== 'plan';
    if (planP.hidden) return;
    const pl = store.doc?.env?.plan;
    const sig = JSON.stringify(pl || null);
    if (sig === planSig && planP.contains(document.activeElement)) return;
    planSig = sig;
    const choose = async () => {
      const f = await pick(); if (!f) return;
      try { const up = await upload(f); env({ plan: { file: up.file, w: pl?.w ?? 12, x: pl?.x ?? 0, z: pl?.z ?? 0, rot: pl?.rot ?? 0, opacity: pl?.opacity ?? 0.6 } }, 'floor plan'); }
      catch (e) { toast(e.message, { kind: 'error' }); }
    };
    const n = (label, key, opts, unit = 'm') => { const f = number({ value: pl[key], ...opts, onChange: (v) => env({ plan: { ...pl, [key]: v } }, `floor plan ${key}`) }); return row(label, unit ? affix(f, unit) : f); };
    const cutRow = row('Cut height', affix(number({ value: store.state.planCut ?? 1.2, min: 0, max: 10, step: 0.1, title: 'The plan slices the set at this height so doors and windows show (0 = no cut)',
      onChange: (v) => { store.set({ planCut: v }); try { localStorage.setItem('bb.planCut', String(v)); } catch {} } }), 'm'));
    planP.body.replaceChildren(cutRow, ...(pl ? [
      row('Picture', button({ label: 'Replace…', kind: 'ghost', onClick: choose }), button({ icon: 'close', kind: 'ghost', title: 'Remove the floor plan', onClick: () => env({ plan: null }, 'no floor plan') })),
      n('Width', 'w', { min: 0.1, step: 0.5 }), n('Centre x', 'x', { step: 0.25 }), n('Centre z', 'z', { step: 0.25 }), n('Turn', 'rot', { step: 1 }, '°'),
      n('Opacity', 'opacity', { min: 0, max: 1, step: 0.05 }, ''),
      h('div.st-tip', {}, "Set Width to the plan's real width, then Add → Wall and click along its walls."),
    ] : [
      row('Picture', button({ label: 'Choose…', kind: 'ghost', title: 'A floor plan or sketch to trace walls over', onClick: choose })),
      h('div.st-tip', {}, 'Drop a floor plan here or choose one, then trace its walls with Add → Wall.'),
    ]));
  }
  planP.addEventListener('dragover', (e) => e.preventDefault());
  planP.addEventListener('drop', async (e) => {
    e.preventDefault();
    const f = [...e.dataTransfer.files].find(isImage); if (!f) return;
    const pl = store.doc?.env?.plan;
    try { const up = await upload(f); env({ plan: { ...(pl || { w: 12, x: 0, z: 0, rot: 0, opacity: 0.6 }), file: up.file } }, 'floor plan'); } catch (err) { toast(err.message, { kind: 'error' }); }
  });
  store.on('state', (c) => { if ('view' in c) planPanel(); });
  store.on('doc', () => planPanel());
  planPanel();

  // ---------- pictures dropped on the set ----------
  const hitAt = (e) => {
    const r = viewport.canvas.getBoundingClientRect(), ray = new THREE.Raycaster();
    ray.setFromCamera(new THREE.Vector2(((e.clientX - r.left) / r.width) * 2 - 1, -((e.clientY - r.top) / r.height) * 2 + 1), viewport.activeCam);
    const hit = ray.intersectObjects(viewport._pickables(), false)[0];
    const floor = ray.ray.intersectPlane(new THREE.Plane(new THREE.Vector3(0, 1, 0), 0), new THREE.Vector3());
    return { id: hit?.object.userData.id, floor };
  };
  async function dropImages(e, files) {
    const { id, floor } = hitAt(e);
    const o = id && store.object(id);
    if (o && !['card', 'light', 'person', 'model'].includes(o.type)) return texture(o.id, files[0]);
    let x = floor ? floor.x : at()[0];
    for (const f of files) { await addCard(f, [r2(x), 0, r2(floor ? floor.z : at()[2])]); x += 1.2; }
  }

  return { dropImages, isImage, draw, inspect };
}
