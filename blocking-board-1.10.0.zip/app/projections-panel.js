// Blocking Board: the Projections panel (in the settings column) - the film's 360s and location pictures that paint
// the set (app/projections.js). Each one: on / off, where it was taken (x, y, z, heading, pitch, roll; a photo's lens),
// "Use the camera" (it takes the shot camera's spot and direction: line a picture up by framing the shot camera on
// it first), "Go there" (keys the shot camera at its spot). Add 360 / Add picture upload a file to textures/ and place
// it at the shot camera. The list is the film's: every scene and every artist sees the same.
import * as THREE from 'three';
import { h, icon, toast, panel, row, number, affix, button } from './ui/kit.js';
import { store } from './store.js';
import { fovToLens, lensToFov, sampleCamera } from '/core/curves.js';

const DEG = Math.PI / 180;

export function mountProjectionsPanel(viewport) {
  const proj = viewport.proj; if (!proj) return;
  const P = panel({ title: 'Projections', collapsible: true, collapsed: true });
  P.classList.add('st-proj');
  document.getElementById('dock').append(P);
  let open = null;   // the item being edited

  const camNow = () => { const d = store.doc; return d && sampleCamera(d.timeline, store.state.time); };
  // the shot camera as a projection's spot: heading 0 = looking along -z, 90 = along +x
  function fromCamera() {
    const c = camNow(); if (!c) return null;
    const f = new THREE.Vector3(...c.target).sub(new THREE.Vector3(...c.position)).normalize();
    const vfov = c.fov * DEG, asp = store.doc.meta.width / store.doc.meta.height, hfov = 2 * Math.atan(Math.tan(vfov / 2) * asp);
    return { x: +c.position[0].toFixed(3), y: +c.position[1].toFixed(3), z: +c.position[2].toFixed(3), heading: +(Math.atan2(f.x, -f.z) / DEG).toFixed(1),
      pitch: +(Math.asin(Math.max(-1, Math.min(1, f.y))) / DEG).toFixed(1), roll: +(-(c.roll || 0)).toFixed(1), lens: +(18 / Math.tan(hfov / 2)).toFixed(1) };
  }
  async function goThere(p) {
    const sh = store.doc.shots.find((s) => s.id === store.doc.shot);
    if (sh?.lock) return toast(`The camera of ${sh.name} is locked`);
    const y = p.heading * DEG, pt = (p.pitch || 0) * DEG, f = [Math.sin(y) * Math.cos(pt), Math.sin(pt), -Math.cos(y) * Math.cos(pt)];
    const asp = store.doc.meta.width / store.doc.meta.height;
    // a photo: the same view across (its lens is across a 36 mm frame); a 360: keep the lens
    const fov = p.kind === 'photo' ? 2 * Math.atan(Math.tan(Math.atan(18 / (p.lens || 24))) / asp) / DEG : camNow()?.fov || 40;
    const tl = store.doc.timeline, t0 = store.state.time, near = tl.keys.find((k) => Math.abs(k.t - t0) <= 0.5 / (tl.fps || 24));
    try {
      await store.op({ op: 'key.add', t: near ? near.t : +t0.toFixed(3), position: [p.x, p.y, p.z], target: [p.x + f[0] * 3, p.y + f[1] * 3, p.z + f[2] * 3],
        fov: Math.max(lensToFov(300), Math.min(lensToFov(8), fov)), roll: -(p.roll || 0) }, `camera at ${p.name}`);
    } catch (e) { toast(e.message, { kind: 'error' }); }
  }
  const update = (id, patch, label) => proj.save(proj.items.map((x) => (x.id === id ? { ...x, ...patch } : x)), label);
  async function add(kind) {
    const input = h('input', { type: 'file', accept: 'image/png,image/jpeg,image/webp' });
    input.onchange = async () => {
      const f = input.files?.[0]; if (!f) return;
      const r = await fetch(`/api/texture?name=${encodeURIComponent(f.name)}`, { method: 'POST', body: f }).then((x) => x.json()).catch(() => null);
      if (!r?.ok) return toast(r?.error || 'Could not upload the picture', { kind: 'error' });
      const at = fromCamera() || { x: 0, y: 1.5, z: 0, heading: 0, pitch: 0, roll: 0, lens: 24 };
      const id = `${kind === 'photo' ? 'pic' : 'pano'}-${Date.now().toString(36)}`;
      const item = { id, name: f.name.replace(/\.[^.]+$/, ''), kind, file: r.file, ...at, on: true };
      if (await proj.save([...proj.items, item], `${kind === 'photo' ? 'Picture' : '360'} added at the shot camera - line it up below`)) { open = id; render(); }
    };
    input.click();
  }

  function render() {
    const items = proj.items;
    const rows = items.map((p) => {
      const isOpen = open === p.id;
      const head = h('div.st-proj-row', { class: isOpen ? 'is-open' : '', onClick: () => { open = isOpen ? null : p.id; render(); } },
        icon(p.kind === 'photo' ? 'image' : 'aim'), h('span.st-proj-name', { title: p.name }, p.name),
        h('button.st-objs-btn', { type: 'button', title: p.on ? 'Painting the set: click to turn it off' : 'Off: click to paint with it', class: p.on ? 'is-on' : '',
          onClick: (e) => { e.stopPropagation(); update(p.id, { on: !p.on }); } }, icon(p.on ? 'eye' : 'eyeOff')));
      if (!isOpen) return head;
      const n = (label, key, step, unit, opts = {}) => row(label, affix(number({ value: p[key], step, precision: step < 1 ? 2 : 1, ...opts, onChange: (v) => update(p.id, { [key]: v }) }), unit));
      return h('div.st-proj-item', {}, head,
        row('Where', ...['x', 'y', 'z'].map((k) => affix(number({ value: p[k], step: 0.05, precision: 2, title: { x: 'east', y: 'height', z: 'south' }[k], onChange: (v) => update(p.id, { [k]: v }) }), 'm'))),
        n('Heading', 'heading', 0.5, '°'), n('Pitch', 'pitch', 0.5, '°'), n('Roll', 'roll', 0.5, '°'),
        p.kind === 'photo' ? n('Lens', 'lens', 0.5, 'mm', { min: 4, title: 'Across a 36 mm frame' }) : null,
        row('', button({ label: 'Use the camera', kind: 'ghost', title: 'It takes the shot camera\'s spot and direction (frame the shot camera on the picture first)', onClick: () => { const c = fromCamera(); if (c) update(p.id, p.kind === 'photo' ? c : { ...c, lens: p.lens }, `${p.name} moved to the shot camera`); } }),
          button({ label: 'Go there', kind: 'ghost', title: 'Key the shot camera at its spot', onClick: () => goThere(p) })),
        row('', button({ label: 'Remove', kind: 'ghost', onClick: () => { if (confirmRemove(p)) proj.save(proj.items.filter((x) => x.id !== p.id), `${p.name} removed`); } })));
    });
    P.body.replaceChildren(
      h('div.st-proj-hint', {}, items.length ? `${items.filter((x) => x.on).length} of ${items.length} painting the set · the look is picked under the camera (Set)` : 'No 360s or pictures yet'),
      ...rows,
      row('', button({ label: 'Add 360…', kind: 'ghost', title: 'An equirectangular (2:1) 360 picture, placed at the shot camera', onClick: () => add('360') }),
        button({ label: 'Add picture…', kind: 'ghost', title: 'A normal picture of a location, projected from the shot camera', onClick: () => add('photo') })));
  }
  const confirmRemove = (p) => window.confirm?.(`Remove ${p.name} from the film's projections?`) ?? true;
  proj.on(render);
  render();
}
