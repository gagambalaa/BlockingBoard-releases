// Blocking Board: projection mapping - the film's 360s and location pictures painted onto the 3D set (as on the first
// Blocking Board, v20). The list is the film's (library/_projections.json, GET / POST /api/projections, shared through
// KAI); each item is a 360 (equirectangular) or a photo, placed where it was taken: x, y, z in the set's own axes
// (metres, y up), heading (0 looks along -z, 90 along +x), pitch, roll (degrees), and for a photo its lens (mm across a
// 36 mm frame) and aspect.
//
// The look (per PC, `bb.look`): Grey (the set as modelled), Painted (every surface takes the colour of the nearest
// projection that sees it - a depth cube per projection keeps a wall from being painted with what's behind it), Auto
// (Painted, and the exact 360 when the camera stands at a 360's spot) and 360 view (the 360 exactly as seen from the
// camera). The plan stays the blueprint. Up to SLOTS projections at once: the ones nearest the camera.
//
// Only imported models (the set) are painted; people, props, walls and cards keep their own look.
import * as THREE from 'three';
import { store } from './store.js';
import { toast } from './ui/kit.js';

const SLOTS = 6, FAR = 100, DEG = Math.PI / 180;
const read = (k) => { try { return localStorage.getItem(k); } catch { return null; } };
const write = (k, v) => { try { localStorage.setItem(k, v); } catch {} };
export const LOOKS = [['grey', 'Grey'], ['painted', 'Painted'], ['auto', 'Auto'], ['view', '360 view']];

export function mountProjections(viewport) {
  let items = [], look = LOOKS.some(([k]) => k === read('bb.look')) ? read('bb.look') : 'auto';
  const tex = new Map(), depth = new Map(), listeners = new Set();
  const emit = () => listeners.forEach((fn) => fn());

  // ---------- shader: every painted material shares these uniforms ----------
  const dummyTex = new THREE.DataTexture(new Uint8Array([128, 128, 128, 255]), 1, 1); dummyTex.needsUpdate = true;
  const dummyCube = new THREE.WebGLCubeRenderTarget(1);
  const U = { viewMode: { value: 0 }, vSlot: { value: 0 } };
  for (let k = 0; k < SLOTS; k++) Object.assign(U, {
    [`pT${k}`]: { value: dummyTex }, [`pD${k}`]: { value: dummyCube.texture }, [`pC${k}`]: { value: new THREE.Vector3() },
    [`pOn${k}`]: { value: 0 }, [`pR${k}`]: { value: new THREE.Vector3(1, 0, 0) }, [`pU${k}`]: { value: new THREE.Vector3(0, 1, 0) },
    [`pF${k}`]: { value: new THREE.Vector3(0, 0, -1) }, [`pK${k}`]: { value: 0 }, [`pTn${k}`]: { value: new THREE.Vector2(1, 1) },
  });
  const K = [...Array(SLOTS).keys()];
  const slotGLSL = (k) => `
    if (pOn${k} > 0.5) { vec3 d = vW - pC${k}; float L = length(d); vec3 dir = d / max(L, 1e-4);
      float stored = textureCube(pD${k}, dir).r * ${FAR.toFixed(1)};
      if (L <= stored + 0.04 + 0.025 * L && L < bestL) {
        vec3 Lc = vec3(dot(dir, pR${k}), dot(dir, pU${k}), dot(dir, pF${k}));
        if (pK${k} > 0.5) {
          if (Lc.z > 0.02) { vec2 sp = vec2(Lc.x / Lc.z / pTn${k}.x, Lc.y / Lc.z / pTn${k}.y);
            if (abs(sp.x) <= 1.0 && abs(sp.y) <= 1.0) { best = texture2D(pT${k}, 0.5 + 0.5 * sp).rgb; bestL = L; } }
        } else {
          float u = fract(0.5 + atan(Lc.x, Lc.z) / 6.2831853);
          float v = 0.5 + asin(clamp(Lc.y, -1.0, 1.0)) / 3.14159265;
          best = texture2D(pT${k}, vec2(u, v)).rgb; bestL = L; } } }`;
  const VS = `#include <common>
#include <logdepthbuf_pars_vertex>
varying vec3 vW; varying vec3 vN;
void main() { vec4 w = modelMatrix * vec4(position, 1.0); vW = w.xyz; vN = normalize(mat3(modelMatrix) * normal);
  gl_Position = projectionMatrix * viewMatrix * w;
  #include <logdepthbuf_vertex>
}`;
  const FS = `#include <common>
#include <logdepthbuf_pars_fragment>
uniform vec3 base; uniform float viewMode; uniform float vSlot;
${K.map((k) => `uniform sampler2D pT${k}; uniform samplerCube pD${k}; uniform vec3 pC${k}; uniform float pOn${k}; uniform vec3 pR${k}; uniform vec3 pU${k}; uniform vec3 pF${k}; uniform float pK${k}; uniform vec2 pTn${k};`).join('\n')}
varying vec3 vW; varying vec3 vN;
void main() {
  #include <logdepthbuf_fragment>
  if (viewMode > 0.5) {
    vec3 dv = normalize(vW - cameraPosition); vec3 col = base;
    ${K.map((k) => `if (abs(vSlot - ${k}.0) < 0.5) { vec3 Lv = vec3(dot(dv, pR${k}), dot(dv, pU${k}), dot(dv, pF${k})); col = texture2D(pT${k}, vec2(fract(0.5 + atan(Lv.x, Lv.z) / 6.2831853), 0.5 + asin(clamp(Lv.y, -1.0, 1.0)) / 3.14159265)).rgb; }`).join('\n    ')}
    gl_FragColor = vec4(col, 1.0);
    #include <colorspace_fragment>
    return;
  }
  vec3 best = vec3(0.0); float bestL = 1e9;
  ${K.map(slotGLSL).join('\n')}
  vec3 n = normalize(vN); float lam = 0.55 + 0.45 * max(dot(n, normalize(vec3(0.4, 0.8, 0.3))), 0.0);
  gl_FragColor = vec4(bestL < 1e8 ? best : base * lam, 1.0);
  #include <colorspace_fragment>
}`;
  const painted = (orig) => {
    const m = new THREE.ShaderMaterial({ uniforms: { ...U, base: { value: orig?.color ? orig.color.clone() : new THREE.Color(0.7, 0.7, 0.7) } },
      vertexShader: VS, fragmentShader: FS, side: orig?.side ?? THREE.FrontSide, toneMapped: false, polygonOffset: true, polygonOffsetFactor: 1, polygonOffsetUnits: 1 });
    m.userData.painted = true;
    return m;
  };
  // (the 360 view's backdrop: a big sphere, painted the same way)
  const sky = new THREE.Mesh(new THREE.SphereGeometry(300, 48, 24), painted({ color: new THREE.Color(0x9cc9ee), side: THREE.BackSide }));
  sky.frustumCulled = false; sky.visible = false; sky.userData.projSky = true;
  viewport.scene.add(sky);

  // ---------- the set's meshes: painted or their own material ----------
  const setMeshes = () => {
    const out = [];
    for (const [id, m] of viewport.meshes) if (m.model && store.object(id)?.type === 'model') m.model.traverse((c) => { if (c.isMesh && !c.isSkinnedMesh) out.push(c); });
    return out;
  };
  let applied = null;
  /** Swap the set to the painted look or back (on: false in the plan, and for Grey). */
  function apply(on) {
    on = on && look !== 'grey' && items.some((p) => p.on);
    const meshes = setMeshes(), key = `${on}|${meshes.length}`;
    if (key === applied) return;
    applied = key;
    for (const c of meshes) {
      if (!c.userData.origMat) { c.userData.origMat = c.material; c.userData.paintMat = Array.isArray(c.material) ? c.material.map(painted) : painted(c.material); }
      c.material = on ? c.userData.paintMat : c.userData.origMat;
    }
    viewport.dirty = true;
  }

  // ---------- each projection's picture and depth cube ----------
  function basis(p, k) {
    const y = p.heading * DEG, pt = (p.pitch || 0) * DEG, rl = (p.roll || 0) * DEG;
    const f = new THREE.Vector3(Math.sin(y) * Math.cos(pt), Math.sin(pt), -Math.cos(y) * Math.cos(pt)), r0 = new THREE.Vector3(Math.cos(y), 0, Math.sin(y));
    const u0 = new THREE.Vector3().crossVectors(r0, f).normalize(), r = r0.clone().multiplyScalar(Math.cos(rl)).addScaledVector(u0, Math.sin(rl)).normalize();
    U[`pF${k}`].value.copy(f); U[`pR${k}`].value.copy(r); U[`pU${k}`].value.copy(new THREE.Vector3().crossVectors(r, f).normalize());
    if (p.kind === 'photo') { const th = 18 / (p.lens || 30), asp = p.aspect || 16 / 9; U[`pK${k}`].value = 1; U[`pTn${k}`].value.set(asp >= 1 ? th : th * asp, asp >= 1 ? th / asp : th); }
    else U[`pK${k}`].value = 0;
  }
  function picture(p) {
    if (tex.has(p.file)) return tex.get(p.file);
    const t = new THREE.TextureLoader().load(`/textures/${encodeURIComponent(p.file)}`, (tt) => {
      if (p.kind === 'photo' && tt.image?.width) p.aspect = p.aspect || tt.image.width / tt.image.height;
      slotKey = ''; viewport.dirty = true;
    });
    t.colorSpace = THREE.SRGBColorSpace; t.generateMipmaps = false; t.minFilter = THREE.LinearFilter;
    t.wrapS = p.kind === 'photo' ? THREE.ClampToEdgeWrapping : THREE.RepeatWrapping;
    tex.set(p.file, t);
    return t;
  }
  const distMat = new THREE.ShaderMaterial({ side: THREE.DoubleSide, uniforms: { center: { value: new THREE.Vector3() } },
    vertexShader: 'varying vec3 vW; void main(){ vec4 w = modelMatrix * vec4(position, 1.0); vW = w.xyz; gl_Position = projectionMatrix * viewMatrix * w; }',
    fragmentShader: `uniform vec3 center; varying vec3 vW; void main(){ gl_FragColor = vec4(length(vW - center) / ${FAR.toFixed(1)}, 0.0, 0.0, 1.0); }` });
  /** What the projection's spot sees, as distances: a wall stops it painting what's behind (made once per spot and set). */
  // (one per renderer: the main view, the Cam view and the exports each have their own WebGL context, and a render
  // target made in one can't be read in another - it came out empty, and nothing got painted)
  const rid = new WeakMap(); let rids = 0;
  const idOf = (r) => { if (!rid.has(r)) rid.set(r, ++rids); return rid.get(r); };
  function depthOf(p, renderer) {
    const key = `${p.x},${p.y},${p.z}|${setMeshes().length}`, dk = `${p.id}|${idOf(renderer)}`;
    const have = depth.get(dk);
    if (have?.key === key) return have.rt;
    const rt = have?.rt || new THREE.WebGLCubeRenderTarget(512, { type: THREE.HalfFloatType, generateMipmaps: false, minFilter: THREE.NearestFilter, magFilter: THREE.NearestFilter });
    const cc = new THREE.CubeCamera(0.03, FAR * 1.5, rt); cc.position.set(p.x, p.y, p.z); cc.updateMatrixWorld(true);
    const sc = viewport.scene, hidden = [];
    for (const c of sc.children) if (c.visible && c !== viewport.objects) { hidden.push(c); c.visible = false; }
    for (const [id, m] of viewport.meshes) if (store.object(id)?.type !== 'model' && m.mesh.visible) { hidden.push(m.mesh); m.mesh.visible = false; }
    const bg = sc.background, fog = sc.fog, clip = viewport.cutPlane?.constant;
    if (viewport.cutPlane) viewport.cutPlane.constant = 1e9;
    sc.background = new THREE.Color(1, 0, 0); sc.fog = null; distMat.uniforms.center.value.set(p.x, p.y, p.z);
    sc.overrideMaterial = distMat;
    try { cc.update(renderer, sc); }
    finally { sc.overrideMaterial = null; sc.background = bg; sc.fog = fog; hidden.forEach((c) => { c.visible = true; }); if (viewport.cutPlane) viewport.cutPlane.constant = clip; }
    depth.set(dk, { key, rt });
    return rt;
  }

  // ---------- per picture: the projections nearest the camera fill the slots ----------
  let slotKey = '', slotItems = [];
  function assign(x, z, renderer) {
    let on = items.filter((p) => p.on);
    if (on.length > SLOTS) on = on.slice().sort((a, b) => Math.hypot(a.x - x, a.z - z) - Math.hypot(b.x - x, b.z - z)).slice(0, SLOTS);
    const key = on.map((p) => [p.id, p.file, p.x, p.y, p.z, p.heading, p.pitch, p.roll, p.lens, p.aspect].join(',')).join('|') + `|${setMeshes().length}|${idOf(renderer)}`;
    if (key === slotKey) return;
    slotKey = key; slotItems = on;
    for (let k = 0; k < SLOTS; k++) {
      const p = on[k];
      if (!p) { U[`pOn${k}`].value = 0; continue; }
      const t = picture(p);
      // (a picture still on its way paints nothing: the surface stays grey instead of black; it paints once it's in)
      if (!t.image?.width) { U[`pOn${k}`].value = 0; continue; }
      U[`pT${k}`].value = t; U[`pC${k}`].value.set(p.x, p.y, p.z); basis(p, k);
      U[`pD${k}`].value = depthOf(p, renderer).texture; U[`pOn${k}`].value = 1;
    }
    viewport.dirty = true;
  }
  /** Called before each picture of the set (main view, Cam view, frames, exports): which look, which projections. */
  function before(cam, plan, renderer = viewport.renderer) {
    apply(!plan);
    if (plan || look === 'grey' || !items.some((p) => p.on)) { sky.visible = false; U.viewMode.value = 0; return; }
    assign(cam.position.x, cam.position.z, renderer);
    let view = look === 'view';
    if (look === 'auto' || view) {
      let best = -1, bd = Infinity;
      slotItems.forEach((p, k) => { if (p.kind === 'photo') return; const d = Math.hypot(p.x - cam.position.x, p.z - cam.position.z); if (d < bd) { bd = d; best = k; } });
      if (look === 'auto') view = best >= 0 && bd < 0.75;
      if (best >= 0) U.vSlot.value = best; else view = false;
    }
    U.viewMode.value = view ? 1 : 0;
    sky.visible = view;
  }

  // ---------- the list ----------
  async function load() {
    try { const r = await fetch('/api/projections').then((x) => x.json()); if (r.ok) items = r.items; } catch {}
    slotKey = ''; applied = null; viewport.dirty = true; emit();
  }
  async function save(next, label) {
    const r = await store.post('/api/projections', { items: next });
    if (!r.ok) { toast(r.error || 'Could not save the projections', { kind: 'error' }); return false; }
    items = r.items; slotKey = ''; applied = null; viewport.dirty = true; emit();
    if (label) toast(label);
    return true;
  }
  store.on('projections', load);
  load();

  return {
    before,
    get items() { return items; },
    get look() { return look; },
    setLook(v) { look = v; write('bb.look', v); applied = null; viewport.dirty = true; emit(); },
    save, load,
    on(fn) { listeners.add(fn); return () => listeners.delete(fn); },
    /** A new set arrived (model loaded or replaced): paint it again, re-make the depth cubes. */
    modelChanged() { applied = null; slotKey = ''; depth.clear(); viewport.dirty = true; },
  };
}
