// Blocking Board: the simple floor-plan camera, as on the first Blocking Board's Floor plan card. In the Plan view the
// active shot's camera is a diamond with its view cone (as wide as the lens) and a small dot at its aim: drag the
// diamond to move the camera across the floor (its height and direction stay), drag the dot to turn it. People and
// props get a small dot in front too: drag it to turn them (dragging their body moves them: app/board-tools.js).
// Also drawn: the other shots' cameras (faded; click one to go to that shot), walk waypoints (diamonds), where people
// end the shot (hollow rings) and the 180° line (dashed). A bar over the plan holds Cut, Other shots and Fit.
// Every drag is one undo step; the camera is keyed at the playhead like any other camera change (a locked shot's
// camera shows Locked and doesn't drag).
import * as THREE from 'three';
import { h, toast } from './ui/kit.js';
import { store } from './store.js';
import { shotList } from '/core/doc.js';
import { sampleCamera, sampleObject } from '/core/curves.js';
import { planMove, planTurn, planCone } from '/core/plancam.js';

const DEG = Math.PI / 180;
const read = (k) => { try { return localStorage.getItem(k); } catch { return null; } };
const write = (k, v) => { try { localStorage.setItem(k, v); } catch {} };

export function mountPlanTools({ viewport, camView }) {
  const stage = viewport.stage;
  const cv = h('canvas.pt-overlay'), ctx = cv.getContext('2d');
  stage.append(cv);
  let others = read('bb.otherShots') !== 'off';

  // ---------- the bar over the plan: Cut, Other shots, Fit ----------
  const cutOut = h('output.pt-cut-out.cc-mono');
  const cut = h('input', { type: 'range', min: '0', max: '4', step: '0.1', title: 'Cut height: the plan slices the set this high (0 = no cut)',
    onInput: () => setCut(+cut.value) });
  function setCut(v) { store.set({ planCut: v }); write('bb.planCut', String(v)); }
  const otherBox = h('input', { type: 'checkbox', onChange: () => { others = otherBox.checked; write('bb.otherShots', others ? 'on' : 'off'); } });
  otherBox.checked = others;
  const fitBtn = h('button.cc-btn', { type: 'button', title: 'Show the people and the cameras (Home)', onClick: () => fit() }, 'Fit');
  const zoomBtn = (sign) => h('button.cc-btn.pt-zoom', { type: 'button', title: sign > 0 ? 'Zoom in (or scroll / pinch on the plan)' : 'Zoom out', onClick: () => zoomBy(sign > 0 ? 1.5 : 1 / 1.5) }, sign > 0 ? '+' : '−');
  function zoomBy(f) {
    const cam = viewport.planCam;
    cam.zoom = Math.max(viewport.planOrbit.minZoom, Math.min(viewport.planOrbit.maxZoom, cam.zoom * f));
    cam.updateProjectionMatrix(); viewport.planOrbit.update();
  }
  const bar = h('div.cc-panel.pt-bar', {},
    h('label.pt-cut', {}, 'Cut', cut, cutOut),
    h('label.pt-check', { title: "The scene's other shot cameras, faded (click one to go to that shot)" }, otherBox, 'Other shots'),
    zoomBtn(-1), zoomBtn(1), fitBtn);
  const hint = h('div.pt-hint', { title: 'Diamonds are walk waypoints, hollow rings are where people end the shot, the dashed line is the 180° line' },
    'Drag the camera, a person or a prop to move it · drag its small dot to turn it · drag empty space to pan · scroll to zoom');
  stage.append(bar, hint);
  // the 3D view's own bar: Center (back to the scene's people and camera - easy to get lost in a whole town)
  const bar3d = h('div.cc-panel.pt-bar.pt-bar3d', {},
    h('button.cc-btn', { type: 'button', title: 'Back to the middle: the people, the props and the shot camera in view (Home)', onClick: () => viewport.home() }, 'Center'));
  stage.append(bar3d);
  addEventListener('keydown', (e) => {
    if (e.key !== 'Home' || e.target.closest?.('input, textarea, select, [contenteditable]')) return;
    const v = store.state.view; if (v === 'plan') { e.preventDefault(); fit(); } else if (v === 'free') { e.preventDefault(); viewport.home(); }
  });

  // ---------- plan <-> screen ----------
  const W = () => stage.clientWidth, H = () => stage.clientHeight;
  const toScreen = (x, z) => { const v = new THREE.Vector3(x, 0, z).project(viewport.planCam); return [(v.x + 1) / 2 * W(), (1 - v.y) / 2 * H()]; };
  const toFloor = (e) => {
    const r = viewport.canvas.getBoundingClientRect();
    const v = new THREE.Vector3(((e.clientX - r.left) / r.width) * 2 - 1, -((e.clientY - r.top) / r.height) * 2 + 1, 0).unproject(viewport.planCam);
    return [v.x, v.z];
  };
  const pxPerM = () => { const a = toScreen(0, 0), b = toScreen(1, 0); return Math.max(1e-3, Math.abs(b[0] - a[0])); };

  // ---------- what's on the plan ----------
  const doc = () => store.doc, t = () => store.state.time;
  const shotNow = () => doc().shots.find((s) => s.id === doc().shot);
  const aspect = () => doc().meta.width / doc().meta.height;
  const isCast = (o) => o.type === 'person' || (o.type === 'card' && o.params.lit !== false && (o.params.h || 0) * (o.scale?.[1] || 1) >= 1);
  const draggable = (id) => window.canvas.planDraggable?.(id);
  const posed = (o, tl = doc().timeline, at = t()) => sampleObject(o, tl, at);
  const poseOf = (tl, at) => { const p = sampleCamera(tl, at); return p && { position: p.position, target: p.target, fov: p.fov, roll: p.roll || 0 }; };
  let drag = null, preview = null, handles = [], lastSig = '';

  function colors() {
    const cs = getComputedStyle(document.documentElement);
    return { accent: cs.getPropertyValue('--cc-accent').trim() || '#ff5a1f' };
  }
  const label = (text, x, y, color = '#fff') => {
    ctx.font = '600 11px system-ui, sans-serif'; ctx.lineWidth = 3; ctx.strokeStyle = 'rgba(20,20,18,.75)'; ctx.strokeText(text, x, y);
    ctx.fillStyle = color; ctx.fillText(text, x, y);
  };
  function cone(pose, len, fill, stroke, width = 1.5) {
    const { yaw, half } = planCone(pose, aspect()), [sx, sy] = toScreen(pose.position[0], pose.position[2]);
    const pt = (a) => { const r = a * DEG; return toScreen(pose.position[0] + Math.sin(r) * len, pose.position[2] + Math.cos(r) * len); };
    const [ax, ay] = pt(yaw - half), [bx, by] = pt(yaw + half);
    ctx.beginPath(); ctx.moveTo(sx, sy); ctx.lineTo(ax, ay); ctx.lineTo(bx, by); ctx.closePath();
    if (fill) { ctx.fillStyle = fill; ctx.fill(); }
    if (stroke) { ctx.strokeStyle = stroke; ctx.lineWidth = width; ctx.stroke(); }
    return { sx, sy, yaw };
  }
  function diamond(x, y, r, yawDeg, fill, stroke) {
    ctx.save(); ctx.translate(x, y); ctx.rotate(yawDeg * DEG);
    ctx.beginPath(); ctx.moveTo(0, -r); ctx.lineTo(r, 0); ctx.lineTo(0, r); ctx.lineTo(-r, 0); ctx.closePath();
    if (fill) { ctx.fillStyle = fill; ctx.fill(); }
    if (stroke) { ctx.strokeStyle = stroke; ctx.lineWidth = 1.5; ctx.stroke(); }
    ctx.restore();
  }

  function draw() {
    const on = store.state.view === 'plan' && !!doc();
    cv.hidden = bar.hidden = hint.hidden = !on;
    bar3d.hidden = store.state.view !== 'free' || !doc();
    if (!on) { lastSig = ''; return; }
    const dpr = Math.min(2, devicePixelRatio || 1), w = W(), hh = H();
    // (drawn again only when the plan camera, the scene, the time, the selection, a drag or the size changed)
    const pc = viewport.planCam, sig = `${store.rev}|${store.state.time}|${store.state.selection}|${others}|${w}x${hh}|${pc.zoom}|${pc.position.x},${pc.position.z}|${pc.left},${pc.top}|${drag ? JSON.stringify(preview) : ''}`;
    if (sig === lastSig) return;
    lastSig = sig;
    if (cv.width !== Math.round(w * dpr) || cv.height !== Math.round(hh * dpr)) { cv.width = Math.round(w * dpr); cv.height = Math.round(hh * dpr); }
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0); ctx.clearRect(0, 0, w, hh);
    const c = colors(), m = pxPerM(), d = doc(), tl = d.timeline, sh = shotNow();
    const v = store.state.planCut ?? 1.2;
    if (document.activeElement !== cut) cut.value = String(v);
    cutOut.textContent = `${(+v).toFixed(1)} m`;
    handles = [];
    // the other shots' cameras, faded, at their start
    if (others) for (const s of shotList(d)) {
      if (s.active) continue;
      const p = poseOf(s.timeline, 0); if (!p) continue;
      const { sx, sy, yaw } = cone(p, 110 / m, 'rgba(255,255,255,.06)', 'rgba(255,255,255,.35)', 1);
      diamond(sx, sy, 6, yaw, 'rgba(255,255,255,.5)', null);
      label(s.name, sx + 9, sy + 14, 'rgba(255,255,255,.7)');
      handles.push({ kind: 'shot', id: s.id, x: sx, y: sy, r: 9 });
    }
    const cast = d.objects.filter((o) => isCast(o) && !(sh?.off || []).includes(o.id));
    // the 180° line (dashed): the slate's pair, else the first two people
    const L = d.slate?.line?.every((id) => cast.some((o) => o.id === id)) && d.slate.line[0] !== d.slate.line[1] ? d.slate.line.map((id) => cast.find((o) => o.id === id)) : cast.slice(0, 2);
    if (L.length === 2) {
      const [a, b] = L.map((o) => posed(o).position), dx = b[0] - a[0], dz = b[2] - a[2];
      const [x1, y1] = toScreen(a[0] - dx * 0.6, a[2] - dz * 0.6), [x2, y2] = toScreen(b[0] + dx * 0.6, b[2] + dz * 0.6);
      ctx.save(); ctx.setLineDash([7, 5]); ctx.strokeStyle = 'rgba(255,255,255,.7)'; ctx.lineWidth = 1.5;
      ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2, y2); ctx.stroke(); ctx.restore();
      label('180°', x2 + 4, y2 - 4, 'rgba(255,255,255,.8)');
    }
    // walk waypoints (diamonds) and where people end the shot (hollow rings)
    const st = tl.start || 0, dur = tl.duration;
    for (const o of cast) {
      if (!o.anim?.length) continue;
      for (const k of o.anim) if (k.t > st + 1e-3 && k.t < st + dur - 1e-3) { const [x, y] = toScreen(k.position[0], k.position[2]); diamond(x, y, 5, 45, null, 'rgba(255,255,255,.85)'); }
      const a = posed(o, tl, 0).position, b = posed(o, tl, dur).position;
      if (Math.hypot(b[0] - a[0], b[2] - a[2]) > 0.1) {
        const [x, y] = toScreen(b[0], b[2]);
        ctx.beginPath(); ctx.arc(x, y, Math.max(6, 0.25 * m), 0, Math.PI * 2); ctx.strokeStyle = '#fff'; ctx.lineWidth = 2; ctx.stroke();
      }
    }
    // turn dots: people always, a prop while it's selected
    const sel = store.state.selection;
    for (const o of d.objects) {
      if (!(isCast(o) && !(sh?.off || []).includes(o.id)) && !(o.id === sel && draggable(o.id))) continue;
      if (!draggable(o.id)) continue;
      const s = drag?.kind === 'turn' && drag.id === o.id ? { position: drag.pos, rotation: [0, drag.yaw, 0] } : posed(o);
      const r = s.rotation[1] * DEG, reach = Math.max(0.45, 22 / m);
      const [bx, by] = toScreen(s.position[0], s.position[2]), [x, y] = toScreen(s.position[0] + Math.sin(r) * reach, s.position[2] + Math.cos(r) * reach);
      ctx.strokeStyle = 'rgba(255,255,255,.9)'; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.moveTo(bx, by); ctx.lineTo(x, y); ctx.stroke();
      ctx.beginPath(); ctx.arc(x, y, 4.5, 0, Math.PI * 2); ctx.fillStyle = '#fff'; ctx.fill(); ctx.strokeStyle = 'rgba(20,20,18,.8)'; ctx.lineWidth = 1; ctx.stroke();
      handles.push({ kind: 'turn', id: o.id, x, y, r: 8 });
    }
    // the active shot's camera: cone, aim dot, diamond
    const p = preview || poseOf(tl, t());
    if (p) {
      const len = 150 / m, { sx, sy, yaw } = cone(p, len, 'rgba(255,90,31,.16)', c.accent, 1.5);
      const r = yaw * DEG, [ax, ay] = toScreen(p.position[0] + Math.sin(r) * len, p.position[2] + Math.cos(r) * len);
      ctx.strokeStyle = c.accent; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(sx, sy); ctx.lineTo(ax, ay); ctx.stroke();
      const locked = !!sh?.lock;
      ctx.beginPath(); ctx.arc(ax, ay, 5.5, 0, Math.PI * 2); ctx.fillStyle = locked ? 'rgba(255,255,255,.6)' : c.accent; ctx.fill();
      diamond(sx, sy, 9, yaw, c.accent, '#fff');
      label(`${sh?.name || ''} cam${locked ? ' · Locked' : ''}`, sx + 13, sy + 15);
      if (!locked) handles.push({ kind: 'aim', x: ax, y: ay, r: 9 }, { kind: 'cam', x: sx, y: sy, r: 12 });
    }
  }
  (function loop() { requestAnimationFrame(loop); try { draw(); } catch (e) { console.warn('plan tools', e); } })();

  // ---------- dragging the camera, its dot, and turn dots ----------
  const hit = (e) => {
    const r = stage.getBoundingClientRect(), x = e.clientX - r.left, y = e.clientY - r.top;
    for (let i = handles.length - 1; i >= 0; i--) { const k = handles[i]; if (Math.hypot(x - k.x, y - k.y) <= k.r) return k; }
    return null;
  };
  stage.addEventListener('pointerdown', (e) => {
    if (store.state.view !== 'plan' || e.button !== 0 || !doc() || e.target.closest?.('.pt-bar')) return;
    const k = hit(e); if (!k) return;
    e.stopPropagation(); e.preventDefault();
    if (k.kind === 'shot') { store.op({ op: 'shot.use', id: k.id }, 'switch shot').catch((err) => toast(err.message, { kind: 'error' })); return; }
    if (store.state.playing) store.set({ playing: false });
    const f = toFloor(e);
    if (k.kind === 'turn') {
      const o = store.object(k.id); if (!o) return;
      const s = posed(o);
      store.set({ selection: o.id });
      drag = { kind: 'turn', id: o.id, pos: s.position, yaw: s.rotation[1], moved: false };
    } else {
      const p0 = poseOf(doc().timeline, t()); if (!p0) return;
      drag = { kind: k.kind, p0, f0: f, moved: false };
    }
    viewport.planOrbit.enabled = false; viewport.dragging = true;
    stage.setPointerCapture?.(e.pointerId);
  }, true);
  addEventListener('pointermove', (e) => {
    if (!drag) return;
    drag.moved = true;
    const [x, z] = toFloor(e);
    if (drag.kind === 'cam') {
      const step = e.shiftKey ? 0.001 : 0.05, snap = (v) => Math.round(v / step) * step;
      preview = planMove(drag.p0, snap(x - drag.f0[0]), snap(z - drag.f0[1]));
      // Keep aimed (under the camera): moving the camera on the set keeps the Aim person (or prop) framed
      if (camView?.keepAim && camView.aimed) {
        const V = (a) => new THREE.Vector3(...a), q = camView.aimed({ position: V(preview.position), target: V(preview.target), fov: preview.fov, roll: preview.roll });
        preview = { ...preview, target: q.target.toArray().map((v) => Math.round(v * 1000) / 1000) };
      }
      camView?.preview(preview);
    } else if (drag.kind === 'aim') {
      preview = planTurn(drag.p0, x, z);
      camView?.preview(preview);
    } else if (drag.kind === 'turn') {
      let y = Math.atan2(x - drag.pos[0], z - drag.pos[2]) / DEG;
      if (!e.shiftKey) y = Math.round(y / 15) * 15;
      drag.yaw = Math.round(y * 100) / 100;
      const m = viewport.meshes.get(drag.id); if (m) m.mesh.rotation.y = drag.yaw * DEG;
    }
  });
  addEventListener('pointerup', async () => {
    if (!drag) return;
    const d = drag; drag = null;
    viewport.planOrbit.enabled = store.state.view === 'plan'; viewport.dragging = false;
    if (!d.moved) { preview = null; camView?.preview(null); return; }
    try {
      if (d.kind === 'turn') {
        const o = store.object(d.id); if (!o) return;
        const rot = [o.rotation[0], d.yaw, o.rotation[2]];
        await store.op(o.anim?.length ? { op: 'anim.key', id: o.id, t: +t().toFixed(3), position: d.pos, rotation: rot } : { op: 'update', id: o.id, rotation: rot }, `turn ${o.id}`);
      } else if (preview) await keyCamera(preview, d.kind === 'cam' ? 'camera moved on the plan' : 'camera turned on the plan');
    } catch (err) { toast(err.message, { kind: 'error' }); }
    finally { preview = null; camView?.preview(null); }
  });
  // the camera keyed at the playhead: the key there (within a frame), or a new one
  async function keyCamera(p, label) {
    const tl = doc().timeline, t0 = t(), near = tl.keys.find((k) => Math.abs(k.t - t0) <= 0.5 / (tl.fps || 24));
    const at = near ? near.t : +t0.toFixed(3);
    // (a held camera - every key the same - stays held: the move goes to every key)
    const same = (a, b) => a.every((x, i) => Math.abs(x - b[i]) < 1e-4);
    const held = tl.keys.length > 1 && tl.keys.every((k) => same(k.position, tl.keys[0].position) && same(k.target, tl.keys[0].target) && Math.abs(k.fov - tl.keys[0].fov) < 1e-4);
    if (held) return store.op(tl.keys.map((k, i) => ({ op: 'key.update', index: i, position: p.position, target: p.target, fov: p.fov, roll: p.roll })), label);
    await store.op({ op: 'key.add', t: at, position: p.position, target: p.target, fov: p.fov, roll: p.roll }, label);
    if (!near) toast(`Camera key added at ${at.toFixed(2)} s`);
  }

  // ---------- Fit: the people, the props and the cameras in view ----------
  function fit() {
    const d = doc(); if (!d) return;
    const pts = [];
    for (const o of d.objects) if (draggable(o.id)) { const p = posed(o).position; pts.push([p[0], p[2]]); }
    for (const s of shotList(d)) if (s.active || others) { const p = poseOf(s.timeline, s.active ? t() : 0); if (p) pts.push([p.position[0], p.position[2]], [p.target[0], p.target[2]]); }
    if (!pts.length) return toast('Nothing to fit yet: add a person or key the camera');
    const xs = pts.map((p) => p[0]), zs = pts.map((p) => p[1]);
    const cx = (Math.min(...xs) + Math.max(...xs)) / 2, cz = (Math.min(...zs) + Math.max(...zs)) / 2;
    const sx = Math.max(4, Math.max(...xs) - Math.min(...xs)), sz = Math.max(4, Math.max(...zs) - Math.min(...zs));
    const cam = viewport.planCam, vw = cam.right - cam.left, vh = cam.top - cam.bottom;
    cam.zoom = Math.max(0.02, Math.min(40, Math.min(vw / (sx * 1.35), vh / (sz * 1.35))));
    viewport.planOrbit.target.set(cx, 0, cz);
    cam.position.set(cx, cam.position.y, cz);
    cam.updateProjectionMatrix(); viewport.planOrbit.update();
  }
  return { fit };
}
