// Cam view: what the shot camera sees, always on screen beside the main view (as on the first Blocking Board, where
// the floor plan and the camera sat side by side). It shows while the main view is Plan or 3D; with the main view on
// Cam it steps aside (the main view is the camera then). Drawn live by its own renderer: scrubbing, playing and
// moving things all show here at once. The Cam button in the top bar hides it (remembered per PC).
import { h, icon, toast } from './ui/kit.js';
import { store } from './store.js';
import { shotList } from '/core/doc.js';

export function mountCamView(hud, { viewport }) {
  let on = localStorage.getItem('bb.cam') !== 'off';
  const btn = h('button.cc-btn.st-add', { type: 'button', title: 'Show or hide the Cam view (what the shot camera sees)', onClick: () => toggle() }, icon('camera'), 'Cam');
  hud.append(btn);
  const title = h('span.cv-title');
  const big = h('button.cc-btn.cc-btn--ghost', { type: 'button', title: 'Make the camera the main view (C)', onClick: () => store.set({ view: 'shot' }) }, icon('frame'));
  const hide = h('button.cc-btn.cc-btn--ghost', { type: 'button', title: 'Hide the Cam view', onClick: () => toggle(false) }, icon('close'));
  // the film's frame - every scene's camera, and the frames KAI shows on its cards (one for the whole project)
  const fmt = h('select.cc-select.cv-fmt', { title: "The film's frame: every scene's camera, and the pictures on KAI's cards", onChange: () => setFormat(fmt.value) });
  async function readFormat() {
    try {
      const r = await fetch('/api/format').then((x) => x.json()); if (!r.ok) return;
      fmt.replaceChildren(...r.choices.map((c) => h('option', { value: c }, c)));
      fmt.value = r.aspect;
      fmt.title = r.from === 'slate' ? `${r.aspect} - from Scene Slate's show` : r.from === 'board' ? `${r.aspect} - picked for this film` : `${r.aspect} (no format set)`;
    } catch {}
  }
  async function setFormat(aspect) {
    const r = await store.post('/api/format', { aspect }); if (!r.ok) return toast(r.error, { kind: 'error' });
    await readFormat();
    try { const n = await window.canvas.library.frames(true); toast(`Frame ${r.aspect}${n ? ' - KAI frames updated' : ''}. Other scenes follow when they're opened.`); }
    catch { toast(`Frame ${r.aspect}`); }
  }
  readFormat();
  const body = h('div.cv-body', { title: 'Double-click: make the camera the main view', onDblclick: () => store.set({ view: 'shot' }) });
  const panel = h('div.cc-panel.cv-panel', { hidden: true }, h('div.cv-head', {}, icon('camera'), title, fmt, big, hide), body);
  document.body.append(panel);

  function toggle(v = !on) { on = v; localStorage.setItem('bb.cam', on ? 'on' : 'off'); place(); }
  const showing = () => on && !!store.doc && store.state.view !== 'shot';
  function place() {
    panel.hidden = !showing(); btn.classList.toggle('is-open', on);
    const tl = document.getElementById('timeline')?.getBoundingClientRect();
    if (tl) panel.style.bottom = `${Math.round(innerHeight - tl.top + 10)}px`;   // sits just above the timeline
  }
  addEventListener('resize', place);
  new ResizeObserver(place).observe(document.getElementById('timeline'));
  store.on('state', (c) => { if (c.view) place(); });

  // the live picture: up to 30 a second while playing or when something changed, never when hidden
  let last = '', lastT = 0, canvas = null;
  function frame(now) {
    requestAnimationFrame(frame);
    if (!showing() || document.visibilityState !== 'visible') return;
    if (panel.hidden) place();
    const d = store.doc, s = store.state, sh = shotList(d).find((x) => x.active);
    const w = Math.min(960, Math.round(body.clientWidth * Math.min(2, devicePixelRatio || 1))), hgt = Math.round(w * d.meta.height / d.meta.width);
    if (!w) return;
    const key = `${store.rev}|${s.time}|${w}|${viewport.loading?.size || 0}|${s.selection || ''}`;
    if (key === last && now - lastT < 1000) return;   // (once a second anyway: pictures and models that just finished loading)
    if (now - lastT < 33) return;
    last = key; lastT = now;
    try {
      const c = viewport.renderShot(s.time, w, hgt, { view: 'shot', grid: false, slot: 'pip' });
      if (c !== canvas) { canvas = c; body.replaceChildren(c); }
    } catch (e) { console.warn('cam view', e); }
    title.textContent = `Cam view · ${sh?.name || ''}`;
    body.style.aspectRatio = `${d.meta.width} / ${d.meta.height}`;
    panel.classList.toggle('is-tall', d.meta.height > d.meta.width);
  }
  requestAnimationFrame(frame);
  store.on('doc', place);
  return { toggle, get on() { return on; } };
}
