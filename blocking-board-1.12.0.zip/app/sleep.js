// Asleep while out of sight. The page holds the whole set in memory - models, textures, the 3D scene and a WebGL
// renderer per view - even while nobody looks at it: KAI keeps its plugin views loaded behind the canvas. After
// AFTER out of sight (no frame drawn for 3 s: the browser stops drawing a hidden frame - KAI's view behind the canvas - and
// a background tab; a hidden frame keeps its old size and its IntersectionObserver goes quiet, so neither can tell), with nothing on its way
// to the server, nothing exporting, filling or playing, the page writes KAI's frames and the prompts, then swaps itself
// for sleep.html (a few KB). That page comes back here as soon as it's seen again; the server's open scene is the one
// that opens, so nothing is lost. Per PC: localStorage bb.sleep = 'off', or a number of seconds (default 240).
import { store } from './store.js';

const AFTER = () => { try { const v = localStorage.getItem('bb.sleep'); return v === 'off' ? Infinity : +v > 0 ? +v * 1000 : 240e3; } catch { return 240e3; } };

export function mountSleep({ library, slate }) {
  let since = null, going = false;
  let drawn = Date.now();
  const seen = () => { drawn = Date.now(); requestAnimationFrame(seen); }; requestAnimationFrame(seen);
  const away = () => document.visibilityState === 'hidden' || Date.now() - drawn > 3000;
  const idle = () => store.pending === 0 && !store.state.exporting && !store.state.playing && !slate?.filling && !store.moved;
  const check = async () => {
    if (!away()) { since = null; return; }
    since ??= Date.now();
    if (going || Date.now() - since < AFTER() || !idle()) return;
    going = true;
    try { await library.frames(); await slate?.writePrompts?.(); } catch {}
    if (!away() || !idle()) { going = false; return; }   // (back in view, or a change started, while it was writing)
    location.replace(`/sleep.html#${encodeURIComponent(location.pathname + location.search)}`);
  };
  setInterval(check, 5000);
}
