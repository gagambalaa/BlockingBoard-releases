// Blockout bridge server. Zero dependencies.
//
// - serves the app (app/, core/, three.js and mediabunny from node_modules)
// - owns the scene document: applies ops, keeps undo history, persists to scene.json
// - pushes changes and RPC calls to browser tabs over Server-Sent Events
// - queues prompts typed in the canvas so the user's agent can pick them up (canvas wait)
// - stores snapshots and exported videos under exports/

import http from 'node:http';
import fs from 'node:fs';
import fsp from 'node:fs/promises';
import path from 'node:path';
import { normalizeAsk, answerAsk } from '../core/ask.js';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import os from 'node:os';
import { applyOps, createDoc, migrate, describe, shotList, AUDIO_FILE, MODEL_FILE, IMAGE_FILE } from '../core/doc.js';
import crypto from 'node:crypto';
import { dataDir } from './paths.mjs';
import { saveSecret, listSecrets } from './secrets.mjs';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');

/**
 * How this server was started, so the empty chat can say the right next step: by Claude Code (its Bash
 * tool sets CLAUDECODE), by Codex (CODEX_* variables), or by hand from a terminal; whether the
 * blockout plugin is installed (so /blockout:start works); and whether this is a git checkout
 * (so "listen to the canvas" works for an agent started in it, through the repo's own hooks).
 */
export function launchInfo(env = process.env, root = ROOT) {
  const by = env.CLAUDECODE || env.CLAUDE_CODE_SESSION_ID ? 'claude' : Object.keys(env).some((k) => k.startsWith('CODEX_')) ? 'codex' : 'terminal';
  let plugin = !!env.CLAUDE_PLUGIN_ROOT || root.split(path.sep).join('/').includes('/.claude/plugins/');
  if (!plugin) {
    try { plugin = fs.readFileSync(path.join(env.CLAUDE_CONFIG_DIR || path.join(os.homedir(), '.claude'), 'plugins', 'installed_plugins.json'), 'utf8').includes('"blockout@'); } catch {}
  }
  // the folder as the user would type it: ~/... when it is under home and needs no quoting
  const home = os.homedir(), rel = root.startsWith(home + path.sep) ? root.slice(home.length + 1) : null;
  const dir = rel && /^[\w./-]+$/.test(rel) ? `~/${rel}` : /^[\w./-]+$/.test(root) ? root : JSON.stringify(root);
  return { by, plugin, checkout: fs.existsSync(path.join(root, '.git')), root, dir };
}

// How a camera key's segment travels, for ls: " → orbit 90° around car-1".
const pathNote = (k) => {
  const p = k.path;
  if (!p) return '';
  const deg = p.angle ? ` ${p.angle}°` : '';
  if (p.type === 'orbit') return ` → orbit${deg} around ${p.around || (p.center || k.target).join(',')}`;
  const by = p.move && p.move !== p.type && p.move !== 'pan' && p.move !== 'tilt' ? ` (${p.move}${p.params?.by != null ? ` ${p.params.by}m` : ''}${p.params?.lens != null ? ` ${p.params.lens}mm` : ''}${p.params?.angle != null ? ` ${p.params.angle}°` : ''})` : '';
  if (p.type === 'turn') return ` → turn${deg}${p.move === 'tilt' ? ' (tilt)' : ''}`;
  return ` → ${p.type}${by}`;
};

const MIME = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.mjs': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8', '.json': 'application/json', '.png': 'image/png', '.jpg': 'image/jpeg', '.webp': 'image/webp', '.gif': 'image/gif',
  '.svg': 'image/svg+xml', '.mp4': 'video/mp4', '.webm': 'video/webm', '.mov': 'video/quicktime', '.md': 'text/markdown; charset=utf-8',
  '.mp3': 'audio/mpeg', '.wav': 'audio/wav', '.m4a': 'audio/mp4', '.aac': 'audio/aac', '.ogg': 'audio/ogg', '.oga': 'audio/ogg',
  '.opus': 'audio/ogg', '.flac': 'audio/flac', '.woff2': 'font/woff2', '.glb': 'model/gltf-binary',
};

/**
 * What a GLB holds, read from its JSON chunk without loading it: clip names and lengths, and the height of its
 * meshes above the origin (their bind pose; node transforms are not applied). Null if it is not a GLB.
 */
export function glbInfo(buf) {
  if (buf.length < 20 || buf.toString('latin1', 0, 4) !== 'glTF' || buf.readUInt32LE(16) !== 0x4e4f534a) return null;
  const j = JSON.parse(buf.toString('utf8', 20, 20 + buf.readUInt32LE(12)));
  const acc = j.accessors || [];
  const clips = (j.animations || []).map((a, i) => ({
    name: a.name || `clip ${i + 1}`,
    length: Math.round(Math.max(0, ...a.samplers.map((s) => acc[s.input]?.max?.[0] ?? 0)) * 1000) / 1000,
  }));
  let top = null;
  for (const m of j.meshes || []) for (const p of m.primitives || []) {
    const y = acc[p.attributes?.POSITION]?.max?.[1];
    if (Number.isFinite(y)) top = Math.max(top ?? y, y);
  }
  return { clips, height: top == null ? null : Math.round(top * 1000) / 1000, meshes: (j.meshes || []).length, skins: (j.skins || []).length };
}

export function startServer({ port = 5317, host = '127.0.0.1', scene, quiet = false } = {}) {
  const scenePath = path.resolve(scene || process.env.CANVAS_SCENE || path.join(dataDir(), 'scenes', 'scene.json'));
  const workDir = path.join(path.dirname(scenePath), '.canvas');
  const exportsDir = path.resolve(process.env.CANVAS_EXPORTS || path.join(path.dirname(scenePath), 'exports'));
  const savesRoot = path.join(path.dirname(scenePath), 'saved');
  const exportsRoot = exportsDir;
  const promptsRoot = path.join(path.dirname(scenePath), 'prompts');
  // Blocking Board: what belongs to a scene is filed under its Episode / Scene (saved versions, exports, frames, prompts)
  const sceneSub = () => { const { ep, sc } = doc?.meta || {}; try { return ep && sc ? path.join(libName(ep, 'an episode'), libName(sc, 'a scene')) : ''; } catch { return ''; } };
  const urlOf = (rel) => rel.split(path.sep).map(encodeURIComponent).join('/');
  let savesDir = savesRoot;
  const setSavesDir = () => { savesDir = path.join(savesRoot, sceneSub()); };
  const uploadsDir = path.join(workDir, 'uploads');
  const audioDir = path.join(path.dirname(scenePath), 'audio'); // the timeline's audio tracks, shared by every save
  const modelsDir = path.join(path.dirname(scenePath), 'models'); // imported GLBs (model objects), shared by every save
  const texturesDir = path.join(path.dirname(scenePath), 'textures'); // Blocking Board: pictures for textures and cards, shared by every scene
  fs.mkdirSync(workDir, { recursive: true });
  fs.mkdirSync(exportsDir, { recursive: true });
  const inboxPath = path.join(workDir, 'inbox.jsonl');
  const logPath = path.join(workDir, 'log.jsonl');
  const log = (...a) => { if (!quiet) console.log('[canvas]', ...a); };

  // ---------- document ----------
  let doc;
  try { doc = migrate(JSON.parse(fs.readFileSync(scenePath, 'utf8'))); }
  catch (e) {
    if (fs.existsSync(scenePath)) log(`could not read ${scenePath} (${e.message}); starting a new scene`);
    doc = createDoc();
  }
  let rev = 0;
  const undo = [], redo = [];
  let lastWritten = '';
  const persist = () => {
    const text = JSON.stringify(doc, null, 2) + '\n';
    lastWritten = text;
    fs.mkdirSync(path.dirname(scenePath), { recursive: true });
    fs.writeFileSync(scenePath + '.tmp', text);
    fs.renameSync(scenePath + '.tmp', scenePath);
    scheduleAutosave();
    scheduleLibWrite();
  };
  // ---------- shared projects: several artists on one board (KAI syncs library\ between their PCs) ----------
  // One artist works on a scene at a time. KAI holds a lock for what this server says it is working on (status:
  // editing) and writes the locks others hold to .kai\locks.json. A scene someone else holds opens read-only here:
  // nothing is written, and their changes show as they arrive. Files KAI brings in while a scene is open (the
  // scene itself, or its location) are picked up at once; what this server wrote itself is told apart by its time.
  const kaiDir = path.join(path.dirname(scenePath), '.kai');
  const relLib = (f) => path.relative(path.dirname(scenePath), f).split(path.sep).join('/');
  const ownTimes = new Map(); // library file -> its mtime when this server last wrote it
  const noteOwn = (f) => { try { ownTimes.set(f, fs.statSync(f).mtimeMs); } catch {} };
  let locks = { locks: {}, me: '', online: false };
  const readLocks = () => { try { locks = JSON.parse(fs.readFileSync(path.join(kaiDir, 'locks.json'), 'utf8')); } catch { locks = { locks: {}, me: '', online: false }; } };
  /** What this server is working on, for KAI to lock: the open scene, and its location while it's being edited. */
  function editingPaths() {
    const { ep, sc, location } = doc?.meta || {};
    if (!ep || !sc) return [];
    const out = []; try { out.push(relLib(libFile(ep, sc))); if (location?.name && location.edit === 'location') out.push(relLib(locFile(location.name))); } catch {}
    return out;
  }
  /** Who else holds what this scene needs (null = it's ours to change). */
  function lockedBy() { for (const p of editingPaths()) { const l = locks.locks?.[p]; if (l) return l.name || l.by || 'Someone'; } return null; }
  const lockError = () => Object.assign(new Error(`${lockedBy()} is working on this scene - you're viewing it`), { status: 423 });
  let lockWas = null;
  function lockChanged() { const now = lockedBy(); if (now !== lockWas) { lockWas = now; broadcast('lock', { by: now }); } }
  /** The open scene again from its library file (someone else changed it, or KAI put their version in place). */
  function reloadOpen(why) {
    const { ep, sc } = doc.meta || {}; if (!ep || !sc) return;
    let next; try { next = migrate(compose(migrate(JSON.parse(fs.readFileSync(libFile(ep, sc), 'utf8'))))); } catch { return; }
    next.meta = { ...next.meta, ep, sc };
    clearTimeout(libTimer); libTimer = null;   // (what was waiting to be written is older than what just arrived)
    undo.length = 0; redo.length = 0;
    doc = next; rev++;
    const text = JSON.stringify(doc, null, 2) + '\n'; lastWritten = text;
    fs.writeFileSync(scenePath + '.tmp', text); fs.renameSync(scenePath + '.tmp', scenePath);
    broadcast('doc', { doc, rev, source: 'sync', label: why });
    scheduleKaiIndex();
  }
  let libWatchTimer = null; const touched = new Set();
  function libraryTouched(file) { // something in library\ changed on disk: when it wasn't this server, follow it
    touched.add(file);
    clearTimeout(libWatchTimer);
    libWatchTimer = setTimeout(() => {
      const files = [...touched]; touched.clear();
      const outside = files.filter((f) => { try { return fs.statSync(f).mtimeMs !== ownTimes.get(f); } catch { return ownTimes.has(f); } });
      if (!outside.length) return;
      const { ep, sc, location } = doc.meta || {};
      let mine = []; try { mine = [libFile(ep, sc), ...(location?.name ? [locFile(location.name)] : [])]; } catch {}
      for (const f of outside) { noteOwn(f); if (!fs.existsSync(f)) ownTimes.delete(f); }
      if (outside.some((f) => mine.includes(f))) reloadOpen('changed by another artist');
      pushLibrary();
    }, 250);
  }

  // ---------- library: a film's episodes and scenes (Blocking Board) ----------
  // scenes/library/<Episode>/<Scene>.json, one scene document each. scene.json is the open one (agents edit it as
  // before); doc.meta.ep / doc.meta.sc say which library file it is, and every change is written back to that file.
  const libDir = path.join(path.dirname(scenePath), 'library');
  const libName = (s, what) => {
    const n = String(s ?? '').replace(/[\\/:*?"<>|\u0000-\u001f]+/g, ' ').replace(/\s+/g, ' ').trim().replace(/^\.+/, '').slice(0, 60);
    if (!n) throw Object.assign(new Error(`${what} needs a name`), { status: 400 });
    return n;
  };
  const natural = (a, b) => a.localeCompare(b, undefined, { numeric: true, sensitivity: 'base' });
  const libFile = (ep, sc) => path.join(libDir, libName(ep, 'an episode'), `${libName(sc, 'a scene')}.json`);
  let libTimer = null;
  function writeLib() {
    clearTimeout(libTimer); libTimer = null;
    const { ep, sc } = doc.meta || {};
    if (!ep || !sc) return;
    if (lockedBy()) return;   // (someone else's scene: nothing of ours to write)
    try {
      const f = libFile(ep, sc);
      fs.mkdirSync(path.dirname(f), { recursive: true });
      fs.writeFileSync(f + '.tmp', JSON.stringify(splitLocation(doc), null, 2) + '\n');
      fs.renameSync(f + '.tmp', f);
      noteOwn(f);
    } catch (e) { console.error(`[canvas] could not write the scene to the library: ${e.message}`); }
  }
  function scheduleLibWrite() { clearTimeout(libTimer); libTimer = setTimeout(() => { writeLib(); scheduleKaiIndex(); }, 300); }
  function libraryOnDisk() {
    let eps = [];
    try { eps = fs.readdirSync(libDir, { withFileTypes: true }).filter((d) => d.isDirectory() && !/^[._]/.test(d.name)).map((d) => d.name); } catch {}
    return {
      current: { ep: doc.meta?.ep || null, sc: doc.meta?.sc || null },
      episodes: eps.sort(natural).map((ep) => {
        let files = [];
        try { files = fs.readdirSync(path.join(libDir, ep)).filter((f) => f.endsWith('.json')); } catch {}
        return {
          name: ep,
          scenes: files.map((f) => f.slice(0, -5)).sort(natural).map((sc) => {
            const file = path.join(libDir, ep, `${sc}.json`), png = path.join(libDir, ep, `${sc}.png`);
            let shots = 0, objects = 0;
            try { const d = JSON.parse(fs.readFileSync(file, 'utf8')); shots = d.shots?.length || 1; objects = d.objects?.length || 0; } catch {}
            const thumb = fs.existsSync(png) ? `/library/${encodeURIComponent(ep)}/${encodeURIComponent(sc)}.png?v=${Math.round(fs.statSync(png).mtimeMs)}` : null;
            return { name: sc, shots, objects, thumb };
          }),
        };
      }),
    };
  }
  /** The film as the navigator shows it: what's in the library, plus every Scene Slate scene that has no board scene
   *  yet (virtual: true - it is made, and filled from the slate, the first time it's opened). Scenes that follow a
   *  slate scene carry `slate` (its id) and `title` (the slate's). */
  function listLibrary() {
    const L = libraryOnDisk(), sl = slateScenes();
    if (!sl.length) return L;
    const natural2 = (a, b) => a.localeCompare(b, undefined, { numeric: true, sensitivity: 'base' });
    const metas = new Map();
    for (const e of L.episodes) for (const s of e.scenes) { const m = readJsonFile(path.join(libDir, e.name, `${s.name}.json`))?.meta || {}; metas.set(`${e.name}/${s.name}`, m.slate || null); }
    const linked = new Map([...metas].filter(([, v]) => v).map(([k, v]) => [v, k]));
    for (const b of sl) {
      const ep = `EP${pad2(b._ep)}`, sc = `SC${pad2(b._sc)}`, title = String(b.title || '').replace(/^EP\s*\d+\s+S\s*\d+\s*[\u2014\u2013-]\s*/i, '');
      let e = L.episodes.find((x) => x.name === ep);
      const at = linked.get(b._file);
      if (at) { const [en, sn] = at.split('/'); const s = L.episodes.find((x) => x.name === en)?.scenes.find((x) => x.name === sn); if (s) { s.slate = b._file; s.title = title; } continue; }
      const named = e?.scenes.find((x) => (x.name === sc || x.name.startsWith(`${sc} `)) && !metas.get(`${ep}/${x.name}`));
      if (named) { named.slate = b._file; named.title = title; continue; }   // (made by hand under the slate's name: linked when opened)
      if (!e) { e = { name: ep, scenes: [] }; L.episodes.push(e); }
      e.scenes.push({ name: sc, shots: (b.shots || []).length, objects: 0, thumb: null, virtual: true, slate: b._file, title });
    }
    L.episodes.sort((x, y) => natural2(x.name, y.name));
    for (const e of L.episodes) e.scenes.sort((x, y) => natural2(x.name, y.name));
    return L;
  }
  const pushLibrary = () => { broadcast('library', listLibrary()); scheduleKaiIndex(); };


  // ---------- Scene Slate (the sibling plugin in the same KAI project): where the shots are written ----------
  // Its folder is read, never written: <project>\KAI\Scene Slate\ (scenes\<id>.json = the authored scene,
  // data\scenes\<id>.json = what people changed over it). A board scene staged from a slate scene carries
  // meta.slate = its id and meta.slateHash = the slate as it was when the shots were last filled from it.
  const slateDir = path.join(process.env.KAI_PROJECT_DIR || path.dirname(path.dirname(scenePath)), 'Scene Slate');
  const readJsonFile = (f) => { try { return JSON.parse(fs.readFileSync(f, 'utf8')); } catch { return null; } };
  let slateCache = { at: 0, list: [] };
  function slateScenes() {
    if (Date.now() - slateCache.at < 3000) return slateCache.list;
    let files = []; try { files = fs.readdirSync(path.join(slateDir, 'scenes')).filter((f) => f.endsWith('.json')); } catch {}
    const list = files.map((f) => readJsonFile(path.join(slateDir, 'scenes', f))).filter((x) => x && x._file && x._ep != null && x._sc != null);
    slateCache = { at: Date.now(), list };
    return list;
  }
  const SLATE_ID = /^[A-Za-z0-9][A-Za-z0-9._-]{0,80}$/;

  // ---------- following Scene Slate's shape (it adds, removes and merges scenes; their ids never change) ----------
  // A staged scene (meta.slate = its slate scene's id) takes that scene's numbers (EP02/SC03 -> EP02/SC04), with its
  // thumbnail, frames and prompts. One the slate removed goes aside - library/_removed/<slate id>.json (+ its
  // thumbnail, frames and prompts) - and comes back when the slate scene is restored. One merged into another brings
  // its shots (each with its camera) and the set pieces that don't clash into that scene's board; when that one isn't
  // staged, it becomes it. A slate scene that's simply missing (not in removed/) is left alone.
  const boardAside = path.join(libDir, '_removed');
  const workRoot = path.dirname(scenePath);
  const filesOf = (ep, sc) => ({ json: path.join(libDir, ep, `${sc}.json`), png: path.join(libDir, ep, `${sc}.png`),
    frames: path.join(workRoot, 'frames', ep, sc), prompts: path.join(workRoot, 'prompts', ep, `${sc}.json`) });
  const asideOf = (id) => ({ json: path.join(boardAside, `${id}.json`), png: path.join(boardAside, `${id}.png`),
    frames: path.join(boardAside, 'frames', id), prompts: path.join(boardAside, 'prompts', `${id}.json`) });
  function moveSet(a, b) {   // a scene's files (json, png, frames, prompts) from one place to another
    for (const k of ['json', 'png', 'frames', 'prompts']) {
      if (!fs.existsSync(a[k])) continue;
      fs.mkdirSync(path.dirname(b[k]), { recursive: true });
      fs.rmSync(b[k], { recursive: true, force: true });
      fs.renameSync(a[k], b[k]);
    }
  }
  const readScene = (f) => migrate(compose(migrate(JSON.parse(fs.readFileSync(f, 'utf8')))));
  function mergeInto(src, dst) {   // shots (with their cameras), elements and set pieces that don't clash
    const ids = new Set(dst.shots.map((x) => x.id));
    for (const sh of shotList(src)) {
      let id = sh.id, n = 2; while (ids.has(id)) id = `${sh.id}-${n++}`; ids.add(id);
      dst.shots.push({ id, name: sh.name, timeline: JSON.parse(JSON.stringify(sh.timeline)), ...(sh.off?.length ? { off: [...sh.off] } : {}),
        ...(Object.keys(sh.hold || {}).length ? { hold: JSON.parse(JSON.stringify(sh.hold)) } : {}) });
    }
    const oids = new Set(dst.objects.map((o) => o.id)), names = new Set(dst.objects.map((o) => String(o.name || '').toLowerCase()).filter(Boolean));
    for (const o of src.objects) if (!o.loc && !oids.has(o.id) && !(o.name && names.has(String(o.name).toLowerCase()))) dst.objects.push(JSON.parse(JSON.stringify(o)));
    if (src.elements?.length) { const have = new Set((dst.elements || []).map((e) => e.id)); dst.elements = [...(dst.elements || []), ...src.elements.filter((e) => !have.has(e.id))]; }
  }
  const pad2s = (n) => String(n).padStart(2, '0');
  function followSlate() {
    slateCache.at = 0;
    const sl = new Map(slateScenes().map((b) => [b._file, b]));
    const removedDir = path.join(slateDir, 'removed');
    if (!sl.size && !fs.existsSync(removedDir)) return false;
    writeLib();
    const openWas = doc.meta?.ep && doc.meta?.sc ? `${doc.meta.ep}/${doc.meta.sc}` : null;
    const staged = [];
    for (const e of libraryOnDisk().episodes) for (const s of e.scenes) {
      const m = readJsonFile(path.join(libDir, e.name, `${s.name}.json`))?.meta;
      if (m?.slate) staged.push({ ep: e.name, sc: s.name, slate: m.slate });
    }
    const gone = (id) => readJsonFile(path.join(removedDir, `${id}.json`));
    let changed = false, openTo;   // (undefined: the open scene stays; null: it went aside; {ep, sc}: renamed)
    const write = (f, d) => { fs.mkdirSync(path.dirname(f), { recursive: true }); fs.writeFileSync(f, JSON.stringify(splitLocation(d), null, 2) + '\n'); noteOwn(f); };
    // 1. removed / merged in the slate: aside, or into the scene it merged into
    for (const s of [...staged]) {
      if (sl.has(s.slate)) continue;
      const r = gone(s.slate); if (!r) continue;
      const into = r._removed?.into && sl.get(r._removed.into);
      const t = into && staged.find((x) => x.slate === into._file);
      const f = filesOf(s.ep, s.sc).json, isOpen = openWas === `${s.ep}/${s.sc}`;
      if (into && !t) {   // the scene it merged into isn't on the board yet: this board scene becomes it
        const d = isOpen ? doc : readScene(f);
        d.meta = { ...d.meta, slate: into._file, slateHash: undefined };
        if (isOpen) persist(); write(f, d);
        s.slate = into._file; changed = true; continue;
      }
      if (t) {
        const tf = filesOf(t.ep, t.sc).json, tOpen = openWas === `${t.ep}/${t.sc}`;
        const dst = tOpen ? doc : readScene(tf);
        mergeInto(isOpen ? doc : readScene(f), dst);
        if (tOpen) { rev++; persist(); } write(tf, dst);
        log(`slate: ${s.ep}/${s.sc} merged into ${t.ep}/${t.sc}`);
      }
      moveSet(filesOf(s.ep, s.sc), asideOf(s.slate));
      staged.splice(staged.indexOf(s), 1);
      if (isOpen) openTo = null;
      changed = true;
    }
    // 2. restored in the slate: back from aside (it takes its numbers below)
    let aside = []; try { aside = fs.readdirSync(boardAside).filter((f) => f.endsWith('.json')).map((f) => f.slice(0, -5)); } catch {}
    for (const id of aside) {
      const b = sl.get(id); if (!b || staged.some((x) => x.slate === id)) continue;
      const ep = `EP${pad2s(b._ep)}`, sc = `SC${pad2s(b._sc)}`;
      if (fs.existsSync(filesOf(ep, sc).json)) continue;   // (its place is taken: the numbers step sorts it out next time)
      moveSet(asideOf(id), filesOf(ep, sc));
      staged.push({ ep, sc, slate: id }); changed = true;
      log(`slate: ${id} restored as ${ep}/${sc}`);
    }
    // 3. the slate's numbers (two steps, so scenes can swap places)
    const want = (s) => { const b = sl.get(s.slate); if (!b) return null;
      const ep = `EP${pad2s(b._ep)}`, sc = `SC${pad2s(b._sc)}`;
      return { ep: /^EP\d+/i.test(s.ep) ? s.ep.replace(/^EP\d+/i, ep) : s.ep, sc: /^SC\d+/i.test(s.sc) ? s.sc.replace(/^SC\d+/i, sc) : s.sc }; };
    const moving = staged.map((s) => ({ s, to: want(s) })).filter((x) => x.to && (x.to.ep !== x.s.ep || x.to.sc !== x.s.sc));
    const freeing = new Set(moving.map((x) => `${x.s.ep}/${x.s.sc}`));
    const ok = moving.filter((x) => !fs.existsSync(filesOf(x.to.ep, x.to.sc).json) || freeing.has(`${x.to.ep}/${x.to.sc}`));
    for (const x of ok) moveSet(filesOf(x.s.ep, x.s.sc), asideOf(`~mv-${x.s.slate}`));
    for (const x of ok) {
      moveSet(asideOf(`~mv-${x.s.slate}`), filesOf(x.to.ep, x.to.sc));
      if (openWas === `${x.s.ep}/${x.s.sc}` && openTo === undefined) openTo = x.to;
      log(`slate: ${x.s.ep}/${x.s.sc} -> ${x.to.ep}/${x.to.sc}`);
      changed = true;
    }
    if (!changed) return false;
    if (openTo === null) doc.meta = { ...doc.meta, ep: undefined, sc: undefined };
    else if (openTo) doc.meta = { ...doc.meta, ep: openTo.ep, sc: openTo.sc };
    if (openTo !== undefined) { rev++; setSavesDir(); persist(); broadcast('doc', { doc, rev, source: 'scene', label: openTo ? `now ${openTo.ep} / ${openTo.sc}` : 'removed in the slate' }); }
    pushLibrary();
    return true;
  }
  let followTimer = null;
  const followSoon = () => { clearTimeout(followTimer); followTimer = setTimeout(() => { try { followSlate(); } catch (e) { console.error(`[canvas] following the slate: ${e.message}`); } }, 1500); };
  // (the slate's folder is read, never written - nothing is made there: its file names and times are looked at instead)
  let slateSig = null;
  const slateShape = () => ['scenes', 'removed'].map((n) => {
    try { const d = path.join(slateDir, n); return fs.readdirSync(d).filter((f) => f.endsWith('.json')).map((f) => `${f}:${Math.round(fs.statSync(path.join(d, f)).mtimeMs)}`).join(','); } catch { return '-'; }
  }).join('|');
  setInterval(() => { const sig = slateShape(); if (slateSig !== null && sig !== slateSig) followSoon(); slateSig = sig; }, 4000).unref();

  // ---------- the film's frame: one aspect for every scene (the project's format - a vertical show is 9:16) ----------
  // library/format.json = the one picked here ({aspect}); without it, Scene Slate's show says (its format "Vertical..."
  // or an aspect), else 16:9. Every scene's meta.width x meta.height follows it: the shot camera, the Cam view, the
  // prompts' frame line and the frames KAI shows on its cards are all cut to it.
  const FRAMES = { '16:9': [1280, 720], '9:16': [720, 1280], '1:1': [1080, 1080], '4:5': [1080, 1350], '4:3': [1280, 960], '2.39:1': [1280, 536] };
  const formatFile = path.join(libDir, 'format.json');
  function filmFormat() {
    const own = readJsonFile(formatFile);
    if (own && FRAMES[own.aspect]) return { aspect: own.aspect, from: 'board' };
    const show = readJsonFile(path.join(slateDir, 'show.json'));
    if (show) {
      const t = `${show.title?.format || ''} ${show.title?.aspect || ''} ${show.aspect || ''}`;
      if (/vertical|portrait|9\s*[:x]\s*16/i.test(t)) return { aspect: '9:16', from: 'slate' };
      const m = t.match(/\b(16:9|1:1|4:5|4:3|2\.39:1)\b/);
      if (m) return { aspect: m[1], from: 'slate' };
    }
    return { aspect: '16:9', from: 'default' };
  }
  function fitFormat(d) {   // a scene's frame made the film's; true = it changed
    const [width, height] = FRAMES[filmFormat().aspect];
    if (d?.meta?.width === width && d?.meta?.height === height) return false;
    d.meta = { ...d.meta, width, height };
    return true;
  }
  /** A slate scene as it stands now (authored + edits), in the shape the Slate panel fills shots from. */
  function slateScene(id) {
    if (!SLATE_ID.test(String(id || ''))) return null;
    const b = readJsonFile(path.join(slateDir, 'scenes', `${id}.json`)); if (!b) return null;
    const o = readJsonFile(path.join(slateDir, 'data', 'scenes', `${id}.json`)) || {};
    const g = { ...(b.globals || {}), ...(o.globals || {}) };
    const byId = new Map((b.shots || []).map((s) => [s.id, s]));
    const order = o.order?.length ? o.order.filter((x) => byId.has(x)) : [...byId.keys()];
    for (const k of byId.keys()) if (!order.includes(k)) order.push(k);
    const text = (v) => Array.isArray(v) ? v.map((x) => (x.who ? `${x.who}: ` : '') + (x.line || '')).join('\n') : String(v ?? '');
    const shots = order.map((sid) => {
      const s = { ...byId.get(sid), ...Object.fromEntries(Object.entries((o.shots || {})[sid] || {}).filter(([k]) => k !== 'editedAt')) };
      return { name: `${s.id}${s.type ? ` ${s.type}` : ''}`, props: { slate_shot: s.id, slate_type: s.type || '', slate_sec: String(s.sec ?? ''), slate_frame: s.frame || '',
        slate_action: s.action || '', slate_acting: s.acting || '', slate_camera: s.camera || '', slate_light: [s.light, s.bg ? `Background: ${s.bg}` : ''].filter(Boolean).join(' '),
        slate_dialogue: text(s.dialogue) } };
    });
    const scene = { id, ep: b._ep, sc: b._sc, title: b.title || id, location: g.location || '', blocking: g.blocking || '', shots, byId: true };
    return { scene, hash: crypto.createHash('sha1').update(JSON.stringify(scene)).digest('hex').slice(0, 12) };
  }
  const pad2 = (n) => String(n).padStart(2, '0');
  /** The board scene staged from a slate scene: by its link, else the one named like it (EP01 / SC02). */
  function boardSceneFor(id, b) {
    const want = { ep: `EP${pad2(b._ep)}`, sc: `SC${pad2(b._sc)}` };
    let named = null;
    for (const e of libraryOnDisk().episodes) for (const s of e.scenes) {
      const m = readJsonFile(path.join(libDir, e.name, `${s.name}.json`))?.meta || {};
      if (m.slate === id) return { ep: e.name, sc: s.name, linked: true };
      if (e.name === want.ep && (s.name === want.sc || s.name.startsWith(`${want.sc} `)) && !m.slate) named = { ep: e.name, sc: s.name, linked: false };
    }
    return named || { ...want, missing: true };
  }
  const setMeta = (patch, source) => { if (lockedBy()) throw lockError(); doc = { ...doc, meta: { ...doc.meta, ...patch } }; rev++; persist(); broadcast('doc', { doc, rev, source }); };

  // ---------- KAI: kai-index.json, what this film has, for Blocking Board's panel and cards in KAI (see kai-plugin.json) ----------
  // { plugin, updated, groups: [{ name: <Episode>, items: [{ key: "EP/SC", label, title, info, open: {ep, sc},
  //   main: {file}, frames: [{key, name, file}] }] }] } - files relative to this folder; KAI adds their refs.
  const framesDir = path.join(path.dirname(scenePath), 'frames');
  const kaiIndexPath = path.join(path.dirname(scenePath), 'kai-index.json');
  const rel = (f) => path.relative(path.dirname(scenePath), f).split(path.sep).join('/');
  const frameOrder = (k) => k === 'main' ? '' : k.replace(/_start$/, '_0').replace(/_end$/, '_1');
  const frameName = (k) => { if (k === 'main') return 'Main keyframe'; const m = k.match(/^(\d+)_(.+)_(start|end)$/); return m ? `${+m[1]}. ${m[2].replace(/-/g, ' ')} · ${m[3]}` : k.replace(/_/g, ' '); };
  function writeKaiIndex() {
    clearTimeout(kaiIndexTimer); kaiIndexTimer = null;
    try {
      const groups = listLibrary().episodes.map((e) => ({
        name: e.name,
        items: e.scenes.map((s) => {
          if (s.virtual) return { key: `${e.name}/${s.name}`, label: `🎬 ${e.name} › ${s.name}`, title: s.title || '', info: `${s.shots} shot${s.shots === 1 ? '' : 's'} · not staged yet`,
            open: { slate: s.slate }, main: null, frames: [], slate: s.slate };
          let title = '', slate = null;
          try { const lj = JSON.parse(fs.readFileSync(path.join(libDir, e.name, `${s.name}.json`), 'utf8')); title = lj.slate?.scene?.title || ''; slate = lj.meta?.slate || null; } catch {}
          const fd = path.join(framesDir, e.name, s.name);
          let keys = [];
          try { keys = fs.readdirSync(fd).filter((f) => f.endsWith('.png')).map((f) => f.slice(0, -4)); } catch {}
          keys.sort((x, y) => natural(frameOrder(x), frameOrder(y)));
          const frames = keys.map((k) => ({ key: k, name: frameName(k), file: rel(path.join(fd, `${k}.png`)) }));
          const thumb = path.join(libDir, e.name, `${s.name}.png`);
          const main = frames.find((f) => f.key === 'main') || frames[0] || (fs.existsSync(thumb) ? { file: rel(thumb) } : null);
          const pj = path.join(promptsRoot, e.name, `${s.name}.json`);
          return { key: `${e.name}/${s.name}`, label: `🎬 ${e.name} › ${s.name}`, title, info: `${s.shots} shot${s.shots === 1 ? '' : 's'}`,
            open: { ep: e.name, sc: s.name }, main, frames, ...(slate ? { slate } : {}), ...(fs.existsSync(pj) ? { prompts: { data: rel(pj) } } : {}) };
        }),
      }));
      const text = JSON.stringify({ plugin: 'blocking-board', updated: new Date().toISOString(), groups }, null, 2) + '\n';
      fs.writeFileSync(kaiIndexPath + '.tmp', text); fs.renameSync(kaiIndexPath + '.tmp', kaiIndexPath);
    } catch (e) { console.error(`[canvas] kai-index: ${e.message}`); }
  }
  let kaiIndexTimer = null;
  function scheduleKaiIndex() { clearTimeout(kaiIndexTimer); kaiIndexTimer = setTimeout(writeKaiIndex, 1500); }

  // ---------- locations: one set shared by many scenes, with states ----------
  // scenes/library/_locations/<Name>.json = { name, env, objects, states: { <State>: { objects: { id: object | null },
  // add: [objects], env } } }. A scene names its location in meta.location = { name, state, edit }; its file keeps only
  // its own objects, and opening it puts the location in (as it is now, in the scene's state), marked loc: true.
  // edit 'scene': the location is locked in the app and nothing is written to it; edit 'location': changes to its
  // objects (and new loc objects) go into the location - into the scene's state if it has one, else the base.
  const locDir = path.join(libDir, '_locations');
  const LOC_ENV = ['background', 'ground', 'grid', 'fog', 'sun', 'plan', 'sky'];
  const locFile = (n) => path.join(locDir, `${libName(n, 'a location')}.json`);
  const readLoc = (n) => JSON.parse(fs.readFileSync(locFile(n), 'utf8'));
  function writeLoc(L) {
    fs.mkdirSync(locDir, { recursive: true });
    const f = locFile(L.name);
    fs.writeFileSync(f + '.tmp', JSON.stringify(L, null, 2) + '\n');
    fs.renameSync(f + '.tmp', f);
    noteOwn(f);
  }
  function locObjects(L, state) {
    const st = (state && L.states?.[state]) || {}, ov = st.objects || {}, out = [];
    for (const o of L.objects || []) { if (ov[o.id] === null) continue; out.push({ ...(ov[o.id] || o), loc: true }); }
    for (const o of st.add || []) out.push({ ...o, loc: true });
    return out;
  }
  const locEnv = (L, state) => ({ ...(L.env || {}), ...((state && L.states?.[state]?.env) || {}) });
  // a scene's own part + its location -> what the editor works on
  function compose(d) {
    const ref = d.meta?.location;
    if (!ref?.name) return d;
    let L; try { L = readLoc(ref.name); } catch { return d; }
    const own = (d.objects || []).filter((o) => !o.loc), taken = new Set(own.map((o) => o.id));
    return { ...d, env: { ...d.env, ...locEnv(L, ref.state) }, objects: [...locObjects(L, ref.state).filter((o) => !taken.has(o.id)), ...own] };
  }
  // the open scene -> its own part (returned) and, when editing the location, the location written back
  function splitLocation(d) {
    const ref = d.meta?.location;
    if (!ref?.name) return d;
    if (ref.edit === 'location') {
      let L; try { L = readLoc(ref.name); } catch { L = null; }
      if (L) {
        const mine = d.objects.filter((o) => o.loc).map(({ loc, ...rest }) => rest);
        const envPart = Object.fromEntries(LOC_ENV.filter((k) => d.env[k] !== undefined).map((k) => [k, d.env[k]]));
        const same = (a, b) => JSON.stringify(a) === JSON.stringify(b);
        if (ref.state) { // the state keeps what differs from the base
          const st = ((L.states ||= {})[ref.state] ||= {});
          const byId = new Map(mine.map((o) => [o.id, o])), base = L.objects || [], baseIds = new Set(base.map((o) => o.id));
          st.objects = {};
          for (const b of base) { const o = byId.get(b.id); if (!o) st.objects[b.id] = null; else if (!same(o, b)) st.objects[b.id] = o; }
          st.add = mine.filter((o) => !baseIds.has(o.id));
          st.env = Object.fromEntries(Object.entries(envPart).filter(([k, v]) => !same(v, L.env?.[k])));
        } else { L.objects = mine; L.env = envPart; }
        writeLoc(L);
      }
    }
    return { ...d, objects: d.objects.filter((o) => !o.loc) };
  }
  function listLocations() {
    let files = [];
    try { files = fs.readdirSync(locDir).filter((f) => f.endsWith('.json')); } catch {}
    const users = {}; // location -> scenes using it
    for (const ep of libraryOnDisk().episodes) for (const sc of ep.scenes) {
      try { const m = JSON.parse(fs.readFileSync(libFile(ep.name, sc.name), 'utf8')).meta?.location; if (m?.name) (users[m.name] ||= []).push({ ep: ep.name, sc: sc.name, state: m.state || null }); } catch {}
    }
    return files.map((f) => {
      let L = {}; try { L = JSON.parse(fs.readFileSync(path.join(locDir, f), 'utf8')); } catch {}
      const name = f.slice(0, -5);
      return { name, objects: (L.objects || []).length, states: Object.keys(L.states || {}), scenes: users[name] || [] };
    }).sort((a, b) => natural(a.name, b.name));
  }
  // the open scene re-made with another location / state (its own part kept); undo starts over
  function useLocation(name, state, edit = 'scene') {
    writeLib();
    const d = JSON.parse(JSON.stringify(doc));
    d.objects = d.objects.filter((o) => !o.loc);
    if (name) d.meta.location = { name, state: state || null, edit }; else delete d.meta.location;
    undo.length = 0; redo.length = 0;
    doc = migrate(compose(d)); rev++;
    persist();
    broadcast('doc', { doc, rev, source: 'scene', label: name ? `location ${name}${state ? ` / ${state}` : ''}` : 'no location' });
    pushLibrary();
  }
  // the KAI project this film belongs to (its Higgsfield elements are the film's element library)
  const KAI = process.env.KAI_URL || 'http://127.0.0.1:8420';
  // linked by hand (library/.kai.json), else - started by KAI - the project KAI started it in: its main canvas in
  // KAI_PROJECT_DIR (<project>\\KAI\\<name>.kzcanvas), so the film's elements show without picking anything
  const kaiLink = () => {
    try { const l = JSON.parse(fs.readFileSync(path.join(libDir, '.kai.json'), 'utf8')); if (l?.key) return l; } catch {}
    const dir = process.env.KAI_PROJECT_DIR;
    if (!dir) return {};
    try {
      const main = fs.readdirSync(dir).filter((f) => f.toLowerCase().endsWith('.kzcanvas')).sort()[0];
      if (!main) return {};
      const p = path.join(dir, main);
      let name = path.basename(main, '.kzcanvas');
      try { name = JSON.parse(fs.readFileSync(p, 'utf8')).name || name; } catch {}
      return { key: `ext:${p}`, name, auto: true };
    } catch { return {}; }
  };
  // open another scene: the open one is written back first; undo starts over (each scene has its own story)
  function openScene(ep, sc) {
    writeLib();
    const f = libFile(ep, sc);
    const next = migrate(compose(migrate(JSON.parse(fs.readFileSync(f, 'utf8')))));
    next.meta = { ...next.meta, ep: path.basename(path.dirname(f)), sc: path.basename(f, '.json') };
    const reframed = fitFormat(next);
    undo.length = 0; redo.length = 0;
    doc = next; rev++;
    if (reframed) scheduleLibWrite();
    setSavesDir();
    persist();
    broadcast('doc', { doc, rev, source: 'scene', label: `open ${next.meta.ep} / ${next.meta.sc}` });
    lockChanged();
    broadcast('saves', { saves: listSaves() });
    pushLibrary();
  }
  // Autosave into the named version you are on (scenes/saved/<meta.name>.json), so a saved version never goes stale.
  let autosaveTimer = null;
  function scheduleAutosave() {
    clearTimeout(autosaveTimer);
    autosaveTimer = setTimeout(autosaveNow, 800);
  }
  function autosaveNow() {
    autosaveTimer = null;
    {
      const n = doc.meta?.name;
      if (!n || n === 'untitled' || !/^[a-z0-9._-]+$/.test(n)) return;
      const file = path.join(savesDir, `${n}.json`);
      if (!fs.existsSync(file)) return; // only versions that were saved once
      try {
        fs.writeFileSync(file, JSON.stringify({ ...doc, meta: { ...doc.meta, savedAs: n, savedAt: new Date().toISOString() } }, null, 2) + '\n');
        broadcast('saves', { saves: listSaves() });
      } catch (e) { console.error(`[canvas] autosave to ${file} failed: ${e.message}`); }
    }
  }
  // nothing is lost when Blocking Board is stopped: scene.json is written at once on every change; the scene's library file and
  // its saved version follow a moment later - so they're written now (from scene.json) and again on the way out
  const flushAll = () => { try { if (libTimer) writeLib(); } catch {} try { if (kaiIndexTimer) writeKaiIndex(); } catch {} try { if (autosaveTimer) { clearTimeout(autosaveTimer); autosaveTimer = null; autosaveNow(); } } catch {} };
  process.once('exit', flushAll);
  for (const sig of ['SIGINT', 'SIGTERM', 'SIGBREAK', 'SIGHUP']) { try { process.once(sig, () => { flushAll(); process.exit(0); }); } catch {} }
  // the first run: the open scene becomes EP01 / SC01 of the library
  if (!doc.meta?.ep || !doc.meta?.sc) {
    let eps = [];
    try { eps = fs.readdirSync(libDir).filter((n) => !n.startsWith('.')); } catch {}
    if (!eps.length) doc = { ...doc, meta: { ...doc.meta, ep: 'EP01', sc: 'SC01' } };
  }
  setSavesDir();
  readLocks(); lockWas = lockedBy();
  // work that arrived while this was closed: the scene's library file is newer than scene.json -> that is the scene
  try {
    const lf = libFile(doc.meta.ep, doc.meta.sc);
    if (fs.existsSync(scenePath) && fs.statSync(lf).mtimeMs > fs.statSync(scenePath).mtimeMs + 3000) {
      const { ep, sc } = doc.meta;
      doc = migrate(compose(migrate(JSON.parse(fs.readFileSync(lf, 'utf8'))))); doc.meta = { ...doc.meta, ep, sc };
      noteOwn(lf); log('the scene was changed elsewhere while this was closed: opened from the library');
    }
  } catch {}
  if (fitFormat(doc)) { log(`frame: ${filmFormat().aspect}`); scheduleLibWrite(); }
  persist();
  followSoon();   // (the slate may have changed shape while this was closed)
  writeLib();
  writeKaiIndex();
  fs.mkdirSync(kaiDir, { recursive: true }); fs.mkdirSync(libDir, { recursive: true });
  try { fs.watch(kaiDir, () => { readLocks(); lockChanged(); }); } catch {}
  let slateTimer = null;
  const slateTouched = () => { clearTimeout(slateTimer); slateTimer = setTimeout(() => { slateCache.at = 0; pushLibrary(); }, 1200); };
  try { fs.mkdirSync(path.join(slateDir, 'scenes'), { recursive: false }); } catch {}
  try { fs.watch(path.join(slateDir, 'scenes'), slateTouched); } catch {}
  try { fs.watch(libDir, { recursive: true }, (ev, name) => { if (name && /\.json$/i.test(name)) libraryTouched(path.join(libDir, name)); }); } catch {}

  // amend: a bookkeeping change (e.g. the browser recording an audio file's length) that is not an undo step
  function commit(next, source, label, { amend = false } = {}) {
    if (lockedBy()) throw lockError();
    if (doc?.meta?.ep && doc.meta.sc && (next.meta?.ep !== doc.meta.ep || next.meta?.sc !== doc.meta.sc)) {
      next = { ...next, meta: { ...next.meta, ep: doc.meta.ep, sc: doc.meta.sc, ...(doc.meta.location && !next.meta?.location ? { location: doc.meta.location } : {}),
        ...(doc.meta.slate && !next.meta?.slate ? { slate: doc.meta.slate, slateHash: doc.meta.slateHash } : {}) } };
    }
    if (!amend) {
      undo.push(doc); if (undo.length > 200) undo.shift();
      redo.length = 0;
    }
    doc = next; rev++;
    persist();
    broadcast('doc', { doc, rev, source, label });
  }

  // Agents may also edit scene.json by hand: pick that up.
  fs.watchFile(scenePath, { interval: 400 }, () => {
    let text;
    try { text = fs.readFileSync(scenePath, 'utf8'); } catch { return; }
    if (text === lastWritten) return;
    try {
      const next = migrate(JSON.parse(text));
      log('scene.json changed on disk, reloading');
      commit(next, 'file', 'edit scene.json');
    } catch (e) {
      broadcast('say', { from: 'system', text: `scene.json has an error and was not loaded: ${e.message}`, kind: 'error', at: Date.now() });
    }
  });

  // Reload open tabs when the agent edits the app (new controls etc.).
  let reloadTimer;
  for (const dir of ['app', 'core']) {
    try {
      fs.watch(path.join(ROOT, dir), { recursive: true }, () => {
        clearTimeout(reloadTimer);
        reloadTimer = setTimeout(() => broadcast('reload', { at: Date.now() }), 250);
      });
    } catch {}
  }

  // ---------- named saves ----------
  const saveName = (s) => {
    const n = String(s || '').trim().toLowerCase().replace(/\.json$/, '').replace(/[^a-z0-9._-]+/g, '-').replace(/^[-.]+|[-.]+$/g, '');
    if (!n) throw Object.assign(new Error('a save needs a name'), { status: 400 });
    return n.slice(0, 80);
  };
  function listSaves() {
    let files = [];
    try { files = fs.readdirSync(savesDir).filter((f) => f.endsWith('.json')); } catch { return []; }
    return files.map((f) => {
      const file = path.join(savesDir, f), name = f.slice(0, -5);
      let objects = 0, keys = 0, savedAt = null;
      try { const d = JSON.parse(fs.readFileSync(file, 'utf8')); objects = d.objects?.length || 0; keys = d.timeline?.keys?.length || 0; savedAt = d.meta?.savedAt || null; } catch {}
      const mtime = fs.statSync(file).mtimeMs;
      const rel = path.relative(savesRoot, path.join(savesDir, `${name}.png`));
      const thumb = fs.existsSync(path.join(savesDir, `${name}.png`)) ? `/saved/${urlOf(rel)}?v=${Math.round(mtime)}` : null;
      return { name, path: file, savedAt: savedAt || new Date(mtime).toISOString(), objects, keys, thumb };
    }).sort((a, b) => b.savedAt.localeCompare(a.savedAt));
  }

  // ---------- event stream ----------
  const clients = new Map(); // id -> { res, connectedAt, lastSeen, visible }
  function send(res, event, data) { res.write(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`); }
  function broadcast(event, data) { for (const c of clients.values()) send(c.res, event, data); }
  setInterval(() => { for (const c of clients.values()) c.res.write(': ping\n\n'); }, 15000).unref();

  function pickClient() {
    const list = [...clients.entries()];
    if (!list.length) return null;
    list.sort((a, b) => (b[1].visible - a[1].visible) || (b[1].lastSeen - a[1].lastSeen));
    return list[0];
  }

  // ---------- RPC to the browser ----------
  const pending = new Map(); // rpc id -> { resolve, reject, timer }
  let rpcSeq = 0;
  function rpc(method, params = {}, timeoutMs = 30000) {
    const target = pickClient();
    if (!target) return Promise.reject(Object.assign(new Error(`no canvas tab is open. Open http://${host}:${port} (or run: canvas open)`), { status: 409 }));
    const id = `r${++rpcSeq}`;
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => { pending.delete(id); reject(new Error(`${method} timed out after ${timeoutMs / 1000}s`)); }, timeoutMs);
      pending.set(id, { resolve, reject, timer });
      send(target[1].res, 'rpc', { id, method, params });
    });
  }

  // ---------- prompt inbox ----------
  let prompts = [];
  try { prompts = fs.readFileSync(inboxPath, 'utf8').split('\n').filter(Boolean).map((l) => JSON.parse(l)); } catch {}
  const savePrompts = () => fs.writeFileSync(inboxPath, prompts.map((p) => JSON.stringify(p)).join('\n') + (prompts.length ? '\n' : ''));
  const waiters = []; // long-polling agents
  let lastAgentPoll = 0;
  const listenPath = path.join(workDir, 'listen.json');
  // Listen mode belongs to one agent session (the one that turned it on), so a Stop hook installed for every
  // Claude Code session (the plugin) only ever holds that session open, never an unrelated one.
  let listen = false, listenSession = null, listenCwd = null;
  try { ({ on: listen, session: listenSession = null, cwd: listenCwd = null } = JSON.parse(fs.readFileSync(listenPath, 'utf8'))); listen = !!listen; } catch {}
  const agentListening = () => waiters.length > 0 || Date.now() - lastAgentPoll < 3000;
  // "Working" while the agent holds a prompt. In listen mode the agent comes back to poll as soon as it
  // finishes (the Stop hook or `canvas wait`), so a taken prompt means it is still busy, even while it is
  // only thinking and touching nothing; give up after 30 minutes in case the session was closed. Without
  // listen mode, fall back to 2 minutes since the last thing the agent did.
  let lastAgentActivity = 0;
  const touchAgent = () => { lastAgentActivity = Date.now(); };
  const agentWorking = () => {
    const taken = prompts.filter((p) => p.status === 'taken');
    if (!taken.length) return false;
    if (Date.now() - lastAgentActivity < 120000) return true;
    return listen && taken.some((p) => Date.now() - (p.takenAt || 0) < 30 * 60000);
  };
  // Listen mode stays on in listen.json after its session quits. Count it as live only while that agent
  // shows signs of life: polling now, holding a prompt, or active in the last two minutes (for example the
  // turn that turned listening on, before its first Stop hook polls).
  const listenLive = () => listen && (agentListening() || agentWorking() || Date.now() - Math.max(lastAgentActivity, lastAgentPoll) < 120000);
  const launch = launchInfo();
  const statusPayload = () => ({ agent: agentListening(), working: !agentListening() && agentWorking(), listen, listenLive: listenLive(), launch, listenSession, listenCwd, pid: process.pid, waiting: waiters.length, queued: prompts.filter((p) => p.status === 'pending').length, jobs: runningJobs().length, rev });
  let lastStatus = '';
  const pushStatus = () => { const s = JSON.stringify(statusPayload()); if (s !== lastStatus) { lastStatus = s; broadcast('status', statusPayload()); } };
  setInterval(pushStatus, 2000).unref();

  // The agent asking for the next prompt means it has finished the ones it already took.
  function closeTaken() {
    for (const p of prompts) {
      if (p.status !== 'taken') continue;
      p.status = 'done'; p.doneAt = Date.now(); p.autoClosed = true;
      broadcast('prompt', p);
    }
    savePrompts();
  }

  function takePrompt() {
    const p = prompts.find((x) => x.status === 'pending');
    if (!p) return null;
    p.status = 'taken'; p.takenAt = Date.now();
    savePrompts();
    broadcast('prompt', p);
    return p;
  }
  function deliverToWaiters() {
    while (waiters.length && prompts.some((p) => p.status === 'pending')) {
      const w = waiters.shift();
      clearTimeout(w.timer);
      w.resolve(takePrompt());
    }
    pushStatus();
  }
  const progress = new Map(); // progress card id -> its latest state
  for (const m of readTail(logPath, Infinity)) if (m.kind === 'progress' && m.progress) progress.set(m.progress.id, m.progress);
  // Jobs the agent started and has not ended. The Stop hook uses this so a session cannot go idle on a
  // running job and leave its result unreported. One with no update for two hours is taken as abandoned.
  const postProgress = (p) => {
    progress.set(p.id, p);
    const entry = { from: 'agent', kind: 'progress', text: p.title, progress: p, at: p.updatedAt };
    appendLog(entry);
    broadcast('say', entry);
  };
  // "Still working" (canvas say --working) is a promise to come back. It becomes a card with a clock, and
  // counts as a running job until the agent's next real reply or question, so the Stop hook holds it to that.
  const autoCards = () => [...progress.values()].filter((p) => p.auto && p.state === 'running');
  const stillWorking = (text) => {
    const now = Date.now(), note = String(text).trim().slice(0, 200);
    const mine = autoCards()[0];
    if (!mine && runningJobs().length) return false; // the agent keeps its own card: leave the message as it is
    postProgress(mine ? { ...mine, note, updatedAt: now } : { id: `g${now.toString(36)}${crypto.randomBytes(2).toString('hex')}`, title: 'Working', note, state: 'running', auto: true, startedAt: now, updatedAt: now });
    return true;
  };
  const endAutoCards = () => { const now = Date.now(); for (const p of autoCards()) postProgress({ ...p, state: 'done', endedAt: now, updatedAt: now }); };
  const runningJobs = () => [...progress.values()].filter((p) => p.state === 'running' && Date.now() - (p.updatedAt || p.startedAt) < 2 * 3600000)
    .map((p) => ({ id: p.id, title: p.title, ...(p.auto ? { auto: true, note: p.note } : {}), startedAt: p.startedAt, updatedAt: p.updatedAt || p.startedAt }));
  function appendLog(entry) { fs.appendFileSync(logPath, JSON.stringify(entry) + '\n'); }

  // ---------- chat history ----------
  // "New chat" archives the finished conversation (your prompts and the agent's replies) to
  // .canvas/chats/<id>.json, so past chats can be read again in the chat panel or with `canvas chats`.
  const chatsDir = path.join(workDir, 'chats');
  const CURRENT = 100; // messages of each kind the open chat shows
  const chatTitle = (ps, ms) => {
    const first = ps.find((p) => p.text?.trim()) || ms.find((m) => m.text?.trim());
    const t = (first?.text || (ps.length ? 'Images' : 'Chat')).trim().replace(/\s+/g, ' ');
    return t.length > 80 ? `${t.slice(0, 79)}…` : t;
  };
  function archiveChat(ps, ms, id = String(Date.now())) {
    if (!ps.length && !ms.length) return null;
    const ats = [...ps, ...ms].map((x) => x.at).filter(Number.isFinite);
    const chat = { id, title: chatTitle(ps, ms), startedAt: Math.min(...ats, Date.now()), endedAt: Math.max(...ats, 0) || Date.now(), prompts: ps, messages: ms };
    fs.mkdirSync(chatsDir, { recursive: true });
    fs.writeFileSync(path.join(chatsDir, `${id}.json`), JSON.stringify(chat) + '\n');
    return chat;
  }
  // Earlier versions kept only the agent's side of an old chat, as .canvas/log-<time>.jsonl: move those in.
  try {
    for (const f of fs.readdirSync(workDir)) {
      const m = /^log-(\d+)\.jsonl$/.exec(f);
      if (!m) continue;
      archiveChat([], readTail(path.join(workDir, f), Infinity), m[1]);
      fs.unlinkSync(path.join(workDir, f));
    }
  } catch {}
  const readChat = (id) => {
    if (!/^[\w-]+$/.test(String(id || ''))) return null;
    try { return JSON.parse(fs.readFileSync(path.join(chatsDir, `${id}.json`), 'utf8')); } catch { return null; }
  };
  function listChats() {
    let files = [];
    try { files = fs.readdirSync(chatsDir).filter((f) => f.endsWith('.json')); } catch {}
    return files.map((f) => readChat(f.slice(0, -5))).filter(Boolean)
      .map(({ id, title, startedAt, endedAt, prompts: ps = [], messages: ms = [] }) => ({ id, title, startedAt, endedAt, count: ps.length + ms.length }))
      .sort((a, b) => b.endedAt - a.endedAt);
  }
  // A progress card is logged once per update. The open chat gets each card once: its latest state, at the
  // place in the conversation where it first appeared.
  const foldProgress = (ms) => {
    const last = new Map(), first = new Map();
    for (const m of ms) if (m.kind === 'progress' && m.progress) { last.set(m.progress.id, m); if (!first.has(m.progress.id)) first.set(m.progress.id, m.at); }
    return ms.flatMap((m) => (m.kind !== 'progress' || !m.progress ? [m] : first.get(m.progress.id) === m.at && last.has(m.progress.id) ? (() => { const l = last.get(m.progress.id); last.delete(m.progress.id); return [{ ...l, at: m.at }]; })() : []));
  };
  const currentChat = () => ({ prompts: prompts.slice(-CURRENT), messages: foldProgress(readTail(logPath, Infinity)).slice(-CURRENT) });

  // ---------- http ----------
  const readBody = (req, limit = 512 * 1024 * 1024) => new Promise((resolve, reject) => {
    const chunks = []; let n = 0;
    req.on('data', (c) => { n += c.length; if (n > limit) { reject(new Error('body too large')); req.destroy(); } else chunks.push(c); });
    req.on('end', () => resolve(Buffer.concat(chunks)));
    req.on('error', reject);
  });
  const readJson = async (req) => { const b = await readBody(req, 50 * 1024 * 1024); return b.length ? JSON.parse(b.toString('utf8')) : {}; };
  const json = (res, status, body) => { res.writeHead(status, { 'content-type': 'application/json', 'cache-control': 'no-store' }); res.end(JSON.stringify(body)); };

  // Files are served whole, or in part for a Range request: video players need ranges to seek (Safari to play at all).
  async function serveFile(res, file, req) {
    try {
      const type = MIME[path.extname(file).toLowerCase()] || 'application/octet-stream';
      const m = /^bytes=(\d*)-(\d*)$/.exec(req?.headers.range || '');
      if (m && (m[1] || m[2])) {
        const { size } = await fsp.stat(file);
        let start = m[1] ? Number(m[1]) : Math.max(0, size - Number(m[2]));
        let end = m[1] && m[2] ? Math.min(Number(m[2]), size - 1) : size - 1;
        if (start >= size || start > end) { res.writeHead(416, { 'content-range': `bytes */${size}` }); return res.end(); }
        res.writeHead(206, { 'content-type': type, 'cache-control': 'no-cache', 'accept-ranges': 'bytes', 'content-range': `bytes ${start}-${end}/${size}`, 'content-length': end - start + 1 });
        return fs.createReadStream(file, { start, end }).pipe(res);
      }
      const data = await fsp.readFile(file);
      res.writeHead(200, { 'content-type': type, 'cache-control': 'no-cache', 'accept-ranges': 'bytes' });
      res.end(data);
    } catch { res.writeHead(404); res.end('not found'); }
  }
  const within = (base, rel) => { const f = path.resolve(base, '.' + path.sep + rel); return f.startsWith(base + path.sep) || f === base ? f : null; };

  // What a chat reply can carry, and how the chat shows it.
  const CHAT_FILE = { '.mp4': 'video', '.webm': 'video', '.mov': 'video', '.png': 'image', '.jpg': 'image', '.jpeg': 'image', '.webp': 'image', '.gif': 'image' };
  const chatFile = (file, name) => ({ file, name: name || file.replace(/^[a-z0-9]+-[a-f0-9]{6}-/, ''), type: CHAT_FILE[path.extname(file).toLowerCase()], url: `/uploads/${file}`, path: path.join(uploadsDir, file) });

  const STATIC = [
    ['/vendor/three/', path.join(ROOT, 'node_modules', 'three')],
    ['/core/', path.join(ROOT, 'core')],
    ['/exports/', exportsDir],
    ['/saved/', savesRoot],
    ['/uploads/', uploadsDir],
    ['/audio/', audioDir],
    ['/models/', modelsDir],
    ['/library/', libDir],
    ['/textures/', texturesDir],
    ['/', path.join(ROOT, 'app')],
  ];

  const routes = {
    'GET /api/doc': (req, res) => json(res, 200, { rev, doc }),
    'GET /api/summary': (req, res) => {
      const tl = doc.timeline;
      json(res, 200, {
        rev, scene: scenePath, exports: exportsDir, ...statusPayload(), tabs: clients.size,
        meta: doc.meta, env: doc.env,
        objects: doc.objects.map(describe),
        timeline: { duration: tl.duration, fps: tl.fps, interp: tl.interp, speed: tl.speed, start: tl.start || 0 },
        audio: doc.audio || null,
        shot: doc.shot,
        shots: shotList(doc).map((s) => ({ id: s.id, name: s.name, active: s.active, duration: s.timeline.duration, fps: s.timeline.fps, start: s.timeline.start || 0, keys: s.timeline.keys.length, off: s.off, hold: s.hold, lock: s.lock })),
        keys: tl.keys.map((k) => `${k.id} t=${k.t} pos=${k.position.join(',')} target=${k.target.join(',')} fov=${k.fov}${k.roll ? ` roll=${k.roll}` : ''} ease=${JSON.stringify(k.ease)}${pathNote(k)}${k.shudder ? ` shudder=${k.shudder.jerks} ${k.shudder.shape}s, ${k.shudder.amount}% back, ${k.shudder.over}${k.shudder.from != null || k.shudder.to != null ? `, from ${k.shudder.from ?? 0} to ${k.shudder.to ?? 1} of the segment` : ''}` : ''}`),
      });
    },
    'GET /api/jobs': (req, res) => json(res, 200, { ok: true, jobs: runningJobs() }),
    // write everything that's waiting (the scene's library file, its saved version) - KAI calls it before stopping Blocking Board
    'POST /api/flush': (req, res) => { flushAll(); json(res, 200, { ok: true }); },
    'GET /api/status': (req, res) => json(res, 200, { ...statusPayload(), tabs: clients.size, scene: scenePath, exports: exportsDir, pid: process.pid, owner: process.env.CANVAS_OWNER || null, kai_dir: path.dirname(scenePath), editing: editingPaths(), locked: lockedBy() }),

    'POST /api/op': async (req, res) => {
      const body = await readJson(req);
      const ops = body.ops ?? body;
      if (body.source !== 'ui') touchAgent();
      try {
        const { doc: next, results } = applyOps(doc, ops);
        commit(next, body.source || 'agent', body.label || [].concat(ops).map((o) => o.op).join(', '), { amend: !!body.amend });
        json(res, 200, { ok: true, rev, results });
      } catch (e) { json(res, 400, { ok: false, error: e.message }); }
    },
    'POST /api/undo': (req, res) => {
      if (lockedBy()) return json(res, 423, { ok: false, error: lockError().message });
      if (!undo.length) return json(res, 200, { ok: false, error: 'nothing to undo' });
      redo.push(doc); doc = undo.pop(); rev++; persist();
      broadcast('doc', { doc, rev, source: 'undo' });
      json(res, 200, { ok: true, rev });
    },
    'POST /api/redo': (req, res) => {
      if (lockedBy()) return json(res, 423, { ok: false, error: lockError().message });
      if (!redo.length) return json(res, 200, { ok: false, error: 'nothing to redo' });
      undo.push(doc); doc = redo.pop(); rev++; persist();
      broadcast('doc', { doc, rev, source: 'redo' });
      json(res, 200, { ok: true, rev });
    },

    // ----- named saves: scenes/saved/<name>.json (+ optional <name>.png thumbnail) -----
    'GET /api/saves': (req, res) => json(res, 200, { ok: true, dir: savesDir, saves: listSaves() }),
    'POST /api/save': async (req, res) => {
      const { name, overwrite } = await readJson(req);
      const n = saveName(name || `scene-${new Date().toISOString().slice(0, 16).replace(/[-:]/g, '').replace('T', '-')}`);
      const file = path.join(savesDir, `${n}.json`);
      if (fs.existsSync(file) && !overwrite) return json(res, 409, { ok: false, error: `a save called "${n}" already exists (overwrite it, or pick another name)`, exists: true, name: n });
      fs.mkdirSync(savesDir, { recursive: true });
      // the scene takes the save's name (shown in the Scenes menu, used for export file names); not an undo step
      if (doc.meta.name !== n) { doc = { ...doc, meta: { ...doc.meta, name: n } }; rev++; persist(); broadcast('doc', { doc, rev, source: 'save' }); }
      fs.writeFileSync(file, JSON.stringify({ ...doc, meta: { ...doc.meta, savedAs: n, savedAt: new Date().toISOString() } }, null, 2) + '\n');
      broadcast('saves', { saves: listSaves() });
      json(res, 200, { ok: true, name: n, path: file });
    },
    'POST /api/save/thumb': async (req, res, url) => {
      const n = saveName(url.searchParams.get('name'));
      if (!fs.existsSync(path.join(savesDir, `${n}.json`))) return json(res, 404, { ok: false, error: `no save "${n}"` });
      fs.writeFileSync(path.join(savesDir, `${n}.png`), await readBody(req, 5 * 1024 * 1024));
      broadcast('saves', { saves: listSaves() });
      json(res, 200, { ok: true });
    },
    // delete a save: its .json and thumbnail move to scenes/saved/.deleted/ (recoverable by hand, never listed).
    // The open scene is left as it is; if it was that save, it simply stops autosaving until saved again.
    'POST /api/save/delete': async (req, res) => {
      const { name } = await readJson(req);
      const n = saveName(name);
      const file = path.join(savesDir, `${n}.json`);
      if (!fs.existsSync(file)) return json(res, 404, { ok: false, error: `no save "${n}" (saves: ${listSaves().map((s) => s.name).join(', ') || 'none'})` });
      const bin = path.join(savesDir, '.deleted');
      fs.mkdirSync(bin, { recursive: true });
      const stamp = new Date().toISOString().replace(/[-:]/g, '').replace(/\..*/, '');
      const moved = path.join(bin, `${n}-${stamp}.json`);
      fs.renameSync(file, moved);
      const png = path.join(savesDir, `${n}.png`);
      if (fs.existsSync(png)) fs.renameSync(png, moved.replace(/\.json$/, '.png'));
      broadcast('saves', { saves: listSaves() });
      json(res, 200, { ok: true, name: n, moved, current: doc.meta?.name === n });
    },
    'POST /api/load': async (req, res) => {
      const { name } = await readJson(req);
      const n = saveName(name);
      const file = path.join(savesDir, `${n}.json`);
      let next;
      try { next = migrate(JSON.parse(fs.readFileSync(file, 'utf8'))); }
      catch (e) { return json(res, e.code === 'ENOENT' ? 404 : 400, { ok: false, error: e.code === 'ENOENT' ? `no save "${n}" (saves: ${listSaves().map((s) => s.name).join(', ') || 'none'})` : `could not read ${n}: ${e.message}` }); }
      delete next.meta.savedAs; delete next.meta.savedAt;
      next.meta.name = n;
      if (doc.meta.ep) Object.assign(next.meta, { ep: doc.meta.ep, sc: doc.meta.sc });
      commit(next, 'load', `load ${n}`); // undoable like any other change
      json(res, 200, { ok: true, name: n, rev, objects: next.objects.length, keys: next.timeline.keys.length });
    },

    // ----- the film's frame (aspect) -----
    'GET /api/format': (req, res) => { const f = filmFormat(); json(res, 200, { ok: true, ...f, width: FRAMES[f.aspect][0], height: FRAMES[f.aspect][1], choices: Object.keys(FRAMES) }); },
    // {aspect}: every scene's frame from now on; null = follow Scene Slate's show (or 16:9)
    'POST /api/format': async (req, res) => {
      const { aspect } = await readJson(req);
      if (aspect != null && !FRAMES[aspect]) return json(res, 400, { ok: false, error: `pick one of ${Object.keys(FRAMES).join(', ')}` });
      try {
        fs.mkdirSync(libDir, { recursive: true });
        if (aspect) fs.writeFileSync(formatFile, JSON.stringify({ aspect }, null, 2) + '\n'); else fs.rmSync(formatFile, { force: true });
      } catch (e) { return json(res, 500, { ok: false, error: e.message }); }
      if (fitFormat(doc)) { rev++; persist(); broadcast('doc', { doc, rev, source: 'scene', label: `frame ${filmFormat().aspect}` }); scheduleLibWrite(); }
      const f = filmFormat();
      json(res, 200, { ok: true, ...f, width: FRAMES[f.aspect][0], height: FRAMES[f.aspect][1] });
    },

    // ----- library: episodes and scenes of the film -----
    'GET /api/library': (req, res) => json(res, 200, { ok: true, dir: libDir, ...listLibrary() }),
    'POST /api/library/open': async (req, res) => {
      const { ep, sc } = await readJson(req);
      try { openScene(ep, sc); } catch (e) { return json(res, e.code === 'ENOENT' ? 404 : e.status || 400, { ok: false, error: e.code === 'ENOENT' ? `no scene "${sc}" in "${ep}"` : e.message }); }
      json(res, 200, { ok: true, ep: doc.meta.ep, sc: doc.meta.sc, rev });
    },
    // a new scene in an episode (made if needed): empty, or a copy of a scene (copy: { ep, sc }, or true = the open one)
    'POST /api/library/new': async (req, res) => {
      const { ep, sc, copy, open = true } = await readJson(req);
      let f;
      try { f = libFile(ep, sc); } catch (e) { return json(res, 400, { ok: false, error: e.message }); }
      if (fs.existsSync(f)) return json(res, 409, { ok: false, error: `"${path.basename(f, '.json')}" is already in ${path.basename(path.dirname(f))}` });
      writeLib();
      let base = createDoc();
      if (copy) {
        const from = copy === true ? doc.meta : copy;
        try { base = migrate(JSON.parse(fs.readFileSync(libFile(from.ep, from.sc), 'utf8'))); }
        catch { return json(res, 404, { ok: false, error: `no scene "${from.sc}" in "${from.ep}" to copy` }); }
      }
      base.meta = { ...base.meta, name: path.basename(f, '.json'), ep: path.basename(path.dirname(f)), sc: path.basename(f, '.json') };
      fs.mkdirSync(path.dirname(f), { recursive: true });
      fs.writeFileSync(f, JSON.stringify(base, null, 2) + '\n');
      if (open) openScene(base.meta.ep, base.meta.sc); else pushLibrary();
      json(res, 200, { ok: true, ep: base.meta.ep, sc: base.meta.sc });
    },
    'POST /api/library/episode': async (req, res) => {
      const { ep } = await readJson(req);
      let n;
      try { n = libName(ep, 'an episode'); } catch (e) { return json(res, 400, { ok: false, error: e.message }); }
      if (fs.existsSync(path.join(libDir, n))) return json(res, 409, { ok: false, error: `"${n}" already exists` });
      fs.mkdirSync(path.join(libDir, n), { recursive: true });
      pushLibrary();
      json(res, 200, { ok: true, ep: n });
    },
    // rename an episode ({ ep, to }) or a scene ({ ep, sc, to }); the open scene follows
    'POST /api/library/rename': async (req, res) => {
      const { ep, sc, to } = await readJson(req);
      try {
        writeLib();
        const name = libName(to, sc ? 'a scene' : 'an episode');
        const from = sc ? libFile(ep, sc) : path.join(libDir, libName(ep, 'an episode'));
        const dest = sc ? path.join(path.dirname(from), `${name}.json`) : path.join(libDir, name);
        if (!fs.existsSync(from)) return json(res, 404, { ok: false, error: `nothing called "${sc || ep}"` });
        if (fs.existsSync(dest)) return json(res, 409, { ok: false, error: `"${name}" already exists` });
        fs.renameSync(from, dest);
        if (sc && fs.existsSync(from.replace(/\.json$/, '.png'))) fs.renameSync(from.replace(/\.json$/, '.png'), dest.replace(/\.json$/, '.png'));
        const m = doc.meta;
        if (m.ep === path.basename(sc ? path.dirname(from) : from) && (!sc || m.sc === sc)) {
          doc = { ...doc, meta: { ...m, ...(sc ? { sc: name, name } : { ep: name }) } }; rev++;
          persist(); broadcast('doc', { doc, rev, source: 'scene' });
        }
        pushLibrary();
        json(res, 200, { ok: true });
      } catch (e) { json(res, e.status || 400, { ok: false, error: e.message }); }
    },
    // ----- merging: another scene comes into the open one -----
    // { ep, sc, gap }: its set and shots join this scene; its first shot's camera carries on from the end of this
    // scene's shot (its first key gap seconds after this one's last: the camera travels between them). The scene
    // merged in stays in the library as it was.
    'POST /api/library/merge': async (req, res) => {
      const { ep, sc, gap = 2 } = await readJson(req);
      let other;
      // (with its location's set in, as its own objects here)
      try { other = migrate(compose(migrate(JSON.parse(fs.readFileSync(libFile(ep, sc), 'utf8'))))); other.objects = other.objects.map(({ loc, ...o }) => o); }
      catch { return json(res, 404, { ok: false, error: `no scene "${sc}" in "${ep}"` }); }
      if (other.meta?.ep === doc.meta?.ep && other.meta?.sc === doc.meta?.sc) return json(res, 400, { ok: false, error: 'a scene cannot be merged into itself' });
      const next = JSON.parse(JSON.stringify(doc));
      const tl = next.timeline, T = Math.round((tl.duration + Math.max(0, Number(gap) || 0)) * 1000) / 1000; // where its action starts
      // its objects: ids kept unless taken here (then "-2", "-3"...); their moves start where its action starts
      const taken = new Set(next.objects.map((o) => o.id)), renamed = {};
      for (const o of other.objects) {
        let id = o.id, n = 2;
        while (taken.has(id)) id = `${o.id}-${n++}`;
        taken.add(id); if (id !== o.id) renamed[o.id] = id;
        next.objects.push({ ...o, id, anim: o.anim?.map((k) => ({ ...k, t: Math.round((k.t + T) * 1000) / 1000 })) });
      }
      // its active shot's camera joins this shot's timeline after the gap; its other shots come in as shots of their own
      const keyIds = new Set(tl.keys.map((k) => k.id));
      for (const k of other.timeline.keys) {
        let id = k.id, n = 2; while (keyIds.has(id)) id = `${k.id}m${n++}`; keyIds.add(id);
        const path = k.path?.around && renamed[k.path.around] ? { ...k.path, around: renamed[k.path.around] } : k.path;
        tl.keys.push({ ...k, id, t: Math.round((k.t + T) * 1000) / 1000, ...(path ? { path } : {}) });
      }
      tl.keys.sort((x, y) => x.t - y.t);
      tl.duration = Math.round((T + other.timeline.duration) * 1000) / 1000;
      const shotIds = new Set(next.shots.map((x) => x.id));
      for (const s of other.shots) {
        if (s.id === other.shot) continue;
        let id = s.id, n = 2; while (shotIds.has(id)) id = `${s.id}-${n++}`; shotIds.add(id);
        next.shots.push({ id, name: `${other.meta.sc || sc} · ${s.name}`, timeline: { ...s.timeline, start: Math.round(((s.timeline.start || 0) + T) * 1000) / 1000 },
          ...(s.off?.length ? { off: s.off.map((x) => renamed[x] || x) } : {}),
          ...(Object.keys(s.hold || {}).length ? { hold: Object.fromEntries(Object.entries(s.hold).map(([k, v]) => [renamed[k] || k, { ...v, by: renamed[v.by] || v.by }])) } : {}) });
      }
      // its elements join this scene's library
      for (const e of other.elements || []) if (!(next.elements ||= []).some((x) => x.id === e.id)) next.elements.push(e);
      try { commit(migrate(next), 'merge', `merge ${ep} / ${sc}`); }
      catch (e) { return json(res, 400, { ok: false, error: e.message }); }
      json(res, 200, { ok: true, joinedAt: T, objects: other.objects.length, renamed, duration: doc.timeline.duration });
    },

    // ----- KAI: the film's project and its Higgsfield elements (KAI runs on this PC) -----
    'GET /api/kai/projects': async (req, res) => {
      try {
        const r = await fetch(`${KAI}/api/canvas/summaries`);
        const boards = (await r.json()).boards || [];
        json(res, 200, { ok: true, link: kaiLink(), projects: boards.filter((b) => !b.parent).map((b) => ({ key: b.key, name: b.name })) });
      } catch (e) { json(res, 502, { ok: false, error: `KAI isn't running on this PC (${e.message})` }); }
    },
    'POST /api/kai/link': async (req, res) => {
      const { key, name } = await readJson(req);
      fs.mkdirSync(libDir, { recursive: true });
      fs.writeFileSync(path.join(libDir, '.kai.json'), JSON.stringify(key ? { key: String(key), name: String(name || '') } : {}, null, 2));
      broadcast('kai', kaiLink());
      json(res, 200, { ok: true, link: kaiLink() });
    },
    'GET /api/kai/elements': async (req, res) => {
      const link = kaiLink();
      if (!link.key) return json(res, 200, { ok: true, link, elements: [] });
      try {
        const r = await fetch(`${KAI}/api/hf/elements?project=${encodeURIComponent(link.key)}`);
        if (!r.ok) throw new Error(await r.text());
        json(res, 200, { ok: true, link, ...(await r.json()) });
      } catch (e) { json(res, 502, { ok: false, link, error: `couldn't read the elements from KAI (${e.message})` }); }
    },
    // an element's picture into textures/ (once; Higgsfield's pictures only)
    'POST /api/kai/picture': async (req, res) => {
      const { url, name } = await readJson(req);
      let u;
      try { u = new URL(String(url)); } catch { return json(res, 400, { ok: false, error: 'not a link' }); }
      if (u.protocol !== 'https:' || !u.hostname.endsWith('.cloudfront.net')) return json(res, 400, { ok: false, error: 'only Higgsfield element pictures' });
      try {
        const r = await fetch(u);
        if (!r.ok) throw new Error(`HTTP ${r.status}`);
        const body = Buffer.from(await r.arrayBuffer());
        const kind = body[0] === 0x89 && body[1] === 0x50 ? '.png' : body[0] === 0xff && body[1] === 0xd8 ? '.jpg' : body.toString('latin1', 8, 12) === 'WEBP' ? '.webp' : null;
        if (!kind) throw new Error('not a png, jpg or webp');
        const stem = String(name || 'element').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 40) || 'element';
        const file = `${stem}-${crypto.createHash('sha1').update(body).digest('hex').slice(0, 8)}${kind}`;
        fs.mkdirSync(texturesDir, { recursive: true });
        if (!fs.existsSync(path.join(texturesDir, file))) fs.writeFileSync(path.join(texturesDir, file), body);
        json(res, 200, { ok: true, file, url: `/textures/${file}` });
      } catch (e) { json(res, 502, { ok: false, error: `couldn't fetch the picture (${e.message})` }); }
    },

    // ----- locations -----
    'GET /api/locations': (req, res) => json(res, 200, { ok: true, current: doc.meta?.location || null, locations: listLocations() }),
    // a new location from the open scene's set (everything but people), which the scene then uses
    'POST /api/location/new': async (req, res) => {
      const { name } = await readJson(req);
      let n; try { n = libName(name, 'a location'); } catch (e) { return json(res, 400, { ok: false, error: e.message }); }
      if (fs.existsSync(locFile(n))) return json(res, 409, { ok: false, error: `there is a location "${n}" already` });
      if (doc.meta?.location?.name) return json(res, 400, { ok: false, error: `this scene already uses ${doc.meta.location.name}` });
      const set = doc.objects.filter((o) => o.type !== 'person').map(({ loc, ...o }) => o);
      writeLoc({ name: n, env: Object.fromEntries(LOC_ENV.filter((k) => doc.env[k] !== undefined).map((k) => [k, doc.env[k]])), objects: set, states: {} });
      doc = { ...doc, objects: doc.objects.filter((o) => o.type === 'person'), meta: { ...doc.meta, location: { name: n, state: null, edit: 'scene' } } };
      useLocation(n, null);
      json(res, 200, { ok: true, name: n, objects: set.length });
    },
    // { name, state }: use that location (null = none) in the open scene
    'POST /api/location/use': async (req, res) => {
      const { name, state } = await readJson(req);
      if (name) { try { const L = readLoc(name); if (state && !L.states?.[state]) return json(res, 404, { ok: false, error: `${name} has no state "${state}"` }); } catch { return json(res, 404, { ok: false, error: `no location "${name}"` }); } }
      useLocation(name || null, state || null);
      json(res, 200, { ok: true });
    },
    // a new state of the open scene's location (a copy of its current state), which the scene then uses
    'POST /api/location/state': async (req, res) => {
      const { state } = await readJson(req);
      const ref = doc.meta?.location;
      if (!ref?.name) return json(res, 400, { ok: false, error: 'this scene has no location' });
      let n; try { n = libName(state, 'a state'); } catch (e) { return json(res, 400, { ok: false, error: e.message }); }
      writeLib();
      const L = readLoc(ref.name);
      if (L.states?.[n]) return json(res, 409, { ok: false, error: `${ref.name} has a state "${n}" already` });
      (L.states ||= {})[n] = JSON.parse(JSON.stringify((ref.state && L.states[ref.state]) || { objects: {}, add: [], env: {} }));
      writeLoc(L);
      useLocation(ref.name, n, ref.edit);
      json(res, 200, { ok: true, state: n });
    },
    // edit 'scene' (the location locked) or 'location' (changes go into the location: the scene's state, else its base)
    'POST /api/location/edit': async (req, res) => {
      const { edit } = await readJson(req);
      const ref = doc.meta?.location;
      if (!ref?.name) return json(res, 400, { ok: false, error: 'this scene has no location' });
      if (!['scene', 'location'].includes(edit)) return json(res, 400, { ok: false, error: 'edit must be scene or location' });
      writeLib();
      doc = { ...doc, meta: { ...doc.meta, location: { ...ref, edit } } }; rev++;
      persist(); broadcast('doc', { doc, rev, source: 'scene' });
      json(res, 200, { ok: true, edit });
    },

    // KAI: a frame of the open scene for KAI's Blocking Board cards - frames/<Episode>/<Scene>/<name>.png (name: main = the
    // scene's main keyframe, else <nn>_<shot>_start|end). KAI reads them from the folder.
    'POST /api/frames': async (req, res, url) => {
      const { ep, sc } = doc.meta || {};
      if (!ep || !sc) return json(res, 400, { ok: false, error: 'the open scene is not in the library' });
      const name = String(url.searchParams.get('name') || '').replace(/[^\w.-]+/g, '-').replace(/^[-.]+/, '').slice(0, 80);
      if (!name) return json(res, 400, { ok: false, error: 'a frame needs a name' });
      const dir = path.join(path.dirname(scenePath), 'frames', libName(ep, 'an episode'), libName(sc, 'a scene'));
      fs.mkdirSync(dir, { recursive: true });
      const body = await readBody(req, 20 * 1024 * 1024);
      if (body[0] !== 0x89 || body[1] !== 0x50) return json(res, 400, { ok: false, error: 'a frame is a PNG' });
      fs.writeFileSync(path.join(dir, `${name}.png`), body);
      scheduleKaiIndex();
      json(res, 200, { ok: true });
    },


    // ----- Scene Slate: its scenes, staging one here, and whether the slate moved on since -----
    'GET /api/slate': (req, res) => {
      let files = []; try { files = fs.readdirSync(path.join(slateDir, 'scenes')).filter((f) => f.endsWith('.json')); } catch {}
      const cur = doc.meta?.slate || null, now = cur ? slateScene(cur) : null;
      const staged = new Map();
      for (const e of libraryOnDisk().episodes) for (const s of e.scenes) { const m = readJsonFile(path.join(libDir, e.name, `${s.name}.json`))?.meta; if (m?.slate) staged.set(m.slate, { ep: e.name, sc: s.name }); }
      const scenes = files.map((f) => readJsonFile(path.join(slateDir, 'scenes', f))).filter((b) => b && b._file)
        .sort((a, b) => (a._ep - b._ep) || (a._sc - b._sc))
        .map((b) => ({ id: b._file, ep: b._ep, sc: b._sc, title: b.title || b._file, shots: (b.shots || []).length, staged: staged.get(b._file) || null }));
      json(res, 200, { ok: true, there: scenes.length > 0, scenes, current: cur, title: now?.scene.title || null,
        changed: !!(now && now.hash !== doc.meta.slateHash), gone: !!(cur && !now) });   // (linked but never filled counts as changed)
    },
    'GET /api/slate/scene': (req, res, url) => {
      const r = slateScene(url.searchParams.get('id'));
      return r ? json(res, 200, { ok: true, ...r }) : json(res, 404, { ok: false, error: 'no such scene in Scene Slate' });
    },
    // opens the board scene of a slate scene: the linked one, the one named like it (linked now), or a new one
    'POST /api/slate/stage': async (req, res) => {
      const { id } = await readJson(req);
      const b = SLATE_ID.test(String(id || '')) ? readJsonFile(path.join(slateDir, 'scenes', `${id}.json`)) : null;
      if (!b) return json(res, 404, { ok: false, error: 'no such scene in Scene Slate' });
      const t = boardSceneFor(id, b);
      let created = false;
      if (t.missing) {
        writeLib();
        const base = createDoc(), f = libFile(t.ep, t.sc);
        base.meta = { ...base.meta, name: t.sc, ep: t.ep, sc: t.sc, slate: id };
        fs.mkdirSync(path.dirname(f), { recursive: true });
        fs.writeFileSync(f, JSON.stringify(base, null, 2) + '\n');
        created = true;
      }
      if (doc.meta?.ep !== t.ep || doc.meta?.sc !== t.sc) openScene(t.ep, t.sc);
      if (doc.meta.slate !== id) setMeta({ slate: id }, 'slate');
      json(res, 200, { ok: true, ep: t.ep, sc: t.sc, created, linked: !!t.linked });
    },
    // the shots were filled from the slate as it is now (hash), or the link is dropped (slate: null)
    'POST /api/slate/mark': async (req, res) => {
      const { hash, slate } = await readJson(req);
      if (slate === null) setMeta({ slate: undefined, slateHash: undefined }, 'slate');
      else if (hash) setMeta({ slateHash: String(hash).slice(0, 40) }, 'slate');
      json(res, 200, { ok: true });
    },

    // KAI: the open scene's prompt document - prompts/<Episode>/PROMPTS - <Scene>.md (the tab writes it from the slate
    // as it changes: every shot's keyframe, Flare, Seedance and blocking prompts). The one before is kept as .prev.
    'POST /api/prompts': async (req, res) => {
      const { ep, sc } = doc.meta || {};
      if (!ep || !sc) return json(res, 400, { ok: false, error: 'the open scene is not in the library' });
      if (lockedBy()) return json(res, 200, { ok: true, skipped: true });   // (a viewer writes nothing)
      // body: the document's text, or { text, data } - data = the same as JSON for other plugins (<Scene>.json)
      const raw = (await readBody(req, 5 * 1024 * 1024)).toString('utf8');
      let text = raw, data = null;
      if (/json/.test(req.headers['content-type'] || '')) { try { ({ text, data } = JSON.parse(raw)); } catch { return json(res, 400, { ok: false, error: 'bad JSON' }); } }
      if (typeof text !== 'string' || !text) return json(res, 400, { ok: false, error: 'no text' });
      const dir = path.join(promptsRoot, libName(ep, 'an episode')), file = path.join(dir, `PROMPTS - ${libName(sc, 'a scene')}.md`);
      fs.mkdirSync(dir, { recursive: true });
      if (data && typeof data === 'object') {
        const jf = path.join(dir, `${libName(sc, 'a scene')}.json`);
        fs.writeFileSync(jf + '.tmp', JSON.stringify({ ...data, updated: new Date().toISOString() }, null, 2) + '\n'); fs.renameSync(jf + '.tmp', jf);
        scheduleKaiIndex();
      }
      let old = null; try { old = fs.readFileSync(file, 'utf8'); } catch {}
      if (old === text) return json(res, 200, { ok: true, path: file, same: true });
      if (old != null) fs.writeFileSync(path.join(dir, `.PROMPTS - ${libName(sc, 'a scene')}.md.prev`), old);
      fs.writeFileSync(file + '.tmp', text); fs.renameSync(file + '.tmp', file);
      json(res, 200, { ok: true, path: file });
    },

    // the open scene's thumbnail (the tab sends a frame of its shot camera)
    'POST /api/library/thumb': async (req, res) => {
      const { ep, sc } = doc.meta || {};
      if (!ep || !sc) return json(res, 400, { ok: false, error: 'the open scene is not in the library' });
      fs.writeFileSync(libFile(ep, sc).replace(/\.json$/, '.png'), await readBody(req, 5 * 1024 * 1024));
      pushLibrary();
      json(res, 200, { ok: true });
    },

    'GET /api/events': (req, res, url) => {
      const id = url.searchParams.get('client') || `c${Date.now()}`;
      res.writeHead(200, { 'content-type': 'text/event-stream', 'cache-control': 'no-store', connection: 'keep-alive' });
      clients.set(id, { res, connectedAt: Date.now(), lastSeen: Date.now(), visible: true });
      send(res, 'home', { dir: path.dirname(scenePath) });
      send(res, 'lock', { by: lockedBy() }); // (which film this server is on: a tab that was on another one stops)
      send(res, 'doc', { doc, rev, source: 'connect' });
      send(res, 'status', statusPayload());
      send(res, 'history', currentChat());
      send(res, 'library', listLibrary());
      req.on('close', () => clients.delete(id));
    },
    'POST /api/presence': async (req, res) => {
      const { client, visible } = await readJson(req);
      const c = clients.get(client);
      if (c) { c.lastSeen = Date.now(); c.visible = !!visible; }
      json(res, 200, { ok: true });
    },

    'POST /api/rpc': async (req, res) => {
      const { method, params, timeout } = await readJson(req);
      touchAgent();
      try { json(res, 200, { ok: true, result: await rpc(method, params, timeout || 30000) }); }
      catch (e) { json(res, e.status || 500, { ok: false, error: e.message }); }
    },
    'POST /api/rpc/result': async (req, res) => {
      const { id, result, error } = await readJson(req);
      const p = pending.get(id);
      if (p) { pending.delete(id); clearTimeout(p.timer); error ? p.reject(new Error(error)) : p.resolve(result); }
      json(res, 200, { ok: true });
    },

    // Browser uploads a rendered file (png / mp4 / webm).
    'POST /api/upload': async (req, res, url) => {
      const name = path.basename(url.searchParams.get('name') || `file-${Date.now()}`);
      const dir = path.join(exportsRoot, sceneSub());
      fs.mkdirSync(dir, { recursive: true });
      const file = path.join(dir, name);
      await fsp.writeFile(file, await readBody(req));
      let out = file;
      const tc = url.searchParams.get('transcode');
      if (tc === 'h264') out = transcodeH264(file) || file;
      else if (tc === 'aac') out = transcodeAac(file) || file;
      json(res, 200, { ok: true, path: out, url: `/exports/${urlOf(path.relative(exportsRoot, out))}` });
    },

    // An audio file for the timeline: saved under the scene folder's audio/ by a name made from the file's
    // name and content, so loading the same file twice reuses it. The caller then sets it with the audio op.
    'POST /api/audio': async (req, res, url) => {
      const orig = path.basename(url.searchParams.get('name') || 'audio.mp3');
      const ext = (path.extname(orig).toLowerCase() || '.mp3').slice(0, 6);
      const body = await readBody(req, 300 * 1024 * 1024);
      if (!body.length) return json(res, 400, { ok: false, error: 'empty audio file' });
      const stem = orig.slice(0, orig.length - path.extname(orig).length).toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 40) || 'audio';
      const file = `${stem}-${crypto.createHash('sha1').update(body).digest('hex').slice(0, 8)}${ext}`;
      if (!AUDIO_FILE.test(file)) return json(res, 400, { ok: false, error: `unsupported audio type "${ext}" (use mp3, wav, m4a, aac, ogg, opus, flac or webm)` });
      fs.mkdirSync(audioDir, { recursive: true });
      fs.writeFileSync(path.join(audioDir, file), body);
      json(res, 200, { ok: true, file, name: orig, path: path.join(audioDir, file), url: `/audio/${file}`, bytes: body.length });
    },

    // A GLB for a model object: saved under the scene folder's models/ by a name made from the file's name and
    // content (the same file twice reuses it). The caller then adds it with { op: 'add', type: 'model', file }.
    'POST /api/model': async (req, res, url) => {
      const orig = path.basename(url.searchParams.get('name') || 'model.glb');
      const body = await readBody(req, 500 * 1024 * 1024);
      if (!body.length) return json(res, 400, { ok: false, error: 'empty model file' });
      let info;
      try { info = glbInfo(body); } catch (e) { return json(res, 400, { ok: false, error: `could not read the GLB: ${e.message}` }); }
      if (!info) return json(res, 400, { ok: false, error: 'not a GLB file (binary glTF 2.0, .glb)' });
      const stem = orig.slice(0, orig.length - path.extname(orig).length).toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 40) || 'model';
      const file = `${stem}-${crypto.createHash('sha1').update(body).digest('hex').slice(0, 8)}.glb`;
      if (!MODEL_FILE.test(file)) return json(res, 400, { ok: false, error: `bad model name "${file}"` });
      fs.mkdirSync(modelsDir, { recursive: true });
      fs.writeFileSync(path.join(modelsDir, file), body);
      json(res, 200, { ok: true, file, name: orig, path: path.join(modelsDir, file), url: `/models/${file}`, bytes: body.length, ...info });
    },

    // Blocking Board: a picture for a texture or a card, saved under textures/ by a name made from the file's name and
    // content (the same picture twice reuses it). The caller then uses it: { texture: { file } } or { type: 'card', file }.
    'POST /api/texture': async (req, res, url) => {
      const orig = path.basename(url.searchParams.get('name') || 'picture.png');
      const body = await readBody(req, 64 * 1024 * 1024);
      if (!body.length) return json(res, 400, { ok: false, error: 'empty picture' });
      const kind = body[0] === 0x89 && body[1] === 0x50 ? '.png' : body[0] === 0xff && body[1] === 0xd8 ? '.jpg' : body.toString('latin1', 8, 12) === 'WEBP' ? '.webp' : null;
      if (!kind) return json(res, 400, { ok: false, error: 'not a png, jpg or webp picture' });
      const stem = orig.slice(0, orig.length - path.extname(orig).length).toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 40) || 'picture';
      const file = `${stem}-${crypto.createHash('sha1').update(body).digest('hex').slice(0, 8)}${kind}`;
      if (!IMAGE_FILE.test(file)) return json(res, 400, { ok: false, error: `bad picture name "${file}"` });
      fs.mkdirSync(texturesDir, { recursive: true });
      fs.writeFileSync(path.join(texturesDir, file), body);
      json(res, 200, { ok: true, file, name: orig, url: `/textures/${file}`, path: path.join(texturesDir, file), bytes: body.length });
    },

    // ----- prompts: canvas -> agent -----
    // Images for chat prompts: saved under .canvas/uploads so the agent can open them by path.
    'POST /api/chat/image': async (req, res) => {
      const { data, name } = await readJson(req);
      const m = /^data:image\/(png|jpeg|webp|gif);base64,(.+)$/.exec(String(data || ''));
      if (!m) return json(res, 400, { ok: false, error: 'expected a png, jpeg, webp or gif data URL' });
      fs.mkdirSync(uploadsDir, { recursive: true });
      const ext = m[1] === 'jpeg' ? 'jpg' : m[1];
      const stem = String(name || 'image').replace(/\.[a-z0-9]+$/i, '').replace(/[^a-z0-9_-]+/gi, '-').slice(0, 40) || 'image';
      const file = `${Date.now().toString(36)}-${stem}.${ext}`;
      fs.writeFileSync(path.join(uploadsDir, file), Buffer.from(m[2], 'base64'));
      json(res, 200, { ok: true, file, url: `/uploads/${file}`, path: path.join(uploadsDir, file) });
    },
    // A file the agent attaches to a chat reply (canvas say --attach): a video or an image, kept with the
    // chat's uploads so it plays in the thread and in past chats.
    'POST /api/chat/file': async (req, res, url) => {
      const orig = path.basename(url.searchParams.get('name') || 'file');
      const ext = path.extname(orig).toLowerCase();
      if (!CHAT_FILE[ext]) return json(res, 400, { ok: false, error: `cannot attach "${ext || orig}" (videos: mp4, webm, mov; images: png, jpg, webp, gif)` });
      const body = await readBody(req, 1024 * 1024 * 1024);
      if (!body.length) return json(res, 400, { ok: false, error: 'empty file' });
      fs.mkdirSync(uploadsDir, { recursive: true });
      const stem = orig.slice(0, orig.length - ext.length).replace(/[^a-z0-9_-]+/gi, '-').replace(/^-+|-+$/g, '').slice(0, 40) || 'file';
      const file = `${Date.now().toString(36)}-${crypto.createHash('sha1').update(body).digest('hex').slice(0, 6)}-${stem}${ext}`;
      fs.writeFileSync(path.join(uploadsDir, file), body);
      json(res, 200, { ok: true, ...chatFile(file, orig) });
    },
    'POST /api/prompt': async (req, res) => {
      const { text, context, images, models } = await readJson(req);
      const imgs = (Array.isArray(images) ? images : [])
        .map((f) => path.basename(String(f?.file || f)))
        .filter((f) => fs.existsSync(path.join(uploadsDir, f)))
        .slice(0, 8)
        .map((f) => ({ file: f, url: `/uploads/${f}`, path: path.join(uploadsDir, f) }));
      // GLBs dropped in the chat: already uploaded to models/ (POST /api/model) but not in the scene yet.
      const mods = (Array.isArray(models) ? models : [])
        .map((f) => ({ file: path.basename(String(f?.file || f)), name: f?.name ? path.basename(String(f.name)) : undefined }))
        .filter((f) => MODEL_FILE.test(f.file) && fs.existsSync(path.join(modelsDir, f.file)))
        .slice(0, 8)
        .map((f) => ({ file: f.file, name: f.name || f.file, url: `/models/${f.file}`, path: path.join(modelsDir, f.file) }));
      if ((!text || !String(text).trim()) && !imgs.length && !mods.length) return json(res, 400, { ok: false, error: 'empty prompt' });
      const p = { id: `p${Date.now().toString(36)}`, text: String(text || '').trim(), context: context || {}, status: 'pending', at: Date.now() };
      if (imgs.length) p.images = imgs;
      if (mods.length) p.models = mods;
      prompts.push(p); if (prompts.length > 500) prompts = prompts.slice(-500);
      savePrompts();
      broadcast('prompt', p);
      deliverToWaiters();
      json(res, 200, { ok: true, prompt: p, agent: agentListening() });
    },
    'GET /api/prompt/next': (req, res, url) => {
      lastAgentPoll = Date.now(); touchAgent();
      if (url.searchParams.get('keep') !== '1') closeTaken();
      const p = takePrompt();
      if (p) { pushStatus(); return json(res, 200, { ok: true, prompt: p }); }
      const wait = Math.min(Number(url.searchParams.get('wait') || 0), 3600) * 1000;
      if (!wait) return json(res, 200, { ok: true, prompt: null });
      const w = {
        resolve: (prompt) => { lastAgentPoll = Date.now(); json(res, 200, { ok: true, prompt }); },
        timer: setTimeout(() => { const i = waiters.indexOf(w); if (i >= 0) waiters.splice(i, 1); lastAgentPoll = Date.now(); json(res, 200, { ok: true, prompt: null }); pushStatus(); }, wait),
      };
      waiters.push(w);
      req.on('close', () => { const i = waiters.indexOf(w); if (i >= 0) { waiters.splice(i, 1); clearTimeout(w.timer); pushStatus(); } });
      pushStatus();
    },
    'POST /api/listen': async (req, res) => {
      const { on, session = null, cwd = null } = await readJson(req);
      listen = !!on;
      listenSession = listen ? session : null;
      listenCwd = listen ? cwd : null;
      if (listen) touchAgent();
      fs.writeFileSync(listenPath, JSON.stringify({ on: listen, session: listenSession, cwd: listenCwd }));
      pushStatus();
      json(res, 200, { ok: true, listen });
    },
    'GET /api/prompts': (req, res) => json(res, 200, { prompts: prompts.slice(-50) }),
    'POST /api/prompt/status': async (req, res) => {
      const { id, status } = await readJson(req);
      const p = prompts.find((x) => x.id === id);
      if (!p) return json(res, 404, { ok: false, error: `no prompt ${id}` });
      p.status = status; savePrompts(); broadcast('prompt', p); deliverToWaiters();
      json(res, 200, { ok: true });
    },

    // ----- secrets: typed into a key block in the chat, kept on this machine, never sent to the agent -----
    'POST /api/secret': async (req, res) => {
      const { name, value } = await readJson(req);
      try { saveSecret(name, value); } catch (e) { return json(res, 400, { ok: false, error: e.message }); }
      json(res, 200, { ok: true, name });
    },
    'GET /api/secrets': (req, res) => json(res, 200, { ok: true, secrets: listSecrets() }),

    // ----- progress: one card in the chat for a long job, updated in place -----
    'POST /api/progress': async (req, res) => {
      const b = await readJson(req);
      touchAgent();
      const text = (v, max) => String(v ?? '').trim().slice(0, max);
      const prev = b.id ? progress.get(String(b.id)) ?? readTail(logPath, Infinity).filter((m) => m.kind === 'progress' && m.progress?.id === b.id).at(-1)?.progress : null;
      if (b.id && !prev) return json(res, 404, { ok: false, error: `no progress card ${b.id} in this chat` });
      if (!prev && !text(b.title, 80)) return json(res, 400, { ok: false, error: 'a progress card needs a title' });
      const now = Date.now();
      const p = prev ? { ...prev } : { id: `g${now.toString(36)}${crypto.randomBytes(2).toString('hex')}`, state: 'running', startedAt: now };
      if (text(b.title, 80)) p.title = text(b.title, 80);
      if (Array.isArray(b.steps)) { p.steps = b.steps.map((s) => text(s, 40)).filter(Boolean).slice(0, 8); if (!p.steps.length) delete p.steps; p.step = p.steps ? Math.min(p.step || 1, p.steps.length) : undefined; }
      if (b.step != null) {
        const n = Number(b.step);
        if (!p.steps || !Number.isInteger(n) || n < 1 || n > p.steps.length) return json(res, 400, { ok: false, error: p.steps ? `step must be 1 to ${p.steps.length}` : 'this card has no steps' });
        if (n !== p.step) delete p.pct; // a percentage belongs to the stage it was given for
        p.step = n;
      }
      if (b.pct != null) { const n = Number(b.pct); if (!(n >= 0 && n <= 100)) return json(res, 400, { ok: false, error: 'pct must be 0 to 100' }); p.pct = Math.round(n); }
      if (b.eta != null) { const n = Number(b.eta); if (n > 0) p.eta = Math.round(n); else delete p.eta; }
      if (b.note != null) { if (text(b.note, 200)) p.note = text(b.note, 200); else delete p.note; }
      if (b.state != null) {
        if (!['running', 'done', 'failed'].includes(b.state)) return json(res, 400, { ok: false, error: 'state must be running, done or failed' });
        p.state = b.state;
        if (p.state === 'running') delete p.endedAt; else p.endedAt = now;
      }
      p.updatedAt = now;
      for (const k of Object.keys(p)) if (p[k] === undefined) delete p[k];
      if (!prev) endAutoCards(); // the agent's own card replaces the one made from "still working"
      postProgress(p);
      json(res, 200, { ok: true, id: p.id, progress: p });
    },

    // ----- questions: the agent asks in the chat, the answers come back as one prompt -----
    'POST /api/ask': async (req, res) => {
      const body = await readJson(req);
      touchAgent();
      let ask;
      try { ask = normalizeAsk(body); } catch (e) { return json(res, 400, { ok: false, error: e.message }); }
      const taken = prompts.filter((x) => x.status === 'taken');
      const reply = body.reply || (taken.length === 1 ? taken[0].id : undefined);
      ask.id = `q${Date.now().toString(36)}${crypto.randomBytes(2).toString('hex')}`;
      const entry = { from: 'agent', kind: 'ask', text: ask.title || ask.questions[0].q, ask, reply, at: Date.now() };
      appendLog(entry);
      broadcast('say', entry);
      endAutoCards();
      // Asking hands the turn to the user: the prompt it answers is no longer being worked on.
      const p = reply && prompts.find((x) => x.id === reply);
      if (p) { p.status = 'done'; p.doneAt = Date.now(); savePrompts(); broadcast('prompt', p); }
      json(res, 200, { ok: true, id: ask.id, questions: ask.questions.length });
    },
    'POST /api/ask/answer': async (req, res) => {
      const { id, answers = {}, cancelled = false, context } = await readJson(req);
      const entry = readTail(logPath, Infinity).find((m) => m.kind === 'ask' && m.ask?.id === id);
      if (!entry) return json(res, 404, { ok: false, error: `no question ${id} in this chat` });
      if (prompts.some((x) => x.ask === id)) return json(res, 409, { ok: false, error: 'already answered' });
      const { text, answers: clean, images } = answerAsk(entry.ask, answers, cancelled, (f) => {
        const file = path.basename(String(f?.file || f));
        return fs.existsSync(path.join(uploadsDir, file)) ? { file, url: `/uploads/${file}`, path: path.join(uploadsDir, file) } : null;
      });
      const p = { id: `p${Date.now().toString(36)}`, text, ask: id, answers: clean, context: context || {}, status: 'pending', at: Date.now() };
      if (cancelled) p.cancelled = true;
      if (images.length) p.images = images;
      prompts.push(p); if (prompts.length > 500) prompts = prompts.slice(-500);
      savePrompts();
      broadcast('prompt', p);
      deliverToWaiters();
      json(res, 200, { ok: true, prompt: p, agent: agentListening() });
    },

    // New chat: archive the conversation and start an empty thread. Prompts still queued or being worked on stay.
    'POST /api/chat/new': async (req, res) => {
      const active = (p) => p.status === 'pending' || p.status === 'taken';
      const chat = archiveChat(prompts.filter((p) => !active(p)), readTail(logPath, Infinity));
      try { fs.rmSync(logPath, { force: true }); } catch {}
      prompts = prompts.filter(active);
      savePrompts();
      broadcast('history', currentChat());
      json(res, 200, { ok: true, kept: prompts.length, archived: chat?.id || null });
    },
    // Past chats, newest first, and one past chat in full.
    'GET /api/chats': (req, res) => json(res, 200, { ok: true, chats: listChats() }),
    'GET /api/chats/get': (req, res, url) => {
      const chat = readChat(url.searchParams.get('id'));
      if (!chat) return json(res, 404, { ok: false, error: `no chat ${url.searchParams.get('id')} (see canvas chats)` });
      json(res, 200, { ok: true, chat });
    },
    // ----- messages: agent -> canvas -----
    'POST /api/say': async (req, res) => {
      const { text, reply: replyTo, kind = 'info', done = true, files } = await readJson(req);
      touchAgent();
      // A reply without --reply answers the prompt the agent is working on, if there is exactly one.
      const taken = prompts.filter((x) => x.status === 'taken');
      const reply = replyTo || (taken.length === 1 ? taken[0].id : undefined);
      const entry = { from: 'agent', text: String(text || ''), reply, kind, at: Date.now() };
      const attached = (Array.isArray(files) ? files : []).map((f) => ({ file: path.basename(String(f?.file || f)), name: f?.name && path.basename(String(f.name)) }))
        .filter((f) => CHAT_FILE[path.extname(f.file).toLowerCase()] && fs.existsSync(path.join(uploadsDir, f.file))).slice(0, 8).map((f) => chatFile(f.file, f.name));
      if (attached.length) entry.files = attached;
      if (!entry.text && !attached.length) return json(res, 400, { ok: false, error: 'empty message' });
      if (kind === 'working' && !attached.length && stillWorking(entry.text)) return json(res, 200, { ok: true });
      if (kind !== 'working') endAutoCards();
      appendLog(entry);
      broadcast('say', entry);
      const p = reply && prompts.find((x) => x.id === reply);
      if (p && done) { p.status = 'done'; p.doneAt = Date.now(); savePrompts(); broadcast('prompt', p); }
      json(res, 200, { ok: true });
    },
  };

  const server = http.createServer(async (req, res) => {
    const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
    const route = routes[`${req.method} ${url.pathname}`];
    try {
      if (route) return await route(req, res, url);
      if (req.method !== 'GET') return json(res, 404, { ok: false, error: `no route ${req.method} ${url.pathname}` });
      if (url.pathname === '/vendor/mediabunny.mjs') return serveFile(res, path.join(ROOT, 'node_modules', 'mediabunny', 'dist', 'bundles', 'mediabunny.min.mjs'));
      for (const [prefix, dir] of STATIC) {
        if (!url.pathname.startsWith(prefix)) continue;
        let rel = decodeURIComponent(url.pathname.slice(prefix.length));
        if (!rel || rel.endsWith('/')) rel += 'index.html';
        const file = within(dir, rel);
        if (file) return serveFile(res, file, req);
      }
      res.writeHead(404); res.end('not found');
    } catch (e) {
      if (!res.headersSent) json(res, e.status || 500, { ok: false, error: e.message });
    }
  });

  return new Promise((resolve, reject) => {
    server.on('error', reject);
    server.listen(port, host, () => {
      log(`ready  http://${host}:${port}`);
      log(`scene  ${scenePath}`);
      log(`export ${exportsDir}`);
      resolve({ server, port, scenePath, exportsDir, close: () => { fs.unwatchFile(scenePath); server.close(); for (const c of clients.values()) c.res.end(); } });
    });
  });
}

function readTail(file, n) {
  try { return fs.readFileSync(file, 'utf8').split('\n').filter(Boolean).slice(-n).map((l) => JSON.parse(l)); } catch { return []; }
}

let ffmpegOk;
function transcodeH264(file) {
  if (ffmpegOk === undefined) ffmpegOk = spawnSync('ffmpeg', ['-version']).status === 0;
  if (!ffmpegOk) return null;
  const out = file.replace(/\.(webm|mp4)$/i, '') + '.h264.mp4';
  const r = spawnSync('ffmpeg', ['-y', '-loglevel', 'error', '-i', file, '-c:v', 'libx264', '-pix_fmt', 'yuv420p', '-crf', '18', '-c:a', 'aac', '-b:a', '192k', '-movflags', '+faststart', out]);
  if (r.status !== 0) return null;
  fs.renameSync(out, file.replace(/\.(webm|mp4)$/i, '.mp4'));
  if (!file.endsWith('.mp4')) fs.unlinkSync(file);
  return file.replace(/\.(webm|mp4)$/i, '.mp4');
}

/** The browser could encode H.264 but not AAC (its audio is Opus): re-encode just the audio to AAC, which every player reads. */
function transcodeAac(file) {
  if (ffmpegOk === undefined) ffmpegOk = spawnSync('ffmpeg', ['-version']).status === 0;
  if (!ffmpegOk || !file.endsWith('.mp4')) return null;
  const out = file.replace(/\.mp4$/i, '.aac.mp4');
  const r = spawnSync('ffmpeg', ['-y', '-loglevel', 'error', '-i', file, '-c:v', 'copy', '-c:a', 'aac', '-b:a', '192k', '-movflags', '+faststart', out]);
  if (r.status !== 0) return null;
  fs.renameSync(out, file);
  return file;
}

// Allow `node server/index.mjs` directly.
if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  startServer({ port: Number(process.env.PORT) || 5317 }).catch((e) => { console.error(e.message); process.exit(1); });
}
