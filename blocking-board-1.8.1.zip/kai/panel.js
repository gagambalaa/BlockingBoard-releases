// Blocking Board's panel inside KAI (the canvas's Presets panel). KAI loads it as a plugin (../kai-plugin.json): this file
// lives in Blocking Board's repo, so it's changed by Blocking Board's developers, never in KAI's code.
// mount(el, kz) -> {setProject(key)}; kz is KAI's plugin kit: api, esc, toast, thumb(ref), plugin.open(card),
// plugin.index(id). Each scene shows its main keyframe; click = open Blocking Board there; drag onto the canvas or a Cards
// Table frame = a Blocking Board card (a plugin card: double-click opens Blocking Board at the scene, right-click picks its frame).
const ID = 'blocking-board';

export function mount(el, kz) {
  let key = null, data = null, busy = false;
  el.innerHTML = `<div class="fx">
    <button class="btn fx-go" data-a="open">🎬 Open Blocking Board</button>
    <div class="fx-h" style="margin-top:10px"><span>Scenes</span><button class="btn sm ghost" data-a="reload" title="Reload">↻</button></div>
    <div class="dim" style="font-size:12px;margin:-4px 0 8px">Click a scene to open it · drag it onto the canvas or a table</div>
    <div data-list></div></div>`;
  const list = el.querySelector('[data-list]');
  const groups = () => data?.index?.groups || [];
  // what a scene is on a canvas: its main keyframe, carrying the plugin card's data
  const card = (s) => s.main?.ref && { ...s.main.ref, plugin: { id: ID, key: s.key, label: s.label, open: s.open, frame: s.frames?.[0]?.key || null } };

  async function load() {
    if (!key) { list.innerHTML = `<div class="fx-empty">Open a project first.</div>`; return; }
    if (busy) return; busy = true;
    try { data = await kz.plugin.index(ID); paint(); }
    catch (err) { list.innerHTML = `<div class="fx-empty">${kz.esc(err.message)}</div>`; }
    finally { busy = false; }
  }
  function paint() {
    if (!data.installed) { list.innerHTML = `<div class="fx-empty">Blocking Board needs Node.js on this PC.</div>`; return; }
    if (!groups().length) { list.innerHTML = `<div class="fx-empty">No scenes yet. Open Blocking Board to start one.</div>`; return; }
    list.innerHTML = groups().map((g, i) => `<div class="fx-card" style="margin-bottom:8px">
      <div class="fx-h"><span>${kz.esc(g.name)}</span><small>${g.items.length} scene${g.items.length === 1 ? '' : 's'}</small></div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:6px">${g.items.map((s, j) => `
        <div class="fx-tile" data-g="${i}" data-s="${j}" draggable="${s.main?.ref ? 'true' : 'false'}" style="cursor:pointer"
          title="${kz.esc(s.title || s.open.sc)} · ${kz.esc(s.info || '')}\nClick: open in Blocking Board · drag: onto the canvas">
          ${s.main?.ref ? `<img src="${kz.thumb(s.main.ref)}" style="aspect-ratio:16/9" draggable="false">` : `<div class="ph" style="aspect-ratio:16/9">No frame yet</div>`}
          <span>${kz.esc(s.open.sc)}</span></div>`).join('')}</div></div>`).join('');
  }
  const scene = (t) => groups()[+t.dataset.g]?.items[+t.dataset.s];

  el.addEventListener('click', (e) => {
    const a = e.target.closest('[data-a]')?.dataset.a;
    if (a === 'open') return key ? kz.plugin.open({ id: ID }) : kz.toast('Open a project first');
    if (a === 'reload') return load();
    const t = e.target.closest('[data-g]'), s = t && scene(t);
    if (s) kz.plugin.open({ id: ID, label: s.label, open: s.open });
  });
  el.addEventListener('dragstart', (e) => {
    const t = e.target.closest('[data-g]'), r = t && card(scene(t));
    if (!r) return e.preventDefault();
    e.dataTransfer.setData('application/x-kz-outputs', JSON.stringify([r])); e.dataTransfer.effectAllowed = 'copy';
  });
  // Blocking Board renders frames as you work: look again when KAI's window comes back
  addEventListener('focus', () => { if (key && el.offsetParent) load(); });

  return { setProject(k) { if (k !== key) { key = k; data = null; } load(); } };
}
