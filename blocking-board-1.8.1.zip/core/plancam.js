// Blocking Board: the shot camera on the floor plan (as on the first Blocking Board's Floor plan card) - drawn as a
// diamond with its view cone, dragged to move it across the floor (its height and the way it points stay), its dot
// dragged to turn it (where it stands, keeping its height, tilt and how far it aims). Pure maths on a camera pose
// { position: [x, y, z], target: [x, y, z], fov (vertical, degrees), roll }: the app keys the result like any other
// camera change.

const r3 = (v) => Math.round(v * 1000) / 1000;
const DEG = Math.PI / 180;

/** The pose moved by dx, dz metres across the floor: height and direction kept. */
export function planMove(pose, dx, dz) {
  const d = [dx, 0, dz];
  return { ...pose, position: pose.position.map((v, i) => r3(v + d[i])), target: pose.target.map((v, i) => r3(v + d[i])) };
}

/**
 * The pose turned (round its own spot) to face the floor point x, z: its height, its tilt (the target's height) and how
 * far it aims along the floor are kept. A point on the camera itself leaves it as it is.
 */
export function planTurn(pose, x, z) {
  const [px, , pz] = pose.position, [tx, ty, tz] = pose.target;
  const reach = Math.hypot(tx - px, tz - pz) || 1, ax = x - px, az = z - pz, len = Math.hypot(ax, az);
  if (len < 1e-6) return { ...pose };
  return { ...pose, target: [r3(px + (ax / len) * reach), ty, r3(pz + (az / len) * reach)] };
}

/** Which way the camera faces on the plan (degrees, 0 = +z, 90 = +x, like an object's turn) and its cone's half-width. */
export function planCone(pose, aspect) {
  const [px, , pz] = pose.position, [tx, , tz] = pose.target;
  const yaw = Math.atan2(tx - px, tz - pz) / DEG;
  const half = Math.atan(Math.tan((pose.fov * DEG) / 2) * aspect) / DEG;
  return { yaw: r3(yaw), half: r3(half) };
}
