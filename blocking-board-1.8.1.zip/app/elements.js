// Blocking Board: the element library. Project = the Higgsfield elements of the KAI project this film belongs to (read
// through KAI); Scene = the elements this scene uses (doc.elements). Click an element to stand it in the set as a
// card where the camera looks; drag it onto the set: on a wall, floor or box it becomes that surface's texture, on
// the floor a card. Whatever is placed joins the scene's library.

import * as THREE from 'three';
import { h, icon, toast } from './ui/kit.js';
import { store } from './store.js';

const r2 = (v) => Math.round(v * 100) / 100;
export const ELEMENT_TYPE = 'application/x-stage-element';

export function mountElements(hud, { viewport }) {
  let tab = localStorage.getItem('bb.elTab') || 'project', project = { link: {}, elements: [] }, projects = null, query = '', loading = false;

  // ---------- button + panel ----------
  const btn = h('button.cc-btn.st-add.el-btn', { type: 'button', title: 'Elements: the project\'s and this scene\'s', onClick: () => toggle() }, icon('image'), 'Elements');
  hud.append(btn);
  const tabs = h('div.el-tabs');
  const head = h('div.el-head');
  const search = h('input.cc-input.lib-ask-input.el-search', { placeholder: 'Search', spellcheck: false });
  search.addEventListener('input', () => { query = search.value.trim().toLowerCase(); render(); });
  search.addEventListener('keydown', (e) => e.stopPropagation());
  const grid = h('div.el-grid');
  const panel = h('div.cc-panel.el-panel', { hidden: true }, tabs, head, search, grid);
  document.body.append(panel);
  function toggle(on = panel.hidden) {
    panel.hidden = !on; btn.classList.toggle('is-open', on);
    if (on) { if (tab === 'project') load(); render(); }
  }
  addEventListener('pointerdown', (e) => { if (!panel.hidden && !panel.contains(e.target) && !btn.contains(e.target)) toggle(false); }, true);

  async function load(force) {
    if (loading || (!force && project.loaded && Date.now() - project.loaded < 60000)) return;
    loading = true; render();
    try {
      const r = await fetch('/api/kai/elements').then((x) => x.json());
      if (!r.ok) throw new Error(r.error);
      project = { ...r, elements: (r.elements || []).filter((e) => e.status === 'completed' || !e.status), loaded: Date.now() };
    } catch (e) { project = { link: project.link, elements: [], error: e.message, loaded: Date.now() }; }
    loading = false; render();
  }
  async function linkProject() {
    if (!projects) { try { projects = (await fetch('/api/kai/projects').then((x) => x.json())).projects || []; } catch { projects = []; } }
    render();
  }

  function tile(e, inScene) {
    const t = h('div.el-tile', { draggable: true, title: `${e.name}${e.canvas ? ` · ${e.canvas}` : ''}\nClick: stand it in the set · drag: onto a surface or the floor` },
      e.image ? h('img', { src: e.image, alt: '', loading: 'lazy', draggable: false }) : h('span.el-noimg'),
      h('span.el-name', {}, e.name),
      inScene ? h('button.el-x', { type: 'button', title: 'Take it out of this scene\'s library', onClick: (ev) => { ev.stopPropagation(); store.op({ op: 'elements', remove: [e.id] }, 'element out'); } }, icon('close')) : null);
    t.addEventListener('click', () => place(e));
    t.addEventListener('dragstart', (ev) => { ev.dataTransfer.setData(ELEMENT_TYPE, JSON.stringify(e)); ev.dataTransfer.effectAllowed = 'copy'; });
    return t;
  }
  function render() {
    tabs.replaceChildren(...[['project', 'Project'], ['scene', `Scene (${(store.doc?.elements || []).length})`]].map(([k, label]) =>
      h('button.el-tab', { type: 'button', class: tab === k ? 'is-on' : '', onClick: () => { tab = k; localStorage.setItem('bb.elTab', k); if (k === 'project') load(); render(); } }, label)));
    if (panel.hidden) return;
    const match = (e) => !query || `${e.name} ${e.canvas || ''}`.toLowerCase().includes(query);
    if (tab === 'project') {
      const link = project.link || {};
      head.replaceChildren(link.key
        ? h('div.el-link', {}, h('span.el-proj', { title: 'The KAI project this film belongs to' }, link.name || 'KAI project'),
          h('button.cc-btn.cc-btn--ghost', { type: 'button', title: 'Read the elements again', onClick: () => load(true) }, icon('undo')),
          h('button.cc-btn.cc-btn--ghost', { type: 'button', title: 'Change the KAI project', onClick: () => { project.link = {}; linkProject(); } }, 'Change'))
        : projects
          ? h('select.cc-select.el-select', { onChange: async (ev) => { const p = projects.find((x) => x.key === ev.target.value); if (!p) return;
              await store.post('/api/kai/link', { key: p.key, name: p.name }); project = { link: { key: p.key, name: p.name }, elements: [] }; load(true); } },
            h('option', { value: '' }, 'Pick the KAI project…'), ...projects.map((p) => h('option', { value: p.key }, p.name)))
          : h('button.cc-btn.cc-btn--ghost', { type: 'button', onClick: () => linkProject() }, 'Link a KAI project'));
      const list = (project.elements || []).filter(match);
      grid.replaceChildren(...(loading ? [h('div.el-empty', {}, 'Reading the elements from KAI…')]
        : project.error ? [h('div.el-empty', {}, project.error)]
        : !link.key ? [h('div.el-empty', {}, 'Link the film to its KAI project: its Higgsfield elements show here.')]
        : list.length ? list.map((e) => tile(e, false)) : [h('div.el-empty', {}, query ? 'Nothing matches' : 'No elements in this project yet')]));
    } else {
      head.replaceChildren(h('div.el-note', {}, 'The elements this scene uses'));
      const list = (store.doc?.elements || []).filter(match);
      grid.replaceChildren(...(list.length ? list.map((e) => tile(e, true)) : [h('div.el-empty', {}, 'None yet: place one from Project, or drop a picture on the set')]));
    }
  }
  store.on('doc', () => { if (tab === 'scene' || !panel.hidden) render(); });

  // ---------- placing ----------
  async function picture(e) {
    if (e.image?.startsWith('/textures/')) return decodeURIComponent(e.image.slice(10));
    const r = await store.post('/api/kai/picture', { url: e.image, name: e.name });
    if (!r.ok) throw new Error(r.error);
    return r.file;
  }
  const aspectOf = (url) => new Promise((ok) => { const i = new Image(); i.onload = () => ok(i.naturalWidth / i.naturalHeight || 1); i.onerror = () => ok(1); i.src = url; });
  const keep = (e) => store.op({ op: 'elements', add: [{ id: e.id, name: e.name, image: e.image, ...(e.canvas ? { canvas: e.canvas } : {}) }] }, 'element in').catch(() => {});
  async function place(e, at) {
    try {
      const file = await picture(e);
      const aspect = r2(await aspectOf(`/textures/${file}`));
      const p = at || viewport.focusPoint();
      const [r] = await store.op({ op: 'add', type: 'card', name: e.name.replace(/[^a-z0-9]+/gi, '-').slice(0, 30) || 'element', file, aspect,
        h: aspect > 1.4 ? 1.2 : 1.8, position: [r2(p.x), 0, r2(p.z)], note: `element ${e.id}`,
        ...(store.doc?.meta?.location?.edit === 'location' ? { loc: true } : {}) }, `place ${e.name}`);
      await keep(e);
      store.set({ selection: r.id });
    } catch (err) { toast(err.message, { kind: 'error' }); }
  }
  async function asTexture(e, id) {
    try {
      const file = await picture(e);
      const o = store.object(id);
      await store.op({ op: 'update', id, texture: { file, scale: o?.texture?.scale ?? 2 } }, `texture ${id}`);
      await keep(e);
    } catch (err) { toast(err.message, { kind: 'error' }); }
  }
  // an element dragged onto the set (main.js hands the drop here)
  function drop(ev, e) {
    const r = viewport.canvas.getBoundingClientRect(), ray = new THREE.Raycaster();
    ray.setFromCamera(new THREE.Vector2(((ev.clientX - r.left) / r.width) * 2 - 1, -((ev.clientY - r.top) / r.height) * 2 + 1), viewport.activeCam);
    const hit = ray.intersectObjects(viewport._pickables(), false)[0];
    let obj = hit?.object; while (obj && !obj.userData.id) obj = obj.parent;
    const o = obj && store.object(obj.userData.id);
    // walls, boxes, roofs take it as their texture; a floor (plane) only with Alt held, else it stands on it as a card
    if (o && !['card', 'light', 'person', 'model'].includes(o.type) && (o.type !== 'plane' || ev.altKey)) return asTexture(e, o.id);
    const floor = ray.ray.intersectPlane(new THREE.Plane(new THREE.Vector3(0, 1, 0), 0), new THREE.Vector3());
    return place(e, floor || undefined);
  }

  render();
  return { toggle, drop, place, load };
}
