// Camera timeline: transport, keyframe track, selected-key controls and the easing / speed curve editor.

import { h, button, segmented, number, select, icon, toast, affix, panel, toggle as onOff } from './ui/kit.js';
import { EASES, bezier, bezierSpeed, resolveEase, easeName, splitEase, removeEasePoint, sampleCamera, fovToLens, lensToFov, isCut, shudder, SHUDDER_DEFAULT } from '/core/curves.js';
import { store } from './store.js';
import { mountAudioTrack } from './audiotrack.js';
import { mountShots } from './shots.js';
import { mountMoves } from './moves.js';
import { shotList } from '/core/doc.js';

const MOD = /Mac|iPhone|iPad/.test(navigator.platform) ? '⌘' : 'Ctrl+';

const PAD = 14;
const SIZES = [[1280, 720], [1920, 1080], [3840, 2160], [1080, 1920], [1080, 1080], [1440, 1080]];
const RETIME_KEY = 'cc-retime';
const PATH_OPTIONS = [{ value: 'smooth', label: 'Smooth' }, { value: 'straight', label: 'Straight' }, { value: 'orbit', label: 'Orbit' }, { value: 'turn', label: 'Turn' }, { value: 'dollyZoom', label: 'Dolly zoom' }];
/** Short label for a key's path on the track: "orbit 90°", "dolly zoom". */
export function pathLabel(p) {
  if (!p) return '';
  const deg = p.angle ? ` ${p.angle > 0 ? '' : '−'}${Math.abs(p.angle)}°` : '';
  if (p.type === 'orbit') return `orbit${deg}${p.around ? ` · ${p.around}` : ''}`;
  if (p.type === 'turn') return `turn${deg}`;
  return p.type === 'dollyZoom' ? 'dolly zoom' : p.type;
}

/** Run fn only when key changed since the last call for this element. Refreshes run every frame while
 *  playing; rebuilding a button's children under the pointer swallows clicks, and rebuilding a select closes it. */
function changed(el, key, fn) { key = JSON.stringify(key); if (el._ccKey !== key) { el._ccKey = key; fn(); } }

/** A tiny inline SVG of an ease curve, for buttons. */
export function easeSvg(ease, size = 14) {
  const b = resolveEase(ease);
  let d = '';
  if (b === 'hold') d = 'M2 13H13V3';
  else for (let i = 0; i <= 16; i++) { const u = i / 16; d += `${i ? 'L' : 'M'}${(2 + u * 12).toFixed(2)} ${(13 - bezier(b, u) * 10).toFixed(2)}`; }
  return `<svg viewBox="0 0 16 16" width="${size}" height="${size}" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="${d}"/></svg>`;
}
const fmtFps = (v) => String(+(+v).toFixed(3));

export function mountTimeline(root, { viewport, exporter }) {
  // ---------- bar: play | camera | output ----------
  const playBtn = button({ icon: 'play', title: 'Play / pause (Space)', onClick: () => store.set({ playing: !store.state.playing }) });
  const timeNow = h('span');
  const timeDur = h('span.tl-faint');
  const timeEl = h('span.cc-mono.tl-time', {}, timeNow, timeDur);
  const viewSeg = segmented({
    options: [{ value: 'plan', label: 'Plan', icon: 'columns', title: 'Main view: top-down blueprint of the set (P)' }, { value: 'free', label: '3D', icon: 'orbit', title: 'Main view: orbit the set in 3D (C)' }, { value: 'shot', label: 'Cam', icon: 'camera', title: 'Main view: look through the shot camera (C)' }],
    value: store.state.view, onChange: (v) => store.set({ view: v }),
  });
  const keyBtn = button({ icon: 'keyAdd', label: 'Key', title: 'Key the current view at the playhead (K)', onClick: () => keyFromView() });
  keyBtn.classList.add('tl-keybtn');
  // Key's caret: preset camera moves (pan, orbit, dolly zoom ...) from the playhead; the popover is mounted below
  const keyCaret = button({ icon: 'chevronDown', title: 'Preset camera moves from the playhead: pan, tilt, orbit, push in, crane, dolly zoom...', onClick: () => moves.toggle() });
  keyCaret.classList.add('tl-keycaret');
  // Key the selected object where it is now, at the playhead. Once it has a key, dragging it with the
  // gizmo at another time adds the next key, so a move is: key, scrub, drag.
  const objKeyLabel = h('span');
  const objKeyBtn = h('button.cc-btn.tl-objkey', { type: 'button', onClick: () => keyObject() }, h('span.tl-odot'), objKeyLabel);

  // selected key: time, ease (opens the curve editor), lens, set to view, delete
  const keyTime = h('span.cc-mono.tl-keytime');
  const easeGlyph = h('span.tl-glyph');
  const easeName_ = h('span.tl-ease-name');
  const easeBtn = h('button.cc-field.tl-ease', { type: 'button', onClick: () => curve.toggle(undefined, 'segment') }, easeGlyph, easeName_, icon('chevronDown'));
  // Lens: sets the selected key's focal length and the free camera's, so the free view looks through the
  // same lens you are keying. With no key selected it sets just the free camera.
  const lensNum = number({ step: 1, min: 8, max: 300, precision: 0, title: 'Lens (mm, full-frame equivalent): the selected key and the free view', width: 34, onInput: (v) => viewport.setFreeFov(lensToFov(v)), onChange: (v) => {
    const fov = +lensToFov(v).toFixed(3);
    viewport.setFreeFov(fov);
    if (store.state.key) updateKey({ fov });
  } });
  const lensField = affix(lensNum, 'mm');
  // Roll (Dutch tilt): like Lens, the selected key's and the free view's. In shot view it hand-frames the
  // shot camera, so K keys it. Hold the right mouse button and press Z / X to roll by hand.
  // the view takes the roll unless a key drives the shot camera, which then follows the key
  const rollLive = () => store.state.view === 'free' || store.state.camDirty || !store.state.key;
  const rollNum = number({ step: 1, min: -180, max: 180, precision: 0, title: 'Roll (degrees): the selected key and the free view', width: 30,
    onInput: (v) => { if (rollLive()) viewport.setRoll(v); },
    onChange: (v) => {
      const live = rollLive();
      if (live) viewport.setRoll(v);
      if (store.state.key && (store.state.view === 'free' || !live)) updateKey({ roll: v });
    } });
  const rollField = affix(rollNum, '°');
  const toViewBtn = button({ icon: 'aim', title: 'Set this key to the current view', kind: 'ghost', onClick: () => { const p = viewport.getPose(); updateKey({ position: p.position, target: p.target, fov: p.fov, roll: p.roll }); } });
  const delKeyBtn = button({ icon: 'trash', title: 'Delete key', kind: 'ghost', onClick: () => deleteKey() });
  // path: how the camera travels to the next key (a move's arc, a turn on the spot, a dolly zoom ...)
  const pathSel = select({ options: PATH_OPTIONS, value: 'smooth', title: 'How the camera travels to the next key', onChange: (v) => updateKey({ path: v }) });
  pathSel.classList.add('tl-path');
  // a key that starts a preset move: reopen that move's settings
  const editMoveBtn = button({ icon: 'orbit', label: 'Edit move', kind: 'ghost', title: 'Change the settings of the move that starts at this key', onClick: () => moves.toggle(true) });
  const keyGroup = h('div.tl-key', {}, h('span.tl-diamond'), keyTime, easeBtn, pathSel, editMoveBtn, toViewBtn, delKeyBtn);

  // output: shot settings chip + export
  const shotDur = h('span'), shotFps = h('span');
  const shotBtn = h('button.cc-btn.tl-shot', { type: 'button', title: 'Shot length, frame rate and size', onClick: () => shot.toggle() },
    icon('frame'), h('span.tl-shot-name', {}, 'Shot'), h('span.cc-mono', {}, shotDur, h('span.cc-affix__unit', {}, ' s')), h('span.tl-faint.tl-shot-fps', {}, '·'), h('span.cc-mono.tl-shot-fps', {}, shotFps, h('span.cc-affix__unit', {}, ' fps')), icon('chevronDown'));
  // Export opens a menu (in the primary color, just below the button): the whole timeline (every shot in
  // order, one mp4), just the active shot, and "Render with Comfy", the optional step after the export done by
  // the agent (the blockout-render skill): it only opens the chat with a request started, so the user can add
  // reference images and send it.
  const exportBtn = button({ icon: 'film', label: 'Export', kind: 'primary', title: 'Export the blockout video, or render it with Comfy', onClick: () => toggleExportMenu() });
  exportBtn.classList.add('tl-exportbtn');
  exportBtn.append(icon('chevronDown'));
  exportBtn.setAttribute('aria-haspopup', 'menu');
  exportBtn.setAttribute('aria-expanded', 'false');
  const runExport = (opts) => exporter.exportVideo(opts).catch((err) => toast(err.message, { kind: 'error' }));
  const menuItem = (cls, ic, label, title, onClick) => {
    const b = button({ icon: ic, label, kind: 'ghost', title, onClick });
    b.classList.add(cls);
    b.setAttribute('role', 'menuitem');
    return b;
  };
  const exportFullBtn = menuItem('tl-export-full', 'film', 'Export full video', 'Every shot in order, cut together into one video (mp4)', () => runExport({ sequence: true }));
  const exportShotBtn = menuItem('tl-export-shot', 'frame', 'Export shot', 'Just the current shot (mp4)', () => runExport({ sequence: false }));
  const renderBtn = menuItem('tl-render', 'sparkle', 'Render with Comfy', 'Render the whole timeline into a finished video with your agent and ComfyUI. Opens the chat with the request started: send it and your agent asks for what it needs',
    () => store.emit('compose', {
      text: 'Render this timeline with ComfyUI (blockout-render skill). ',
      hint: 'Send to start. Nothing costs credits until you confirm.',
    }));
  // (Blocking Board: no built-in agent chat, so no "Render with Comfy" here - renders go through KAI)
  const exportPop = h('div.tl-export-pop', { hidden: true, role: 'menu' }, exportFullBtn, exportShotBtn);
  void renderBtn;
  document.body.append(exportPop);
  function toggleExportMenu(on = exportPop.hidden) {
    if (on) {
      const r = exportBtn.getBoundingClientRect();
      exportPop.hidden = false;
      exportPop.style.right = `${Math.max(12, innerWidth - r.right)}px`;
      exportPop.style.top = `${Math.min(r.bottom + 4, innerHeight - exportPop.offsetHeight - 8)}px`;
    } else exportPop.hidden = true;
    exportBtn.classList.toggle('is-open', on);
    exportBtn.setAttribute('aria-expanded', on);
  }
  exportPop.addEventListener('click', (e) => { if (e.target.closest('button')) toggleExportMenu(false); });
  addEventListener('pointerdown', (e) => { if (!exportPop.hidden && !exportPop.contains(e.target) && !exportBtn.contains(e.target)) toggleExportMenu(false); }, true);
  addEventListener('keydown', (e) => { if (e.key === 'Escape' && !exportPop.hidden) { e.stopPropagation(); toggleExportMenu(false); exportBtn.focus(); } }, true);
  addEventListener('resize', () => { if (!exportPop.hidden) toggleExportMenu(false); });

  // audio: a waveform lane under the track, an Audio button in the bar (functions below are hoisted)
  // (one track for the whole sequence, on the shots' shared action-time axis)
  const audioTrack = mountAudioTrack(root, {
    xA: (a) => xAction(a), aAt: (x) => ((x - left()) / span()) * axisT(), axisEnd: () => axisT(),
    scrubTo: (x, e) => scrubTo(x, e), playheadA: () => axis0() + store.state.time,
    marks: () => [0, axis0() + store.state.time, ...shotList(store.doc).flatMap((s) => [s.timeline.start || 0, (s.timeline.start || 0) + s.timeline.duration])],
    spans: () => shotList(store.doc).map((s) => ({ a0: s.timeline.start || 0, a1: (s.timeline.start || 0) + s.timeline.duration, active: s.active })),
    cutXs: () => cutsOf(liveKeys()).map((c) => c.x), keyXs: () => [...keyXs(liveKeys()).values()],
  });

  const shots = mountShots();
  const bar = h('div.tl-bar', {}, playBtn, timeEl, h('span.cc-divider'), viewSeg, keyBtn, keyCaret, lensField, rollField,
    h('span.cc-spacer'), audioTrack.btn, shotBtn, exportBtn);

  // The bar keeps play, the camera and output. The selected key's settings open in a card above that key
  // (placeKeyCard), Loop and Play all are switches in the shot popover, and the object's Key button sits in
  // the object chip at the top left (main.js).
  const keyCard = h('div.cc-panel.tl-keycard', { hidden: true }, keyGroup);
  document.body.append(keyCard);
  /** Put the key card above the selected key, and lift the popovers over it. */
  function placeKeyCard() {
    const k = store.state.key && store.keyById(store.state.key);
    const show = !!k && !!L;
    keyCard.hidden = !show;
    document.body.classList.toggle('has-keycard', show);
    if (!show) return;
    const x = track.getBoundingClientRect().left + (keyXs(liveKeys()).get(k.id) ?? xOf(k.t));
    const w = keyCard.offsetWidth;
    const left = Math.max(12, Math.min(innerWidth - w - 12, x - w / 2));
    keyCard.style.left = `${left}px`;
    const kh = `${keyCard.offsetHeight}px`;
    if (document.body.style.getPropertyValue('--keycard-h') !== kh) document.body.style.setProperty('--keycard-h', kh);
  }

  // When the controls don't fit, step the bar down (.is-fit1..3 in app.css) only as far as it needs: one level
  // up while it overflows, and one level back whenever it would fit again. At the last level (4) the less used
  // controls move into a ⋯ menu, as they are, so they keep working and show their labels there. Runs on resize
  // and when the bar's contents change (a key selected, an object keyed, audio loaded), at most once a frame.
  const moreBtn = button({ icon: 'more', kind: 'ghost', title: 'More: audio, shot settings', onClick: () => toggleMore() });
  moreBtn.classList.add('tl-more');
  exportBtn.before(moreBtn);
  const morePop = h('div.cc-panel.tl-more-pop', { hidden: true });
  document.body.append(morePop); // outside #timeline, like the other popovers
  // A control opts into the menu with data-overflow. Each keeps a marker where it sits in the bar, so it goes
  // back to the same place.
  for (const el of [audioTrack.btn, shotBtn]) el.dataset.overflow = '';
  const overflow = [...bar.querySelectorAll(':scope > [data-overflow]')].map((el) => {
    const mark = document.createComment('');
    el.after(mark);
    return { el, mark };
  });
  const FIT_MAX = 4;
  let fitLevel = 0, fitQueued = false;
  function setFit(n) {
    fitLevel = n;
    for (let i = 1; i <= 3; i++) bar.classList.toggle(`is-fit${i}`, i <= n);
    const menu = n >= 4;
    if (menu !== bar.classList.contains('is-fit4')) {
      bar.classList.toggle('is-fit4', menu);
      for (const { el, mark } of overflow) (menu ? morePop : mark.parentNode).insertBefore(el, menu ? null : mark);
    }
  }
  const over = () => bar.scrollWidth > bar.clientWidth + 0.5;
  function fit() {
    fitQueued = false;
    if (!bar.clientWidth) return;
    while (fitLevel > 0) { setFit(fitLevel - 1); if (over()) { setFit(fitLevel + 1); break; } }
    while (fitLevel < FIT_MAX && over()) setFit(fitLevel + 1);
    if (fitLevel < 4 && !morePop.hidden) toggleMore(false);
    fitWatch.takeRecords(); // our own moves are not changes to react to
  }
  const queueFit = () => { if (!fitQueued) { fitQueued = true; requestAnimationFrame(fit); } };
  new ResizeObserver(queueFit).observe(bar);
  const fitWatch = new MutationObserver(queueFit);
  for (const el of [bar, morePop]) fitWatch.observe(el, { subtree: true, childList: true, attributes: true, attributeFilter: ['style', 'hidden', 'disabled'] });
  document.fonts?.ready.then(queueFit);
  function toggleMore(on = morePop.hidden) {
    if (on) { const r = moreBtn.getBoundingClientRect(); morePop.style.right = `${Math.max(12, innerWidth - r.right)}px`; }
    morePop.hidden = !on;
    moreBtn.classList.toggle('is-open', on);
  }
  // a click on an item does its thing (opening its own popover from where the item is), then the menu closes
  morePop.addEventListener('click', (e) => { if (e.target.closest('button')) toggleMore(false); });
  addEventListener('pointerdown', (e) => { if (!morePop.hidden && !morePop.contains(e.target) && !moreBtn.contains(e.target)) toggleMore(false); }, true);
  addEventListener('keydown', (e) => { if (e.key === 'Escape' && !morePop.hidden) { e.stopPropagation(); toggleMore(false); } }, true);

  // ---------- track ----------
  const track = h('canvas.tl-track');
  root.append(bar, track, audioTrack.lane);
  const ctx = track.getContext('2d');
  // Shots picked by clicking their bars: Shift or Cmd/Ctrl-click adds or removes one, Shift or Cmd/Ctrl-drag
  // on an empty part of the lanes draws a box around several. Dragging any picked bar sideways moves them all,
  // and Delete removes them.
  let picked = new Set();
  let drag = null; // { kind: 'key'|'okey'|'scrub', id, t, moved }; a key drag moves every selected key
  // Selected camera keys. store.state.key is the primary one (its ease, path and time show in the key card);
  // shift-click adds the range from it, ctrl/cmd-click toggles one, and dragging any of them moves them all.
  let selKeys = new Set();
  const syncSel = () => {
    const k = store.state.key;
    if (!k) selKeys.clear();
    else if (!selKeys.has(k)) selKeys = new Set([k]);
    for (const id of selKeys) if (!store.keyById(id)) selKeys.delete(id);
  };

  const dur = () => store.doc.timeline.duration;
  const fps = () => store.doc.timeline.fps;
  const width = () => track.clientWidth;
  // The track stacks the shots, even when there is only one: a row per shot on the shared action-time axis,
  // each shot a bar from where it picks up the action, then a "+ New shot" row. The active shot's row is the
  // full key editor; times stay shot time, so xOf/tOf just add the shot's start. The axis runs a little past
  // the last shot so there is room to see (and draw) where a new one would go.
  // Layout (px): the ruler band, a header column (GUT) with the shots' names, hairline-separated lanes, the
  // new-shot row and a lane for the selected object's keys at the bottom.
  // The track grows with the shots up to MAX_ROWS of them (and the new-shot row); past that the lanes scroll
  // under the ruler (wheel or trackpad), so the ruler, the object lane and the audio lane below stay put.
  const RULER = 18, ACTIVE_H = 40, ROW_H = 24, NEW_H = 22, GAP = 0, LANE = 16, GUT = 96, INSET = 3, BASE_H = 56, MAX_ROWS = 6;
  let L = null; // { T, end, start, rows: [{ s, top, h }], active, add: { top, h }, list: { top, bottom, max }, height }
  let hoverNew = false; // the pointer is over the new-shot row: preview the shot a click would add
  let scroll = 0, scrolledTo = null; // how far the lanes are scrolled (px); the active shot it last brought into view
  function relayout() {
    const doc = store.doc;
    if (!doc) { L = null; return; }
    const shots = shotList(doc);
    let end = 0;
    for (const x of shots) end = Math.max(end, (x.timeline.start || 0) + x.timeline.duration);
    for (const o of doc.objects) if (o.anim?.length) end = Math.max(end, o.anim[o.anim.length - 1].t);
    const T = Math.max(1, end + Math.max(1, end * 0.25)); // headroom for the next shot
    const hs = shots.map((x) => (x.active ? ACTIVE_H : ROW_H) + GAP);
    const content = hs.reduce((a, b) => a + b, 0) + NEW_H;
    const view = Math.min(content, ACTIVE_H + (MAX_ROWS - 1) * ROW_H + MAX_ROWS * GAP + NEW_H), max = content - view;
    const ai = shots.findIndex((x) => x.active);
    if (doc.shot !== scrolledTo && ai >= 0) { // another shot became active: bring it into view
      scrolledTo = doc.shot;
      const off = hs.slice(0, ai).reduce((a, b) => a + b, 0);
      const need = hs[ai] + (ai === shots.length - 1 ? NEW_H : 0); // the last shot brings the new-shot row with it
      if (off < scroll) scroll = off; else if (off + need > scroll + view) scroll = off + need - view;
    }
    scroll = Math.max(0, Math.min(max, scroll));
    let y = RULER - scroll;
    const rows = shots.map((x, i) => { const r = { s: x, top: y, h: hs[i] - GAP }; y += hs[i]; return r; });
    const add = { top: y, h: NEW_H };
    L = { T, end, start: doc.timeline.start || 0, rows, active: rows.find((r) => r.s.active), add, list: { top: RULER, bottom: RULER + view, max }, height: RULER + view + LANE };
  }
  const inList = (y) => !L || (y >= L.list.top && y < L.list.bottom); // the scrolling lanes, not the ruler or the object lane
  const inNewRow = (y) => !!L && inList(y) && y >= L.add.top && y < L.add.top + L.add.h;
  /** New shot: snap action time `a` to 0, the playhead, or a shot's start or end within a few px; else a frame. */
  function snapAction(a, e) {
    const marks = [0, L.start + store.state.time];
    for (const r of L.rows) { const st = r.s.timeline.start || 0; marks.push(st, st + r.s.timeline.duration); }
    if (!e?.shiftKey) for (const m of marks) if (Math.abs(xAction(m) - xAction(a)) < 7) return +m.toFixed(3);
    const F = fps(); return +(Math.round(a * F) / F).toFixed(3);
  }
  /** The shot a click on the new-shot row adds: the next one, from where the active shot ends, as long. */
  const nextSpan = () => { const tl = store.doc.timeline; return { a0: (tl.start || 0) + tl.duration, a1: (tl.start || 0) + 2 * tl.duration }; };
  const axisT = () => (L ? L.T : dur());
  const axis0 = () => (L ? L.start : 0);
  const left = () => (L ? GUT : 0) + PAD, span = () => width() - left() - PAD; // the time axis, in px
  const xOf = (t) => left() + ((axis0() + t) / axisT()) * span();
  const tOf = (x, free) => { const t = ((x - left()) / span()) * axisT() - axis0(); return free ? t : Math.max(0, Math.min(dur(), t)); };
  const xAction = (a) => left() + (a / axisT()) * span();
  const aOf = (x) => Math.max(0, ((x - left()) / span()) * axisT()); // action time at x
  const inGutter = (x) => !!L && x < GUT;
  const covers = (s, a) => a >= (s.timeline.start || 0) - 1e-6 && a <= (s.timeline.start || 0) + s.timeline.duration + 1e-6;
  // a shot's bar handle: anywhere on another shot's bar, or the name strip along the top of the active one
  // (its top strip keeps the rest free for keys), or its name in the header column
  const onHandle = (r, x, y) => !!r && y < r.top + r.h && (inGutter(x) || (covers(r.s, aOf(x)) && (!r.s.active || y < r.top + 12)));
  const rowAt = (y) => (L && inList(y) ? L.rows.find((r) => y >= r.top && y < r.top + r.h + GAP) : null);
  /** A shot bar's left or right end, to drag for retiming. Another shot's bar: either side of its end. The
   *  active one: just outside its ends (the first and last keys sit right on them), or anywhere along the
   *  end above or below the keys. */
  function edgeAt(x, y) {
    const r = rowAt(y);
    if (!r || y >= r.top + r.h || inGutter(x)) return null;
    const st = r.s.timeline.start || 0, xs = [xAction(st), xAction(st + r.s.timeline.duration)];
    const mid = r.top + r.h / 2 + 2, offKeys = Math.abs(y - mid) > 7;
    for (const [i, side] of [[1, 'right'], [0, 'left']]) {
      const d = (x - xs[i]) * (side === 'right' ? 1 : -1); // + is outside the bar
      if (r.s.active ? (d >= 1 && d <= 8) || (offKeys && Math.abs(d) <= 4) : d >= -4 && d <= 6) return { r, side };
    }
    return null;
  }
  /** Where shot `tl`'s camera key at shot time `t` sits in action time while its edge is dragged (else null). */
  const edgeKeyA = (s, t) => {
    if (drag?.kind !== 'edge' || !drag.moved || drag.s.id !== s.id) return null;
    return drag.trim ? drag.st0 + t : drag.st + t * (drag.dur / drag.dur0);
  };
  const inActive = (y) => !L || (inList(y) && y >= L.active.top && y < L.active.top + L.active.h);
  const snap = (t, e) => (e?.shiftKey ? t : Math.round(t * fps()) / fps());
  const keys = () => [...store.doc.timeline.keys].sort((a, b) => a.t - b.t);
  // While keys are dragged, they (and the other halves of their cuts) are drawn shifted by the drag.
  const liveKeys = () => keys().map((k) => {
    if (drag?.kind === 'key' && drag.moving.has(k.id)) return { ...k, t: drag.moving.get(k.id) + drag.dt };
    const a = L && edgeKeyA(L.active.s, k.t); // the active shot's edge is dragged: keys stretch (or stay) with it
    return a != null ? { ...k, t: a - L.start } : k;
  }).sort((a, b) => a.t - b.t);
  /** Cuts: every hold key (except the last) ends a shot, and the camera cuts to the next key. A hold key and
   *  the next key within a frame or so of each other are one "split" key either side of the cut line. */
  const cutsOf = (ks) => {
    const out = [];
    for (let i = 0; i < ks.length - 1; i++) {
      if (!isCut(ks[i])) continue;
      const a = ks[i], b = ks[i + 1], tight = b.t - a.t <= 1.5 / fps() + 1e-6;
      out.push({ a, b, tight, x: tight ? (xOf(a.t) + xOf(b.t)) / 2 : xOf(b.t) - 3 });
    }
    return out;
  };
  const keyXs = (ks) => {
    const xs = new Map(ks.map((k) => [k.id, xOf(k.t)]));
    for (const c of cutsOf(ks)) { if (c.tight) xs.set(c.a.id, c.x - 3); xs.set(c.b.id, c.x + 4); }
    return xs;
  };
  const keyAt = (x, y) => {
    if (y != null && !inActive(y)) return null;
    const ks = liveKeys(), xs = keyXs(ks);
    let best = null, bd = 8;
    for (const k of ks) { const d = Math.abs(xs.get(k.id) - x); if (d < bd) { bd = d; best = k; } }
    return best && keys().find((k) => k.id === best.id);
  };
  /** The other key of a tight cut, so dragging either half moves the cut as one. */
  const cutPartner = (k) => {
    const c = cutsOf(keys()).find((c) => c.tight && (c.a.id === k.id || c.b.id === k.id));
    return c ? (c.a.id === k.id ? c.b : c.a) : null;
  };

  const selObj = () => (store.state.selection && store.object(store.state.selection)) || null;
  // object keys are stored in action time; this shot shows the action from its timeline.start
  const okeys = () => { const t0 = store.doc.timeline.start || 0; return (selObj()?.anim || []).map((k) => ({ ...k, t: +(k.t - t0).toFixed(3) })); };
  const laneY = () => track.clientHeight - (L ? LANE / 2 : 7); // object keys sit in a lane under the camera keys
  const okeyAt = (x, y) => (y > laneY() - 8 ? okeys().find((k) => Math.abs(xOf(drag?.kind === 'okey' && drag.t0 === k.t ? drag.t : k.t) - x) < 7) : null);

  function seek(t) { store.set({ time: Math.max(0, Math.min(dur(), t)), camDirty: false }); }

  track.addEventListener('pointerdown', (e) => {
    const x = e.offsetX;
    if (inNewRow(e.offsetY) && e.button === 0) { // new shot: click adds the next one, drag draws its span
      track.setPointerCapture(e.pointerId);
      const a = inGutter(x) ? null : snapAction(aOf(x), e);
      drag = { kind: 'new', x0: x, a0: a, a1: a, moved: false };
      store.set({ playing: false });
      return draw();
    }
    const ed = e.button === 0 && edgeAt(x, e.offsetY);
    if (ed) { // a shot's end: drag to retime the shot (Alt/Option: trim it, keys stay where they are)
      track.setPointerCapture(e.pointerId);
      const tl = ed.r.s.timeline, ts = tl.keys.map((k) => k.t);
      drag = { kind: 'edge', side: ed.side, s: ed.r.s, x0: x, st0: tl.start || 0, dur0: tl.duration, st: tl.start || 0, dur: tl.duration,
        first: ts.length ? Math.min(...ts) : 0, last: ts.length ? Math.max(...ts) : 0, trim: e.altKey, moved: false };
      store.set({ playing: false });
      return;
    }
    const ok = okeyAt(x, e.offsetY);
    const k = ok ? null : keyAt(x, e.offsetY);
    track.setPointerCapture(e.pointerId);
    const row = !ok && !k && rowAt(e.offsetY);
    // a shot's bar: click to pick it (and put the playhead there), drag sideways to change where it picks
    // up the action, drag up or down to reorder the sequence
    if (row && e.button === 0 && onHandle(row, x, e.offsetY)) {
      drag = { kind: 'shot', gut: inGutter(x), s: row.s, x0: x, y0: e.offsetY, from: L.rows.indexOf(row), to: L.rows.indexOf(row), start0: row.s.timeline.start || 0, moved: false, axis: null,
        add: e.shiftKey || e.metaKey || e.ctrlKey };
      store.set({ playing: false });
      return;
    }
    // Shift or Cmd/Ctrl-drag on an empty part of the lanes: box-select shots
    if (!ok && !k && L && e.button === 0 && (e.shiftKey || e.metaKey || e.ctrlKey) && inList(e.offsetY) && e.offsetY < L.add.top && !inGutter(x)) {
      drag = { kind: 'box', x0: x, y0: e.offsetY, x1: x, y1: e.offsetY, base: new Set(picked), moved: false };
      store.set({ playing: false });
      return;
    }
    if (!ok && !k) picked = new Set();
    if (!ok && !k && inGutter(x)) return; // the header column is not time
    if (ok && e.button === 0) {
      drag = { kind: 'okey', id: selObj().id, t: ok.t, t0: ok.t, moved: false };
      store.set({ playing: false });
      seek(ok.t);
    } else if (k && e.button === 0) {
      syncSel();
      const anchor = store.state.key && store.keyById(store.state.key);
      let collapse = false; // a plain click on a key of a multi-selection keeps it for dragging, then selects just that key
      if (e.shiftKey && anchor) {
        const [lo, hi] = [Math.min(anchor.t, k.t), Math.max(anchor.t, k.t)];
        for (const x of keys()) if (x.t >= lo - 1e-6 && x.t <= hi + 1e-6) selKeys.add(x.id);
      } else if (e.ctrlKey || e.metaKey) {
        if (selKeys.has(k.id) && selKeys.size > 1) {
          selKeys.delete(k.id);
          store.set({ key: k.id === store.state.key ? [...selKeys][0] : store.state.key });
          return draw();
        }
        selKeys.add(k.id);
      } else if (selKeys.has(k.id) && selKeys.size > 1) collapse = true;
      else selKeys = new Set([k.id]);
      // move the selection and the other half of any cut it touches
      const moving = new Map();
      for (const id of selKeys) { const x = store.keyById(id); if (!x) continue; moving.set(id, x.t); const p = cutPartner(x); if (p) moving.set(p.id, p.t); }
      const ts = [...moving.values()];
      drag = { kind: 'key', id: k.id, t: k.t, t0: k.t, dt: 0, moved: false, moving, collapse, shift0: e.shiftKey, lo: -Math.min(...ts), hi: dur() - Math.max(...ts) };
      store.set({ key: k.id });
      picked = new Set();
      if (!e.shiftKey && !e.ctrlKey && !e.metaKey) seek(k.t);
    } else if (e.button === 0) {
      drag = { kind: 'scrub', moved: false };
      store.set({ playing: false });
      scrubTo(x, e);
    }
  });
  // more shots than fit: the wheel (or a two-finger swipe) scrolls the lanes; Ctrl/Cmd+wheel is left alone
  track.addEventListener('wheel', (e) => {
    if (!L || L.list.max <= 0 || e.ctrlKey || e.metaKey || Math.abs(e.deltaX) > Math.abs(e.deltaY)) return;
    e.preventDefault();
    const s0 = scroll;
    scroll = Math.max(0, Math.min(L.list.max, scroll + e.deltaY * (e.deltaMode === 1 ? 16 : e.deltaMode === 2 ? L.list.bottom - L.list.top : 1)));
    if (scroll !== s0) draw();
  }, { passive: false });
  track.addEventListener('pointermove', (e) => {
    if (!drag) {
      const r = rowAt(e.offsetY), hn = inNewRow(e.offsetY);
      track.style.cursor = hn ? 'pointer' : edgeAt(e.offsetX, e.offsetY) ? 'ew-resize' : okeyAt(e.offsetX, e.offsetY) || keyAt(e.offsetX, e.offsetY) || onHandle(r, e.offsetX, e.offsetY) ? 'grab' : 'default';
      if (hn !== hoverNew) { hoverNew = hn; draw(); }
      return;
    }
    if (drag.kind === 'new') {
      if (drag.a0 == null) return; // pressed on the row's name: a click
      if (!drag.moved && Math.abs(e.offsetX - drag.x0) < 4) return;
      drag.moved = true;
      drag.a1 = Math.min(L.T, snapAction(aOf(e.offsetX), e));
      return draw();
    }
    if (drag.kind === 'edge') {
      if (!drag.moved && Math.abs(e.offsetX - drag.x0) < 3) return;
      drag.moved = true; drag.trim = e.altKey;
      const F = drag.s.timeline.fps, min = 1 / F, end0 = drag.st0 + drag.dur0;
      const a = Math.min(L.T, snapAction(aOf(e.offsetX), e)); // the axis grows after the drop: drag again for more
      if (drag.side === 'right') { // the start stays; trimming can't cut off camera keys
        const end = Math.max(drag.st0 + (drag.trim ? Math.max(min, drag.last) : min), Math.min(drag.st0 + 600, a));
        drag.st = drag.st0; drag.dur = +(end - drag.st0).toFixed(3);
      } else { // the end stays; trimming can't push the first key before the shot
        const st = Math.max(0, end0 - 600, Math.min(a, end0 - min, drag.trim ? drag.st0 + drag.first : Infinity));
        drag.st = +st.toFixed(3); drag.dur = +(end0 - st).toFixed(3);
      }
      return draw();
    }
    if (drag.kind === 'shot') {
      const dx = e.offsetX - drag.x0, dy = e.offsetY - drag.y0;
      if (!drag.moved && (drag.gut ? Math.abs(dy) : Math.max(Math.abs(dx), Math.abs(dy))) < 4) return;
      if (!drag.moved) drag.axis = drag.gut || Math.abs(dy) > Math.abs(dx) ? 'y' : 'x';
      drag.moved = true;
      track.style.cursor = drag.axis === 'y' ? 'ns-resize' : 'grabbing';
      if (drag.axis === 'y') { // reorder: the lane under the pointer (near the ends of a scrolled list, scroll it)
        if (L.list.max > 0) scroll += e.offsetY < L.list.top + 10 ? -ROW_H / 2 : e.offsetY > L.list.bottom - 10 ? ROW_H / 2 : 0;
        relayout();
        const ys = L.rows.map((r) => r.top + r.h / 2);
        let to = 0; for (let i = 0; i < ys.length; i++) if (Math.abs(e.offsetY - ys[i]) < Math.abs(e.offsetY - ys[to])) to = i;
        drag.to = to;
        return draw();
      }
      if (!drag.starts) { // the picked shots move together when the grabbed one is among them (or added now)
        if (drag.add) picked.add(drag.s.id);
        const ids = picked.has(drag.s.id) ? [...picked] : [drag.s.id];
        drag.starts = new Map(ids.map((id) => [id, L.rows.find((r) => r.s.id === id)?.s.timeline.start || 0]).filter(([id]) => L.rows.some((r) => r.s.id === id)));
        drag.min0 = Math.min(...drag.starts.values());
      }
      const F = drag.s.timeline.fps;
      // none of them can start before 0; the grabbed one snaps to a frame (Shift: free)
      let st = Math.max(drag.start0 - drag.min0, drag.start0 + ((e.offsetX - drag.x0) / span()) * axisT());
      if (!e.shiftKey) st = Math.max(drag.start0 - drag.min0, Math.round(st * F) / F);
      drag.start = +st.toFixed(3); drag.dA = drag.start - drag.start0;
      return draw();
    }
    if (drag.kind === 'box') {
      drag.x1 = e.offsetX; drag.y1 = e.offsetY;
      if (!drag.moved && Math.hypot(drag.x1 - drag.x0, drag.y1 - drag.y0) < 4) return;
      drag.moved = true;
      const [xa, xb] = [Math.min(drag.x0, drag.x1), Math.max(drag.x0, drag.x1)], [ya, yb] = [Math.min(drag.y0, drag.y1), Math.max(drag.y0, drag.y1)];
      picked = new Set(drag.base);
      for (const r of L.rows) {
        const st = r.s.timeline.start || 0, bx0 = xAction(st), bx1 = Math.max(bx0 + 3, xAction(st + r.s.timeline.duration));
        if (yb >= r.top && ya < r.top + r.h && xb >= bx0 && xa <= bx1) picked.add(r.s.id);
      }
      return draw();
    }
    drag.moved = true;
    const t = snap(tOf(e.offsetX), e);
    if (drag.kind === 'key') {
      drag.dt = Math.max(drag.lo, Math.min(drag.hi, snap(tOf(e.offsetX, true), drag.shift0 ? null : e) - drag.t0));
      drag.t = drag.t0 + drag.dt; seek(drag.t);
    } else if (drag.kind === 'okey') { drag.t = t; seek(t); }
    else scrubTo(e.offsetX, e);
    draw();
  });
  track.addEventListener('pointerup', (e) => {
    const d = drag; drag = null;
    if (!d) return;
    if (d.kind === 'new') {
      const lo = Math.min(d.a0 ?? 0, d.a1 ?? 0), hi = Math.max(d.a0 ?? 0, d.a1 ?? 0);
      if (d.moved && hi - lo >= 1 / fps() - 1e-6) shots.add({ start: lo, duration: +(hi - lo).toFixed(3) });
      else shots.add();
      return draw();
    }
    if (d.kind === 'edge') {
      const ds = d.st - d.st0;
      if (!d.moved || (Math.abs(ds) < 1e-4 && Math.abs(d.dur - d.dur0) < 1e-4)) return draw();
      const op = { op: 'timeline', duration: d.dur, shot: d.s.id };
      if (d.side === 'left') op.start = d.st;
      if (!d.trim) op.retime = true;
      // trimming the start: the keys keep their moment in the action, so they shift in shot time
      const shift = d.trim && d.side === 'left' && Math.abs(ds) > 1e-4
        ? d.s.timeline.keys.map((k) => ({ op: 'key.update', id: k.id, t: +(k.t - ds).toFixed(3), shot: d.s.id })) : [];
      if (ds < 0) shift.reverse(); // moving later: the last key first, so none passes another
      store.op([op, ...shift], d.trim ? 'trim shot' : 'retime shot').catch(() => {});
      return draw();
    }
    if (d.kind === 'shot') {
      if (d.moved && d.axis === 'y') { if (d.to !== d.from) store.op({ op: 'shot.move', id: d.s.id, to: d.to + 1 }, 'reorder shots').catch(() => {}); draw(); return; }
      if (d.moved) {
        if (d.starts && Math.abs(d.dA) > 1e-4) {
          const ops = [...d.starts].map(([id, st]) => ({ op: 'timeline', start: +Math.max(0, st + d.dA).toFixed(3), shot: id }));
          store.op(ops, ops.length > 1 ? `move ${ops.length} shots` : 'shot action start').catch(() => {});
        }
        draw(); return;
      }
      selKeys.clear(); store.set({ key: null });
      if (d.add) { // Shift or Cmd/Ctrl-click: add the shot to the picked ones, or take it out
        if (picked.has(d.s.id)) picked.delete(d.s.id); else picked.add(d.s.id);
        return draw();
      }
      // a click picks the shot (Delete removes it) and puts the playhead where it was clicked
      picked = new Set([d.s.id]);
      playAt(d.s, d.gut ? L.start + store.state.time : aOf(e.offsetX), e); // from its name: stay at this moment
      return draw();
    }
    if (d.kind === 'key' && d.moved && Math.abs(d.dt) > 1e-4) {
      const ops = [...d.moving].map(([id, t0]) => ({ op: 'key.update', id, t: +(t0 + d.dt).toFixed(3) }));
      const n = selKeys.size;
      store.op(ops, n > 1 ? `move ${n} keys` : ops.length > 1 ? 'move cut' : 'retime key').catch(() => {});
    } else if (d.kind === 'key' && d.collapse) { selKeys = new Set([d.id]); }
    if (d.kind === 'okey' && d.moved && Math.abs(d.t - d.t0) > 1e-4) {
      const k = okeys().find((x) => Math.abs(x.t - d.t0) < 1e-3);
      if (k) store.op([{ op: 'anim.remove', id: d.id, t: d.t0 }, { op: 'anim.key', id: d.id, t: +d.t.toFixed(3), position: k.position, rotation: k.rotation, scale: k.scale, ease: k.ease }], `retime ${d.id} key`).catch(() => {});
    }
    if (d.kind === 'box' && !d.moved) { picked = d.base; return draw(); } // a modifier-click on nothing: keep the pick
    if (d.kind === 'scrub' && !d.moved && !keyAt(e.offsetX, e.offsetY)) { selKeys.clear(); store.set({ key: null }); }
    draw();
  });
  track.addEventListener('pointerleave', () => { if (hoverNew) { hoverNew = false; draw(); } });
  // Esc lets go of the picked shots (the app's own Esc handler clears the key and object selection)
  addEventListener('keydown', (e) => { if (e.key === 'Escape' && picked.size && !e.target.closest?.('input, textarea, [contenteditable]')) { picked = new Set(); draw(); } });
  track.addEventListener('dblclick', (e) => {
    if (!inActive(e.offsetY) || onHandle(rowAt(e.offsetY), e.offsetX, e.offsetY)) return; // keys go on the active shot's row
    if (!keyAt(e.offsetX, e.offsetY)) keyFromView(snap(tOf(e.offsetX), e));
  });
  track.addEventListener('contextmenu', (e) => {
    if (e.ctrlKey && !e.button) { e.preventDefault(); return; } // macOS ctrl-click is a selection toggle, not a right-click
    const r = rowAt(e.offsetY);
    if (onHandle(r, e.offsetX, e.offsetY)) { e.preventDefault(); removeShots(picked.has(r.s.id) ? [...picked] : [r.s.id]); return; }
    const ok = okeyAt(e.offsetX, e.offsetY);
    if (ok) { e.preventDefault(); store.op({ op: 'anim.remove', id: selObj().id, t: ok.t }, 'remove object key').catch(() => {}); return; }
    const k = keyAt(e.offsetX, e.offsetY); if (k) { e.preventDefault(); if (!selKeys.has(k.id)) { selKeys = new Set([k.id]); store.set({ key: k.id }); } deleteKey(); } });

  // ---------- actions ----------
  /** Several shots: put the playhead at action time `a`, in shot `s` (switching to it if it isn't active). */
  let switching = null, pendingAt = null;
  function playAt(s, a, e) {
    const tl = s.timeline, F = tl.fps;
    let t = Math.max(0, Math.min(tl.duration, a - (tl.start || 0)));
    if (!e?.shiftKey) t = Math.round(t * F) / F;
    if (s.id === store.doc.shot) return seek(t);
    if (switching) { pendingAt = [s, a, e]; return; } // scrubbing across a cut: catch up once the switch lands
    switching = shots.use(s.id).then(() => store.set({ time: t })).finally(() => {
      switching = null;
      const p = pendingAt; pendingAt = null;
      if (p) { relayout(); const s2 = L?.rows.find((r) => r.s.id === p[0].id)?.s; if (s2) playAt(s2, p[1], p[2]); }
    });
  }
  /** Scrub to x: one shot, in its time. Several: the action time at x, in the active shot if it covers it,
   *  else the first shot that does, so the ruler and the empty parts of the rows are scrubbable too. */
  function scrubTo(x, e) {
    if (!L) return seek(snap(tOf(x), e));
    const a = aOf(x), cur = L.active.s;
    const s = covers(cur, a) ? cur : L.rows.map((r) => r.s).find((x) => covers(x, a)) || cur;
    playAt(s, a, e);
  }
  function removeShots(ids) {
    ids = ids.filter((id) => store.doc.shots.some((x) => x.id === id));
    if (!ids.length) return;
    if (store.doc.shots.length - ids.length < 1) return toast(store.doc.shots.length < 2 ? 'A scene needs at least one shot' : 'A scene needs at least one shot. Leave one out of the selection');
    const s = store.doc.shots.find((x) => x.id === ids[0]);
    picked = new Set();
    store.op(ids.map((id) => ({ op: 'shot.remove', id })), ids.length > 1 ? `delete ${ids.length} shots` : 'delete shot')
      .then(() => toast(`Deleted ${ids.length > 1 ? `${ids.length} shots` : s?.name || ids[0]}. Undo brings ${ids.length > 1 ? 'them' : 'it'} back`)).catch(() => {});
  }
  async function keyObject(t = store.state.time) {
    const o = selObj();
    if (!o) return;
    await store.op({ op: 'anim.key', id: o.id, t: +t.toFixed(3) }, `key ${o.id}`);
    toast(o.anim?.length ? `Keyed ${o.id} at ${t.toFixed(2)}s` : `Keyed ${o.id} at ${t.toFixed(2)}s. Move the playhead, then drag it to key the next spot`);
  }

  async function keyFromView(t = store.state.time) {
    const p = viewport.getPose();
    const [r] = await store.op({ op: 'key.add', t: +t.toFixed(3), position: p.position, target: p.target, fov: p.fov, roll: p.roll }, 'key camera');
    store.set({ key: r.id, camDirty: false });
    toast(r.replaced ? `Updated key at ${t.toFixed(2)}s` : `Keyed camera at ${t.toFixed(2)}s`);
  }
  function updateKey(patch) {
    const id = store.state.key;
    if (!id) return;
    store.op({ op: 'key.update', id, ...patch }, 'edit key').then(() => store.set({ camDirty: false })).catch(() => {});
  }
  function deleteKey() {
    const id = store.state.key;
    if (!id) { if (picked.size) removeShots([...picked]); return; }
    syncSel();
    const ids = [...selKeys];
    store.op(ids.map((id) => ({ op: 'key.remove', id })), ids.length > 1 ? `delete ${ids.length} keys` : 'delete key')
      .then(() => { selKeys.clear(); store.set({ key: null }); }).catch(() => {});
  }

  // ---------- drawing ----------
  const css = (name) => getComputedStyle(document.documentElement).getPropertyValue(name).trim();
  /** The ruler band: labels against the top, a tick beside each, frame ticks along the hairline under it.
   *  `xf` maps seconds to px; labels that would run into a cut's scissors (`cuts`) are left out. */
  function drawRuler(W, T, xf, F, { dim, line }, cuts = []) {
    const x0 = xf(0), pxPerSec = (xf(T) - x0) / T;
    const step = pxPerSec > 120 ? 0.5 : pxPerSec > 40 ? 1 : pxPerSec > 16 ? 2 : 5;
    ctx.fillStyle = line; ctx.fillRect(L ? GUT : 0, RULER, W, 1);
    ctx.fillStyle = dim;
    if (F && pxPerSec / F > 5) { // frame ticks
      ctx.globalAlpha = 0.45;
      for (let f = 0; f <= T * F + 1e-6; f++) ctx.fillRect(Math.round(xf(f / F)), RULER - 3, 1, 3);
      ctx.globalAlpha = 1;
    }
    for (let t = 0; t <= T + 1e-6; t += step) {
      const x = Math.round(xf(t));
      ctx.globalAlpha = 0.6; ctx.fillRect(x, 3, 1, RULER - 3); ctx.globalAlpha = 1;
      const label = `${+t.toFixed(1)}s`, w = ctx.measureText(label).width;
      const lx = x + 4 + w > W - 3 ? x - 4 - w : x + 4; // the last label sits left of its tick rather than clip
      if (!cuts.some((c) => lx < c.x + 11 && lx + w > c.x - 9)) ctx.fillText(label, lx, 3);
    }
  }

  /** Several shots: header column, action-time ruler and a lane per shot (the active lane's keys are drawn
   *  by draw()). Inactive shots are quiet bars with their keys as ticks; accent marks only the active one. */
  function drawStack(W, H0, { text, dim, line, accent }) {
    const soft = css('--cc-accent-soft'), font = css('--cc-font'), mono = css('--cc-mono');
    const reorder = drag?.kind === 'shot' && drag.axis === 'y';
    // structure: the active lane's header cell, lane hairlines, the header column's edge
    const act = L.active, { top: lt, bottom: lb } = L.list;
    ctx.fillStyle = line;
    ctx.fillRect(GUT, 0, 1, H0);
    ctx.fillRect(0, lb, W, 1); // the lanes end here, scrolled or not
    drawRuler(W, L.T, xAction, 0, { dim, line });
    // faint gridlines carry the ruler's ticks down through the lanes
    const step = (xAction(L.T) - xAction(0)) / L.T > 40 ? 1 : 5;
    ctx.fillStyle = line; ctx.globalAlpha = 0.6;
    for (let a = 0; a <= L.T + 1e-6; a += step) ctx.fillRect(Math.round(xAction(a)), RULER + 1, 1, H0 - RULER - 1);
    ctx.globalAlpha = 1;
    // the lanes, clipped to their (scrolling) window under the ruler
    ctx.save(); ctx.beginPath(); ctx.rect(0, lt + 1, W, lb - lt - 1); ctx.clip();
    ctx.fillStyle = text; ctx.globalAlpha = 0.05; ctx.fillRect(0, act.top + 1, GUT, act.h - 1); ctx.globalAlpha = 1;
    ctx.fillStyle = accent; ctx.fillRect(0, act.top + 1, 2, act.h - 1);
    ctx.fillStyle = line;
    for (const r of L.rows) ctx.fillRect(0, r.top + r.h, W, 1);
    ctx.textBaseline = 'middle';
    for (const [i, r] of L.rows.entries()) {
      const tl = r.s.timeline, my = r.top + r.h / 2 + 1;
      const ed = drag?.kind === 'edge' && drag.moved && drag.s.id === r.s.id;
      const st = drag?.kind === 'shot' && drag.moved && drag.axis === 'x' && drag.starts?.has(r.s.id) ? +(drag.starts.get(r.s.id) + drag.dA).toFixed(3) : ed ? drag.st : tl.start || 0;
      const x0 = xAction(st), bw = Math.max(3, xAction(st + (ed ? drag.dur : tl.duration)) - x0), by = r.top + 1 + INSET, bh = r.h - 1 - INSET * 2;
      const lifted = reorder && drag.s.id === r.s.id;
      // header: position in the sequence, then the name
      ctx.save(); ctx.beginPath(); ctx.rect(0, r.top, GUT - 8, r.h); ctx.clip();
      ctx.globalAlpha = lifted ? 0.4 : 1;
      ctx.font = `10px ${mono}`; ctx.fillStyle = dim; ctx.fillText(String(i + 1), 12, my);
      ctx.font = `${r.s.active ? 500 : 400} 11px ${font}`; ctx.fillStyle = r.s.active ? text : dim; ctx.fillText(r.s.name, 28, my);
      ctx.restore();
      // the shot: a bar from where it picks up the action
      ctx.globalAlpha = lifted ? 0.4 : 1;
      ctx.beginPath(); ctx.roundRect(x0, by, bw, bh, 3);
      if (r.s.active) { ctx.fillStyle = soft; ctx.fill(); }
      else { ctx.save(); ctx.fillStyle = text; ctx.globalAlpha *= 0.08; ctx.fill(); ctx.restore(); }
      if (picked.has(r.s.id)) { ctx.strokeStyle = accent; ctx.lineWidth = r.s.active ? 1 : 1.5; ctx.stroke(); } // picked: outlined in accent
      if (!r.s.active) { // its camera keys, as ticks
        ctx.fillStyle = text; ctx.globalAlpha *= 0.3;
        for (const k of tl.keys) if (k.t > 1e-6 && k.t < tl.duration - 1e-6) ctx.fillRect(Math.round(xAction(edgeKeyA(r.s, k.t) ?? st + k.t)), by + 4, 1, bh - 8);
      }
      ctx.globalAlpha = 1;
      if (ed) { // retiming: the dragged end in accent, and the new length beside it
        const ex = Math.min(W - 1, drag.side === 'right' ? x0 + bw : x0);
        ctx.fillStyle = accent; ctx.fillRect(Math.round(ex) - 1, by, 2, bh);
        const f = drag.dur / drag.dur0, label = `${drag.dur.toFixed(2)} s${drag.trim ? ' · trim' : Math.abs(f - 1) > 0.005 ? ` · ${f.toFixed(2)}×` : ''}`;
        ctx.font = `500 10px ${mono}`;
        const w = ctx.measureText(label).width, lx = drag.side === 'right' ? (ex + 6 + w < W - 2 ? ex + 6 : ex - 6 - w) : (ex - 6 - w > GUT + 2 ? ex - 6 - w : ex + 6);
        ctx.fillStyle = text; ctx.fillText(label, lx, r.top + 1 + INSET + 6);
      }
    }
    drawNewRow(W, { text, dim, line, accent, font, mono });
    // box select
    if (drag?.kind === 'box' && drag.moved) {
      const bx = Math.max(GUT, Math.min(drag.x0, drag.x1)), by = Math.max(RULER, Math.min(drag.y0, drag.y1));
      const bw = Math.min(W, Math.max(drag.x0, drag.x1)) - bx, bh = Math.max(drag.y0, drag.y1) - by;
      ctx.fillStyle = soft; ctx.globalAlpha = 0.5; ctx.fillRect(bx, by, bw, bh); ctx.globalAlpha = 1;
      ctx.strokeStyle = accent; ctx.lineWidth = 1; ctx.strokeRect(Math.round(bx) + 0.5, Math.round(by) + 0.5, Math.round(bw), Math.round(bh));
    }
    // reordering: where the dragged shot will land
    if (reorder && drag.to !== drag.from) {
      const r = L.rows[drag.to];
      ctx.fillStyle = accent; ctx.fillRect(0, (drag.to < drag.from ? r.top : r.top + r.h) - 0.5, W, 2);
    }
    ctx.restore();
    // more shots than fit: a scrollbar along the right edge of the lanes
    if (L.list.max > 0) {
      const vh = lb - lt, th = Math.max(16, (vh * vh) / (vh + L.list.max)), ty = lt + (scroll / L.list.max) * (vh - th);
      ctx.fillStyle = text; ctx.globalAlpha = 0.22;
      ctx.beginPath(); ctx.roundRect(W - 5, ty + 2, 3, th - 4, 1.5); ctx.fill(); ctx.globalAlpha = 1;
    }
    // the selected object's key lane is named after it
    const so = selObj();
    if (so?.anim?.length) {
      ctx.save(); ctx.beginPath(); ctx.rect(0, H0 - LANE, GUT - 8, LANE); ctx.clip();
      ctx.font = `10px ${mono}`; ctx.fillStyle = dim; ctx.fillText(so.id, 12, laneY() + 1);
      ctx.restore();
    }
    ctx.textBaseline = 'top';
    ctx.font = `10px ${mono}`;
  }

  /** The "+ New shot" row: its name in the header column and, while hovered or drawn, a dashed outline of
   *  the shot a click (the next one) or the drag (any span) would add, with a guide where it starts. */
  function drawNewRow(W, { text, dim, line, accent, font, mono }) {
    const r = L.add, my = r.top + r.h / 2 + 1, live = drag?.kind === 'new';
    const span = live && drag.moved ? { a0: Math.min(drag.a0, drag.a1), a1: Math.max(drag.a0, drag.a1) } : hoverNew || live ? nextSpan() : null;
    if (span) { ctx.fillStyle = accent; ctx.globalAlpha = 0.06; ctx.fillRect(0, r.top + 1, W, r.h - 1); ctx.globalAlpha = 1; }
    // header: a plus and the row's name
    const on = !!span;
    ctx.strokeStyle = on ? accent : dim; ctx.lineWidth = 1.4; ctx.lineCap = 'round';
    ctx.beginPath(); ctx.moveTo(10, my); ctx.lineTo(18, my); ctx.moveTo(14, my - 4); ctx.lineTo(14, my + 4); ctx.stroke();
    ctx.lineWidth = 1; ctx.lineCap = 'butt';
    ctx.font = `400 11px ${font}`; ctx.fillStyle = on ? text : dim; ctx.fillText('New shot', 28, my);
    if (!span) return;
    const x0 = xAction(span.a0), x1 = Math.min(W - 2, xAction(span.a1)), by = r.top + 1 + INSET, bh = r.h - 1 - INSET * 2;
    ctx.save(); ctx.beginPath(); ctx.rect(GUT + 1, r.top, W - GUT - 1, r.h); ctx.clip();
    ctx.beginPath(); ctx.roundRect(x0 + 0.75, by + 0.75, Math.max(2, x1 - x0 - 1.5), bh - 1.5, 3);
    ctx.fillStyle = accent; ctx.globalAlpha = 0.08; ctx.fill(); ctx.globalAlpha = 1;
    ctx.setLineDash([4, 3]); ctx.strokeStyle = accent; ctx.lineWidth = 1.5; ctx.stroke(); ctx.setLineDash([]); ctx.lineWidth = 1;
    ctx.restore();
    // a guide down through the lanes where it starts
    ctx.strokeStyle = accent; ctx.globalAlpha = 0.7; ctx.setLineDash([2, 3]);
    ctx.beginPath(); ctx.moveTo(Math.round(x0) + 0.5, RULER); ctx.lineTo(Math.round(x0) + 0.5, r.top); ctx.stroke();
    ctx.setLineDash([]); ctx.globalAlpha = 1;
    ctx.font = `10px ${mono}`;
  }

  function draw() {
    if (!store.doc) return;
    const dpr = devicePixelRatio || 1;
    relayout();
    placeKeyCard(); // the key card follows its key, also while it is dragged
    const W = track.clientWidth, H0 = track.clientHeight;
    if (track.width !== Math.round(W * dpr) || track.height !== Math.round(H0 * dpr)) { track.width = Math.round(W * dpr); track.height = Math.round(H0 * dpr); }
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, W, H0);
    const text = css('--cc-text'), dim = css('--cc-text-faint'), line = css('--cc-line'), accent = css('--cc-accent');
    const D = dur(), F = fps();
    ctx.font = `10px ${css('--cc-mono')}`;
    ctx.textBaseline = 'top';
    if (L) drawStack(W, H0, { text, dim, line, accent });
    const H = L ? L.active.h : H0; // the key editor: the whole track, or the active shot's row
    // inside it: `ct`..`cb` is where shots' bands and cut lines run (under the ruler, or within the bar),
    // and the keys sit on `mid`
    const ct = L ? 12 : RULER + 1, cb = L ? H - INSET : H;
    const mid = L ? H / 2 + 2 : RULER + Math.round((H - RULER) / 2);

    const ks = liveKeys();
    const cuts = cutsOf(ks), xs = keyXs(ks);
    if (L) { ctx.save(); ctx.beginPath(); ctx.rect(0, L.list.top + 1, W, L.list.bottom - L.list.top - 1); ctx.clip(); ctx.translate(0, L.active.top); ctx.beginPath(); ctx.rect(0, 0, W, H); ctx.clip(); }

    // ruler (one shot: in shot time; several: the stack's action-time ruler is drawn above)
    if (!L) drawRuler(W, D, xOf, F, { dim, line }, cuts);
    // shots and cuts: every hold key (but the last) ends a shot and the camera cuts to the next key.
    // With at least one cut, shots get a faint alternating band and a name; the baseline breaks at each cut.
    const eA = L && drag?.kind === 'edge' && drag.moved && drag.s.id === L.active.s.id; // the active shot's end is dragged
    const edges = [xOf(eA ? drag.st - L.start : 0), ...cuts.map((c) => c.x), xOf(eA ? drag.st - L.start + drag.dur : D)];
    ctx.fillStyle = text; ctx.globalAlpha = 0.045;
    for (let i = 1; i < edges.length - 1; i += 2) ctx.fillRect(edges[i], ct, edges[i + 1] - edges[i], cb - ct);
    ctx.globalAlpha = 1;
    ctx.fillStyle = line;
    for (let i = 0; i < edges.length - 1; i++) {
      const x0 = edges[i] + (i ? 7 : 0), x1 = edges[i + 1] - (i < edges.length - 2 ? 7 : 0);
      if (x1 > x0) ctx.fillRect(x0, mid, x1 - x0, 1);
    }
    // segments with a move's path (orbit, turn, dolly zoom ...) or a shudder: a heavier line and its name under it
    ctx.font = `500 10px ${css('--cc-font')}`; ctx.textAlign = 'center';
    for (let i = 0; i < ks.length - 1; i++) {
      const a = ks[i];
      if (!(a.path || a.shudder) || a.ease === 'hold') continue;
      const x0 = xs.get(a.id) + 6, x1 = xs.get(ks[i + 1].id) - 6;
      if (x1 <= x0) continue;
      ctx.fillStyle = text; ctx.globalAlpha = 0.35; ctx.fillRect(x0, mid - 0.5, x1 - x0, 2); ctx.globalAlpha = 1;
      const label = [pathLabel(a.path), a.shudder ? `shudder ×${a.shudder.jerks}` : ''].filter(Boolean).join(' · ');
      if (x1 - x0 > ctx.measureText(label).width + 8) { ctx.fillStyle = dim; ctx.fillText(label, (x0 + x1) / 2, mid + 6); }
    }
    ctx.textAlign = 'start'; ctx.font = `10px ${css('--cc-mono')}`;
    // a long hold before a cut (the shot ends on a still): dotted from the hold key to the cut
    ctx.strokeStyle = dim; ctx.setLineDash([2, 3]); ctx.beginPath();
    for (const c of cuts) if (!c.tight && c.x - xs.get(c.a.id) > 10) { ctx.moveTo(xs.get(c.a.id) + 6, mid + 0.5); ctx.lineTo(c.x - 6, mid + 0.5); }
    ctx.stroke(); ctx.setLineDash([]);

    // shot speed curve, faint, across the whole track
    const speed = resolveEase(store.doc.timeline.speed ?? 'linear');
    if (easeName(speed) !== 'linear') {
      ctx.strokeStyle = accent; ctx.globalAlpha = 0.25; ctx.beginPath();
      for (let i = 0; i <= 80; i++) { const u = i / 80; const y = cb - 4 - bezier(speed, u) * (cb - ct - 6); i ? ctx.lineTo(xOf(u * D), y) : ctx.moveTo(xOf(u * D), y); }
      ctx.stroke(); ctx.globalAlpha = 1;
    }

    // selected segment only: a soft "speed hump" showing how fast the camera moves from the selected key
    // to the next. Flat band = constant speed, a hill = speeds up then slows. Dotted = hold.
    const si = ks.findIndex((k) => k.id === store.state.key);
    if (si >= 0 && si < ks.length - 1) {
      const a = ks[si], b = ks[si + 1];
      const x0 = xs.get(a.id), x1 = xs.get(b.id);
      const e = resolveEase(a.ease);
      if (e === 'hold') {
        ctx.strokeStyle = accent; ctx.globalAlpha = 0.8; ctx.setLineDash([2, 3]);
        ctx.beginPath(); ctx.moveTo(x0, mid + 0.5); ctx.lineTo(x1, mid + 0.5); ctx.stroke();
        ctx.setLineDash([]); ctx.globalAlpha = 1;
      } else if (x1 - x0 >= 6) {
        const room = mid - ct - 3, k = Math.min(10, room / 2.2); // linear sits at k px; peaks clamp to the room above the line
        const n = Math.max(16, Math.round((x1 - x0) / 3));
        const pts = [];
        for (let j = 0; j <= n; j++) {
          const u = j / n, v = bezierSpeed(e, u, 0.004);
          pts.push([x0 + u * (x1 - x0), mid - Math.max(-6, Math.min(room, v * k))]);
        }
        ctx.beginPath(); ctx.moveTo(x0, mid);
        for (const [x, y] of pts) ctx.lineTo(x, y);
        ctx.lineTo(x1, mid); ctx.closePath();
        ctx.fillStyle = accent; ctx.globalAlpha = 0.16; ctx.fill();
        ctx.globalAlpha = 0.9; ctx.strokeStyle = accent; ctx.beginPath();
        pts.forEach(([x, y], j) => (j ? ctx.lineTo(x, y) : ctx.moveTo(x, y)));
        ctx.stroke(); ctx.globalAlpha = 1;
      }
    }

    // shot names, then the cut lines with a scissors tab over the ruler
    if (cuts.length) {
      ctx.font = `500 10px ${css('--cc-font')}`; ctx.fillStyle = dim;
      for (let i = 0; i < edges.length - 1; i++) if (edges[i + 1] - edges[i] >= 56) ctx.fillText(`Shot ${i + 1}`, edges[i] + (i ? 7 : 2), ct + 2);
      ctx.font = `10px ${css('--cc-mono')}`;
    }
    const sunk = css('--cc-surface-sunk');
    for (const c of cuts) {
      const x = Math.round(c.x) + 0.5;
      ctx.fillStyle = text; ctx.fillRect(x - 0.75, ct, 1.5, cb - ct);
      ctx.save(); ctx.translate(0, ct - 12); // the scissors tab sits in the 12 px above the cut line
      ctx.fillStyle = sunk; if (!L) ctx.fillRect(x - 7, 0, 14, 12);
      ctx.strokeStyle = text; ctx.lineWidth = 1.2; ctx.lineCap = 'round';
      ctx.beginPath(); ctx.arc(x - 2.8, 8.6, 1.8, 0, Math.PI * 2); ctx.moveTo(x + 4.6, 8.6); ctx.arc(x + 2.8, 8.6, 1.8, 0, Math.PI * 2);
      ctx.moveTo(x - 1.5, 7.2); ctx.lineTo(x + 2.8, 1.2); ctx.moveTo(x + 1.5, 7.2); ctx.lineTo(x - 2.8, 1.2);
      ctx.stroke(); ctx.lineWidth = 1; ctx.lineCap = 'butt';
      ctx.restore();
    }

    // keys. At a cut the pair becomes one split key: half square = the shot ends, half diamond = the next starts.
    const cutA = new Map(cuts.filter((c) => c.tight).map((c) => [c.a.id, c])), cutB = new Map(cuts.map((c) => [c.b.id, c]));
    for (const k of ks) {
      const x = xs.get(k.id), sel = selKeys.has(k.id), r = sel ? 6 : 5;
      ctx.beginPath();
      if (cutA.has(k.id)) { const cx = Math.round(cutA.get(k.id).x) + 0.5; ctx.rect(cx - 1.5 - (r - 0.5), mid - r + 1, r - 0.5, 2 * r - 2); }
      else if (cutB.has(k.id)) { const cx = Math.round(cutB.get(k.id).x) + 0.5; ctx.moveTo(cx + 1.5, mid - r); ctx.lineTo(cx + 1.5 + r, mid); ctx.lineTo(cx + 1.5, mid + r); ctx.closePath(); }
      else if (k.ease === 'hold') ctx.rect(x - r + 1, mid - r + 1, 2 * r - 2, 2 * r - 2);
      else { ctx.moveTo(x, mid - r); ctx.lineTo(x + r, mid); ctx.lineTo(x, mid + r); ctx.lineTo(x - r, mid); ctx.closePath(); }
      ctx.fillStyle = sel ? accent : text;
      ctx.fill();
    }

    if (L) ctx.restore();

    // selected object's keys, in a lane under the camera keys
    const oks = okeys();
    if (oks.length) {
      const y = laneY();
      const pts = oks.map((k) => (drag?.kind === 'okey' && Math.abs(drag.t0 - k.t) < 1e-3 ? drag.t : k.t)).sort((a, b) => a - b);
      ctx.fillStyle = accent; ctx.globalAlpha = 0.35;
      if (pts.length > 1) ctx.fillRect(xOf(pts[0]), y - 0.5, xOf(pts[pts.length - 1]) - xOf(pts[0]), 1.5);
      ctx.globalAlpha = 1;
      for (const t of pts) {
        ctx.beginPath(); ctx.arc(xOf(t), y, 3.5, 0, Math.PI * 2);
        ctx.fillStyle = css('--cc-surface-solid'); ctx.fill();
        ctx.lineWidth = 1.5; ctx.strokeStyle = accent; ctx.stroke(); ctx.lineWidth = 1;
      }
    }

    // playhead
    const px = Math.round(xOf(store.state.time));
    ctx.fillStyle = accent;
    ctx.fillRect(px, 0, 1.5, H0);
    ctx.beginPath(); ctx.moveTo(px - 4, 0); ctx.lineTo(px + 5.5, 0); ctx.lineTo(px + 0.75, 6); ctx.closePath(); ctx.fill();
  }

  // ---------- bar state ----------
  function refresh() {
    if (!store.doc) return;
    const tl = store.doc.timeline;
    const t = store.state.time;
    timeNow.textContent = t.toFixed(2);
    timeDur.textContent = ` / ${tl.duration.toFixed(2)} s`;
    timeEl.title = `Frame ${Math.round(t * tl.fps)}`;
    // only swap the icon when play state flips: refresh runs every frame while playing, and replacing the
    // icon under the pointer between mousedown and mouseup swallows the click.
    if (playBtn.dataset.playing !== String(!!store.state.playing)) {
      playBtn.dataset.playing = String(!!store.state.playing);
      playBtn.replaceChildren(icon(store.state.playing ? 'pause' : 'play'));
      playBtn.title = store.state.playing ? 'Pause (Space)' : 'Play (Space)';
    }
    loopSw.set(store.state.loop); playAllSw.set(!!store.state.playAll);
    playAllRow.hidden = store.doc.shots.length < 2;
    viewSeg.value = store.state.view;
    keyBtn.setActive(store.state.camDirty);
    keyBtn.title = store.state.camDirty ? 'The camera moved: press K to key this framing' : 'Key the current view at the playhead (K)';
    shotDur.textContent = tl.duration.toFixed(2);
    shotFps.textContent = fmtFps(tl.fps);
    syncSel();
    const k = store.state.key && store.keyById(store.state.key);
    keyGroup.style.display = k ? '' : 'none';
    const multi = selKeys.size > 1;
    easeBtn.style.display = toViewBtn.style.display = multi ? 'none' : ''; // .cc-btn sets display, so hidden alone would not hide it
    keyCaret.setActive(moves.open);
    // a selected key that starts a move: its card offers that move's settings again
    const editable = !!(k && k.path?.move && selKeys.size < 2 && keys().at(-1)?.id !== k.id);
    editMoveBtn.style.display = editable ? '' : 'none';
    delKeyBtn.title = multi ? `Delete ${selKeys.size} keys` : 'Delete key';
    if (k) {
      const sorted = keys();
      const i = sorted.findIndex((x) => x.id === k.id);
      const last = i === sorted.length - 1;
      keyTime.textContent = multi ? `${selKeys.size} keys` : `${k.t.toFixed(2)} s`;
      keyTime.title = multi ? 'Drag any selected key to move them all. Shift-click selects a range, Ctrl/Cmd-click adds or removes one' : `Key ${k.id}`;
      changed(easeGlyph, last ? 'linear' : k.ease, () => { easeGlyph.innerHTML = easeSvg(last ? 'linear' : k.ease); });
      easeName_.textContent = last ? 'last key' : easeName(k.ease);
      easeBtn.disabled = last;
      easeBtn.title = last ? 'Last key: no segment after it' : 'Easing from this key to the next (opens the curve editor)';
      pathSel.style.display = multi || last || k.ease === 'hold' ? 'none' : '';
      if (document.activeElement !== pathSel) pathSel.value = k.path?.type || 'smooth';
      pathSel.title = k.path ? `To the next key: ${pathLabel(k.path)}` : 'How the camera travels to the next key';
      // selecting a key (or the agent changing its lens) puts the free view on that lens too
      changed(lensField, [k.id, k.fov], () => viewport.setFreeFov(k.fov));
      changed(rollField, [k.id, k.roll], () => { viewport.freeRoll = k.roll || 0; });
    }
    const so = selObj();
    objKeyBtn.hidden = !so;
    if (so) {
      objKeyLabel.textContent = `Key ${so.id}`;
      const n = so.anim?.length || 0;
      objKeyBtn.title = n ? `${so.id} has ${n} key${n === 1 ? '' : 's'} (circles under the track). Key it at the playhead; dragging it with the gizmo also keys it` : `Start animating ${so.id}: key where it is now at the playhead`;
      objKeyBtn.classList.toggle('is-animated', !!n);
    }
    const shotView = store.state.view === 'shot';
    // the live camera wins while it is being changed by hand (Ctrl/Cmd + scroll, or a hand-framed shot)
    const lensFov = shotView ? (store.state.camDirty ? viewport.shotCam.fov : k ? k.fov : (sampleCamera(store.doc.timeline, store.state.time)?.fov ?? viewport.freeCam.fov)) : viewport.freeCam.fov;
    lensNum.set(Math.round(fovToLens(lensFov)));
    const lensOff = shotView && !k;
    lensField.classList.toggle('is-disabled', lensOff);
    lensNum.disabled = lensOff;
    const roll = shotView ? (store.state.camDirty ? viewport.shotRoll : k ? k.roll : (sampleCamera(store.doc.timeline, store.state.time)?.roll ?? 0)) : viewport.freeRoll;
    rollNum.set(Math.round(roll || 0));
    rollField.classList.toggle('is-disabled', lensOff && !store.state.camDirty);
    rollNum.disabled = lensOff && !store.state.camDirty;
    rollField.title = rollNum.disabled ? 'Select a key to change its roll (or hold the right mouse button and press Z / X)' : k ? 'Roll (Dutch tilt) of the selected key; the free view uses it too' : 'Roll (Dutch tilt) of the view; new keys get it';
    lensField.title = lensOff ? 'Select a key to change its lens' : k ? 'Lens of the selected key; the free view uses it too' : 'Lens of the free view; new keys get it';
    exportBtn.disabled = store.state.exporting;
    if (exportBtn.disabled && !exportPop.hidden) toggleExportMenu(false);
    const active = shotList(store.doc).find((s) => s.active);
    exportShotBtn.title = `Just the current shot${active?.name ? `, ${active.name}` : ''} (mp4)`;
    draw();
    audioTrack.refresh();
    curve.refresh();
    shot.refresh();
    shots.refresh();
    moves.refresh();
    // the track grows to fit the stacked shots
    relayout();
    const extra = L ? Math.max(0, L.height - BASE_H) : 0;
    if (extra !== lastExtra) { lastExtra = extra; document.documentElement.style.setProperty('--stack-h', `${extra}px`); requestAnimationFrame(draw); }
  }
  let lastExtra = 0;

  // ---------- curve editor + shot settings ----------
  const curve = mountCurveEditor(root, { updateKey, keys, onToggle: (open, mode) => { easeBtn.classList.toggle('is-open', open && mode === 'segment'); }, anchor: () => (keyCard.hidden ? easeBtn : keyCard),
    // clicks here keep it open: its own buttons, and the track, so you can pick another segment (to paste into) with it open
    keepOpen: (el) => easeBtn.contains(el) || keyCard.contains(el) || track.contains(el) });
  // Loop and Play all: a small menu that opens while the pointer is over Play (and stays while it is over the menu)
  const loopSw = onOff({ value: store.state.loop, title: 'Loop playback', onChange: (v) => store.set({ loop: v }) });
  const playAllSw = onOff({ value: !!store.state.playAll, title: 'Play all: playback runs on through the cuts into the next shot', onChange: (v) => store.set({ playAll: v }) });
  const swRow = (label, sw) => h('div.cc-row.tl-playrow', {}, sw, h('span.tl-playrow-label', { onClick: () => sw.click() }, label));
  const playAllRow = swRow('Play all shots', playAllSw);
  const playMenu = h('div.cc-panel.tl-playmenu', { hidden: true }, swRow('Loop', loopSw), playAllRow);
  document.body.append(playMenu);
  let playMenuTimer = 0;
  const showPlayMenu = (on) => {
    clearTimeout(playMenuTimer);
    if (!on) { playMenuTimer = setTimeout(() => { playMenu.hidden = true; }, 220); return; }
    playMenu.style.left = `${Math.max(12, playBtn.getBoundingClientRect().left - 4)}px`;
    playMenu.hidden = false;
  };
  for (const el of [playBtn, playMenu]) {
    el.addEventListener('pointerenter', () => showPlayMenu(true));
    el.addEventListener('pointerleave', () => showPlayMenu(false));
  }
  const shot = mountShotSettings(root, { anchor: shotBtn, keys, openSpeed: () => { shot.toggle(false); curve.toggle(true, 'speed'); } });
  const moves = mountMoves({ anchor: keyCaret, viewport });


  store.on('doc', refresh);
  store.on('state', refresh);
  new ResizeObserver(draw).observe(track);
  return { refresh, keyFromView, seek, xAt: (t) => xOf(t), yAt: () => (L ? L.active.top + L.active.h / 2 + 2 : 0), newRowY: () => (L ? L.add.top + L.add.h / 2 : 0), rowY: (id) => { const r = L?.rows.find((x) => x.s.id === id); return r ? r.top + r.h / 2 + 1 : 0; }, pickedShots: () => [...picked], xAction: (a) => xAction(a), deleteKey, draw, loadAudio: audioTrack.loadFile, shots, objKeyBtn };
}

/**
 * Popover with a draggable bezier ease for the segment at the playhead, or the shot-wide speed curve.
 * Click the curve to add a point with its own handles; double-click or right-click a point to remove it.
 */
function mountCurveEditor(root, { updateKey, keys, onToggle, anchor, keepOpen }) {
  // canvas layout: the curve on top, a speed strip under it, sharing one time axis
  const W = 276, H = 184, L = 18, R = W - 10, T = 10, CB = 124, ST = 136, SB = H - 6;
  const cv = h('canvas.curve-canvas', { width: W * 2, height: H * 2, style: { width: `${W}px`, height: `${H}px` } });
  const ctx = cv.getContext('2d');
  let mode = 'segment';
  const tabs = segmented({ options: [{ value: 'segment', label: 'Camera', title: 'How the camera moves from this key to the next' }, { value: 'speed', label: 'Playback', title: 'Playback speed of the whole shot: slow motion and fast forward for the camera and everything in it' }], value: mode, onChange: (v) => { mode = v; onToggle?.(api.open, mode); refresh(); } });
  const title = h('span.cc-label.cc-mono');
  const nameEl = h('span.curve-name');
  const presets = h('div.curve-presets');
  // how to use the editor: a tooltip on the help icon in the header (hover or focus it)
  const help = h('div.cc-panel.curve-tip', { role: 'tooltip' });
  const helpBtn = button({ icon: 'help', kind: 'ghost', title: '' });
  helpBtn.setAttribute('aria-label', 'How to edit the curve');
  const helpWrap = h('span.curve-tipwrap', {}, helpBtn, help);
  const closeBtn = button({ icon: 'close', kind: 'ghost', title: 'Close (Esc)', onClick: () => toggle(false) });
  closeBtn.setAttribute('aria-label', 'Close');

  // copy the segment's settings (curve + shudder) and paste them onto another segment, or onto the shot's playback speed
  const CLIP_KEY = 'cc-ease-clip';
  let clip = null; // { ease, shudder, from }
  try { const c = JSON.parse(localStorage.getItem(CLIP_KEY)); if (c && c.ease != null) clip = c; } catch {}
  const clipName = (c) => easeName(c.ease) + (c.shudder ? ' + shudder' : '');
  const same = (a, b) => JSON.stringify(a ?? null) === JSON.stringify(b ?? null);
  function copySettings() {
    const tg = target();
    if (!tg) return;
    clip = { ease: tg.ease, shudder: tg.kind === 'segment' && !isCut(tg.key) ? tg.key.shudder ?? null : null, from: tg.kind === 'segment' ? `${tg.key.id} → ${tg.next.id}` : 'playback' };
    try { localStorage.setItem(CLIP_KEY, JSON.stringify(clip)); } catch {}
    toast(`Copied ${clipName(clip)}. Pick another segment and paste it with the paste button or ${MOD}V`);
    refresh();
  }
  /** What paste would change here, or null when it would change nothing. */
  function pasteable(tg) {
    if (!clip || !tg) return null;
    if (tg.kind === 'speed') return clip.ease === 'hold' || same(clip.ease, tg.ease) ? null : { ease: clip.ease };
    const patch = { ease: clip.ease, shudder: clip.ease === 'hold' ? null : clip.shudder };
    return same(patch.ease, tg.ease) && same(patch.shudder, tg.key.shudder) ? null : patch;
  }
  function pasteSettings() {
    const tg = target(), patch = pasteable(tg);
    if (!patch) return;
    if (tg.kind === 'speed') { commit(patch.ease); return; }
    store.set({ key: tg.key.id });
    updateKey({ ease: patch.ease, shudder: patch.shudder || 'off' });
    toast(`Pasted ${clipName(clip)} onto ${tg.key.id} → ${tg.next.id}`);
  }
  const copyBtn = button({ icon: 'copy', kind: 'ghost', title: `Copy this curve and shudder (${MOD}C)`, onClick: copySettings });
  const pasteBtn = button({ icon: 'paste', kind: 'ghost', title: 'Paste', onClick: pasteSettings });

  // copy this segment's ease to every segment in every shot (cuts stay cuts), as one undo step, after a confirmation
  const allBtn = button({ icon: 'layers', label: 'Apply to all segments', title: 'Give every camera segment this ease, in every shot. Cuts stay cuts.', onClick: () => askAll(true) });
  const allCount = h('span.curve-all__count');
  allBtn.append(allCount);
  allBtn.classList.add('curve-all');
  const allMsg = h('span.curve-confirm__msg');
  const allYes = button({ label: 'Replace', kind: 'primary', onClick: () => {
    const tg = target();
    askAll(false);
    if (!tg || tg.kind !== 'segment') return;
    store.op({ op: 'key.easeAll', from: tg.key.id, allShots: true }, 'ease all segments')
      .then(([r]) => toast(`${easeName(tg.ease)} on ${r.updated} segment${r.updated === 1 ? '' : 's'}${r.shots > 1 ? ` in ${r.shots} shots` : ''}. ${MOD}Z undoes it`)).catch(() => {});
  } });
  const allNo = button({ label: 'Cancel', kind: 'ghost', onClick: () => askAll(false) });
  const allConfirm = h('div.curve-confirm', { hidden: true }, allMsg, h('div.cc-row.curve-confirm__row', {}, h('span.cc-spacer'), allNo, allYes));
  let asking = false;
  function askAll(on) { asking = on; refresh(); if (on) allYes.focus(); }
  // shudder: exact jerks back and forth along this segment, on top of its ease
  let liveSh = null; // settings being scrubbed, drawn before they are committed
  const shPatch = (patch) => { const tg = target(); return { ...SHUDDER_DEFAULT, ...tg?.key.shudder, ...patch }; };
  const shPreview = (patch) => { liveSh = shPatch(patch); paintRange(liveSh); draw(); };
  const shCommit = (patch) => {
    const tg = target();
    liveSh = null;
    if (!tg || tg.kind !== 'segment') return;
    store.set({ key: tg.key.id });
    updateKey({ shudder: patch === 'off' ? 'off' : shPatch(patch) });
  };
  const shOn = onOff({ title: 'Shudder: the camera jerks back and forth along this move', onChange: (v) => shCommit(v ? {} : 'off') });
  const shJerks = number({ value: SHUDDER_DEFAULT.jerks, step: 1, min: 1, max: 60, precision: 0, title: 'How many jerks over the move', onInput: (v) => shPreview({ jerks: v }), onChange: (v) => shCommit({ jerks: v }) });
  const shAmount = number({ value: SHUDDER_DEFAULT.amount, step: 0.5, min: 0.5, max: 50, precision: 1, title: 'How far each jerk pulls the camera back, as a share of the whole move', onInput: (v) => shPreview({ amount: v }), onChange: (v) => shCommit({ amount: v }) });
  // where in the segment it plays, in seconds from the segment's first key (stored as shares of the segment)
  const span = () => { const tg = target(); return tg?.kind === 'segment' ? Math.max(1e-3, tg.next.t - tg.key.t) : 1; };
  const shFrac = (sec) => Math.min(1, Math.max(0, sec / span()));
  const shFrom = number({ value: 0, step: 0.05, min: 0, precision: 2, width: 44, title: 'Where the shudder starts, in seconds after this key', onInput: (v) => shPreview({ from: shFrac(v) }), onChange: (v) => shCommit({ from: shFrac(v) }) });
  const shTo = number({ value: 1, step: 0.05, min: 0, precision: 2, width: 44, title: 'Where the shudder stops, in seconds after this key', onInput: (v) => shPreview({ to: shFrac(v) }), onChange: (v) => shCommit({ to: shFrac(v) }) });
  const shShape = segmented({ value: SHUDDER_DEFAULT.shape, onChange: (v) => shCommit({ shape: v }), options: [
    { value: 'jerk', label: 'Jerk', title: 'Snaps back, then eases forward again' },
    { value: 'wobble', label: 'Wobble', title: 'A smooth back and forth' },
    { value: 'stutter', label: 'Stutter', title: 'Falls behind, then catches up in one snap' }] });
  const shOver = segmented({ value: SHUDDER_DEFAULT.over, onChange: (v) => shCommit({ over: v }), options: [
    { value: 'even', label: 'Even', title: 'The same all the way' },
    { value: 'fade', label: 'Fade out', title: 'Strong at the start, gone by the end' },
    { value: 'build', label: 'Build', title: 'Grows towards the end' }] });
  // timing: a strip spanning the segment (key to key) with the shudder's section on it; drag an edge to
  // move that end, drag the middle to slide it, click outside it to bring the nearer end there
  const rangeFill = h('div.curve-range__fill', {}, h('span.curve-range__edge.is-from'), h('span.curve-range__edge.is-to'));
  const range = h('div.curve-range', { title: 'Where the shudder plays: drag an edge to move it, the middle to slide it' }, rangeFill);
  const rangeA = h('span.curve-range__key'), rangeB = h('span.curve-range__key');
  let rangeDrag = null;
  const rangeAt = (e) => { const r = range.getBoundingClientRect(); return Math.min(1, Math.max(0, (e.clientX - r.left) / r.width)); };
  const snapF = (f) => { const tl = store.doc.timeline, d = 1 / (tl.fps || 24) / span(); return Math.min(1, Math.max(0, Math.round(f / d) * d)); };
  range.addEventListener('pointerdown', (e) => {
    const tg = target();
    if (!tg || tg.kind !== 'segment') return;
    e.preventDefault();
    const v = { ...SHUDDER_DEFAULT, ...tg.key.shudder }, x = rangeAt(e), w = range.getBoundingClientRect().width, near = 8 / w;
    let edge = Math.abs(x - v.from) <= near ? 'from' : Math.abs(x - v.to) <= near ? 'to' : x > v.from && x < v.to ? 'move' : x < v.from ? 'from' : 'to';
    rangeDrag = { edge, x0: x, from: v.from, to: v.to, cur: { from: v.from, to: v.to } };
    if (edge !== 'move') { rangeDrag.cur[edge] = snapF(x); shPreview(rangeDrag.cur); }
    range.setPointerCapture(e.pointerId);
  });
  range.addEventListener('pointermove', (e) => {
    if (!rangeDrag) return;
    const x = rangeAt(e), d = rangeDrag, gap = 0.02;
    if (d.edge === 'move') { const len = d.to - d.from; const f = Math.min(1 - len, Math.max(0, snapF(d.from + x - d.x0))); d.cur = { from: f, to: f + len }; }
    else if (d.edge === 'from') d.cur = { from: Math.min(snapF(x), d.to - gap), to: d.to };
    else d.cur = { from: d.from, to: Math.max(snapF(x), d.from + gap) };
    shPreview(d.cur); paintRange(d.cur);
  });
  const endRange = () => { if (!rangeDrag) return; const c = rangeDrag.cur; rangeDrag = null; shCommit({ from: +c.from.toFixed(4), to: +c.to.toFixed(4) }); };
  range.addEventListener('pointerup', endRange);
  range.addEventListener('pointercancel', endRange);
  function paintRange(v) {
    rangeFill.style.left = `${v.from * 100}%`;
    rangeFill.style.right = `${(1 - v.to) * 100}%`;
  }
  const shBody = h('div.curve-shudder__body', {},
    h('div.cc-row', {}, h('span.cc-label', {}, 'Shape'), shShape),
    h('div.cc-row', {}, h('span.cc-label', {}, 'Strength'), shOver),
    h('div.cc-row', {}, h('span.cc-label', {}, 'Jerks'), shJerks, h('span.cc-label.curve-shudder__back', {}, 'Amount'), affix(shAmount, '%')),
    h('div.curve-shudder__sec', {}, 'Timing'),
    range,
    h('div.curve-range__axis', {}, rangeA, h('span.curve-range__fields', {}, affix(shFrom, 's'), h('span.curve-range__dash', {}, '–'), affix(shTo, 's')), rangeB));
  const shWrap = h('div.curve-shudder', {}, h('div.cc-row', {}, h('span.cc-label', {}, 'Shudder'), h('span.cc-spacer'), shOn), shBody);
  // the header stays put while the body scrolls on short screens, so close is always in reach
  const pop = h('div.cc-panel.curve-pop', { hidden: true },
    h('div.curve-pop__head', {},
      h('div.cc-row', {}, tabs, h('span.cc-spacer'), h('div.curve-pop__tools', {}, copyBtn, pasteBtn, helpWrap, closeBtn)),
      h('div.cc-row.curve-head', {}, title, nameEl)),
    h('div.curve-pop__body', {}, cv, presets, h('div.curve-sep'), shWrap, allBtn, allConfirm));
  document.body.append(pop); // outside #timeline: its blurred panel would become the box `position: fixed` measures from

  // The ease is a flat array (see resolveEase): pairs at index % 6 = 0 or 2 are handles, % 6 = 4 points.
  let live = null;    // bezier being dragged
  let dragging = -1;  // index of the pair being dragged
  let hover = -1;     // index of the pair under the pointer, or -2 over the curve (click adds a point)
  let preview = null; // preset name under the pointer, drawn as a ghost
  let lo = 0, hi = 1; // visible progress range; grows past [0, 1] only when the curve does
  const api = { open: false, toggle, refresh };

  const toX = (x) => L + x * (R - L);
  const toY = (y) => CB - ((y - lo) / (hi - lo)) * (CB - T);
  const fromX = (px) => Math.min(1, Math.max(0, (px - L) / (R - L)));
  const fromY = (py) => Math.min(1.6, Math.max(-0.6, lo + ((CB - py) / (CB - T)) * (hi - lo)));

  /** Fit the vertical range to the curve and its handles. While dragging it only grows, so the view never jumps under the pointer. */
  function fit(b) {
    let mn = 0, mx = 1;
    if (b !== 'hold') {
      for (let i = 1; i < b.length; i += 2) { mn = Math.min(mn, b[i]); mx = Math.max(mx, b[i]); }
      for (let i = 0; i <= 40; i++) { const y = bezier(b, i / 40); mn = Math.min(mn, y); mx = Math.max(mx, y); }
    }
    const pad = 0.07 * (mx - mn);
    const nlo = mn - pad, nhi = mx + pad;
    if (dragging >= 0) { lo = Math.min(lo, nlo); hi = Math.max(hi, nhi); } else { lo = nlo; hi = nhi; }
  }

  function target() {
    const tl = store.doc.timeline;
    if (mode === 'speed') return { kind: 'speed', ease: tl.speed ?? 'linear', label: `whole shot · ${tl.duration}s` };
    const ks = keys();
    if (ks.length < 2) return null;
    let i = ks.findIndex((k) => k.id === store.state.key);
    if (i < 0 || i === ks.length - 1) i = sampleCamera(tl, store.state.time)?.segment ?? 0;
    i = Math.min(i, ks.length - 2);
    return { kind: 'segment', key: ks[i], next: ks[i + 1], ease: ks[i].ease, label: `${ks[i].id} → ${ks[i + 1].id} · ${(ks[i + 1].t - ks[i].t).toFixed(2)}s` };
  }

  function commit(ease) {
    const tg = target();
    if (!tg) return;
    if (tg.kind === 'speed') store.op({ op: 'timeline', speed: ease }, 'speed curve').catch(() => {});
    else { store.set({ key: tg.key.id }); updateKey({ ease }); }
  }

  const curvePath = (b) => {
    ctx.beginPath();
    if (b === 'hold') { ctx.moveTo(toX(0), toY(0)); ctx.lineTo(toX(1), toY(0)); ctx.lineTo(toX(1), toY(1)); return; }
    for (let i = 0; i <= 100; i++) { const u = i / 100; const y = bezier(b, u); i ? ctx.lineTo(toX(u), toY(y)) : ctx.moveTo(toX(u), toY(y)); }
  };

  function draw() {
    const tg = target();
    ctx.setTransform(2, 0, 0, 2, 0, 0);
    ctx.clearRect(0, 0, W, H);
    const css = (n) => getComputedStyle(document.documentElement).getPropertyValue(n).trim();
    const line = css('--cc-line'), strong = css('--cc-line-strong'), text = css('--cc-text'), accent = css('--cc-accent'), faint = css('--cc-text-faint');
    const surface = css('--cc-surface-solid');
    const font = (px) => `${px}px ${css('--cc-font') || 'sans-serif'}`;
    const b = tg ? (live || resolveEase(tg.ease)) : 'hold';
    const sh = tg?.kind === 'segment' && b !== 'hold' ? liveSh || tg.key.shudder || null : null;
    const prog = (u) => shudder(sh, bezier(b, u), u);
    fit(tg ? b : 'linear');

    // grid: quarter-time verticals through curve and strip, the 0 and 1 progress lines
    ctx.strokeStyle = line; ctx.lineWidth = 1;
    for (const x of [0.25, 0.5, 0.75]) { ctx.beginPath(); ctx.moveTo(toX(x) + 0.5, T); ctx.lineTo(toX(x) + 0.5, SB); ctx.stroke(); }
    ctx.strokeStyle = strong;
    for (const y of [0, 1]) { ctx.beginPath(); ctx.moveTo(L, Math.round(toY(y)) + 0.5); ctx.lineTo(R, Math.round(toY(y)) + 0.5); ctx.stroke(); }
    ctx.beginPath(); ctx.moveTo(L, SB + 0.5); ctx.lineTo(R, SB + 0.5); ctx.stroke();
    // axis hints
    ctx.fillStyle = faint; ctx.font = font(9);
    ctx.save(); ctx.translate(L - 6, (toY(0) + toY(1)) / 2); ctx.rotate(-Math.PI / 2); ctx.textAlign = 'center'; ctx.fillText('progress →', 0, 0); ctx.restore();
    if (!tg) { ctx.fillStyle = faint; ctx.font = font(11); ctx.textAlign = 'center'; ctx.fillText('Add a second key to ease between them', W / 2, (T + CB) / 2); ctx.textAlign = 'left'; return; }

    // linear reference, then the hovered preset as a ghost
    ctx.strokeStyle = line; ctx.setLineDash([2, 3]);
    ctx.beginPath(); ctx.moveTo(toX(0), toY(0)); ctx.lineTo(toX(1), toY(1)); ctx.stroke();
    if (preview && !live && easeName(tg.ease) !== preview) {
      ctx.strokeStyle = accent; ctx.globalAlpha = 0.55; ctx.lineWidth = 1.5; curvePath(resolveEase(preview)); ctx.stroke(); ctx.globalAlpha = 1; ctx.lineWidth = 1;
    }
    ctx.setLineDash([]);

    // curve, and with a shudder the path the camera really takes on top of it
    ctx.strokeStyle = text; ctx.lineWidth = 2; ctx.lineJoin = 'round'; curvePath(b); ctx.stroke(); ctx.lineWidth = 1;
    if (sh && ((sh.from ?? 0) > 0 || (sh.to ?? 1) < 1)) {
      ctx.fillStyle = accent; ctx.globalAlpha = 0.08;
      ctx.fillRect(toX(sh.from ?? 0), T, toX(sh.to ?? 1) - toX(sh.from ?? 0), SB - T); ctx.globalAlpha = 1;
    }
    if (sh) {
      ctx.beginPath();
      for (let i = 0; i <= 400; i++) { const u = i / 400; (i ? ctx.lineTo : ctx.moveTo).call(ctx, toX(u), toY(prog(u))); }
      ctx.strokeStyle = accent; ctx.lineWidth = 1.5; ctx.stroke(); ctx.lineWidth = 1;
    }
    ctx.fillStyle = text;
    for (const [x, y] of [[0, 0], [1, 1]]) { ctx.beginPath(); ctx.arc(toX(x), toY(y), 2.5, 0, Math.PI * 2); ctx.fill(); }

    // speed strip: how fast the camera moves along its path, 1× = linear
    ctx.fillStyle = faint; ctx.font = font(9); ctx.textAlign = 'right'; ctx.fillText('time →', R, ST + 8); ctx.textAlign = 'left';
    if (b === 'hold') { ctx.fillText('speed · holds, then cuts', L + 3, ST + 8); }
    else {
      const N = sh ? 400 : 80, sp = [], d = 1e-3;
      let mx = 0, mn = 0;
      const speedAt = (u) => (sh ? (prog(Math.min(1, u + d)) - prog(Math.max(0, u - d))) / (Math.min(1, u + d) - Math.max(0, u - d)) : bezierSpeed(b, u));
      for (let i = 0; i <= N; i++) { const s = speedAt(i / N); sp.push(s); mx = Math.max(mx, s); mn = Math.min(mn, s); }
      const top = Math.max(2, mx), sy = (s) => SB - ((s - mn) / (top - mn)) * (SB - ST - 10);
      ctx.beginPath(); ctx.moveTo(toX(0), sy(0));
      sp.forEach((s, i) => ctx.lineTo(toX(i / N), sy(s)));
      ctx.lineTo(toX(1), sy(0)); ctx.closePath();
      ctx.fillStyle = accent; ctx.globalAlpha = 0.14; ctx.fill(); ctx.globalAlpha = 1;
      ctx.beginPath(); sp.forEach((s, i) => (i ? ctx.lineTo : ctx.moveTo).call(ctx, toX(i / N), sy(s)));
      ctx.strokeStyle = accent; ctx.lineWidth = 1.25; ctx.stroke(); ctx.lineWidth = 1;
      ctx.strokeStyle = line; ctx.setLineDash([2, 3]); ctx.beginPath(); ctx.moveTo(L, sy(1)); ctx.lineTo(R, sy(1)); ctx.stroke(); ctx.setLineDash([]);
      if (mn < 0) { ctx.strokeStyle = strong; ctx.beginPath(); ctx.moveTo(L, sy(0) + 0.5); ctx.lineTo(R, sy(0) + 0.5); ctx.stroke(); }
      ctx.fillStyle = faint; ctx.fillText(`speed · peak ${mx.toFixed(1)}×${mn < -0.01 ? ' · backs up' : ''}`, L + 3, ST + 8);
    }
    if (b === 'hold') return;

    // handles: arm from its point, hollow when idle, filled when hovered or dragged; added points are diamonds
    for (const k of pairs(b)) {
      if (k % 6 === 4) continue;
      const [ax, ay] = anchorOf(b, k), on = k === hover || k === dragging;
      ctx.strokeStyle = accent; ctx.lineWidth = 1.25;
      ctx.beginPath(); ctx.moveTo(toX(ax), toY(ay)); ctx.lineTo(toX(b[k]), toY(b[k + 1])); ctx.stroke();
      ctx.beginPath(); ctx.arc(toX(b[k]), toY(b[k + 1]), on ? 6 : 5, 0, Math.PI * 2);
      ctx.fillStyle = on ? accent : surface; ctx.fill(); ctx.lineWidth = 2; ctx.stroke(); ctx.lineWidth = 1;
    }
    for (const k of pairs(b)) {
      if (k % 6 !== 4) continue;
      const on = k === hover || k === dragging, x = toX(b[k]), y = toY(b[k + 1]), r = on ? 6 : 5;
      ctx.beginPath(); ctx.moveTo(x, y - r); ctx.lineTo(x + r, y); ctx.lineTo(x, y + r); ctx.lineTo(x - r, y); ctx.closePath();
      ctx.fillStyle = on ? accent : text; ctx.fill(); ctx.strokeStyle = surface; ctx.lineWidth = 1.5; ctx.stroke(); ctx.lineWidth = 1;
    }
  }

  // ----- the pieces of a bezier ease: pairs (handles and points) by their index in the flat array -----
  const pairs = (b) => (b === 'hold' ? [] : b.map((_, i) => i).filter((i) => i % 2 === 0));
  // point j (0 = start, last = end) as [x, y]
  const pointAt = (b, j) => (j <= 0 ? [0, 0] : 6 * j - 2 >= b.length ? [1, 1] : [b[6 * j - 2], b[6 * j - 1]]);
  // the point a handle hangs from: an outgoing handle (% 6 = 0) from the point before it, an incoming one from the point after
  const anchorOf = (b, k) => (k % 6 === 0 ? pointAt(b, k / 6) : pointAt(b, (k + 4) / 6));
  // a handle's segment, as the x range it may move in (so the curve stays a function of time)
  const rangeOf = (b, k) => { const s = Math.floor(k / 6); return [pointAt(b, s)[0], pointAt(b, s + 1)[0]]; };
  // the other handle of the same point, or -1 at the start and end
  const twinOf = (b, k) => { const t = k % 6 === 0 ? k - 4 : k + 4; return t > 0 && t < b.length - 2 && t % 6 !== 4 ? t : -1; };
  const clampX = (b, k) => { const [a, c] = rangeOf(b, k); b[k] = Math.min(c, Math.max(a, b[k])); };

  /** Move pair k of live to (x, y). A point carries its handles; a handle turns its twin with it unless Alt is held. */
  function moveTo(k, x, y, free) {
    const b = live;
    if (k % 6 === 4) {
      const j = (k + 2) / 6, gap = 0.01;
      x = Math.min(pointAt(b, j + 1)[0] - gap, Math.max(pointAt(b, j - 1)[0] + gap, x));
      const dx = x - b[k], dy = y - b[k + 1];
      b[k] = x; b[k + 1] = y;
      for (const h of [k - 2, k + 2]) { b[h] += dx; b[h + 1] += dy; }
      for (const h of [k - 6, k - 4, k - 2, k + 2, k + 4, k + 6]) if (h >= 0 && h < b.length && h % 6 !== 4) clampX(b, h);
    } else {
      b[k] = x; b[k + 1] = y; clampX(b, k);
      const t = twinOf(b, k);
      if (t >= 0 && !free) {
        // keep the point smooth: the twin points the opposite way, keeping its own length
        const [px, py] = anchorOf(b, k);
        const ux = b[k] - px, uy = b[k + 1] - py, ul = Math.hypot(ux, uy);
        const len = Math.hypot(b[t] - px, b[t + 1] - py);
        if (ul > 1e-6) {
          let vx = (-ux / ul) * len, vy = (-uy / ul) * len;
          const [a, c] = rangeOf(b, t), room = vx < 0 ? px - a : c - px;
          if (Math.abs(vx) > room) { const f = room / Math.abs(vx); vx *= f; vy *= f; }
          b[t] = px + vx; b[t + 1] = py + vy;
        }
      }
    }
    for (let i = 0; i < b.length; i++) b[i] = +b[i].toFixed(3);
  }

  const pos = (e) => { const r = cv.getBoundingClientRect(); return [e.clientX - r.left, e.clientY - r.top]; };
  /** The pair under the pointer, -2 when it is over the curve itself (a click adds a point there), else -1. */
  const nearest = (e) => {
    const tg = target(); if (!tg) return -1;
    const b = live || resolveEase(tg.ease); if (b === 'hold') return -1;
    const [x, y] = pos(e);
    let best = -1, bd = 12;
    for (const k of pairs(b)) {
      const d = Math.hypot(toX(b[k]) - x, toY(b[k + 1]) - y) - (k % 6 === 4 ? 3 : 0); // points win a near tie
      if (d < bd) { bd = d; best = k; }
    }
    if (best >= 0) return best;
    const u = (x - L) / (R - L);
    return u > 0.01 && u < 0.99 && Math.abs(toY(bezier(b, u)) - y) < 7 ? -2 : -1;
  };
  const cursorFor = (i) => (i === -2 ? 'copy' : i < 0 ? '' : 'grab');
  function finish(b) {
    const name = easeName(b);
    if (name === 'custom') remember(b);
    commit(name !== 'custom' ? name : b);
  }
  function removePoint(k) {
    const tg = target(); if (!tg || k % 6 !== 4) return;
    dragging = -1; live = null; hover = -1; cv.style.cursor = '';
    finish(removeEasePoint(resolveEase(tg.ease), (k + 2) / 6));
  }
  cv.addEventListener('pointerdown', (e) => {
    if (e.button !== 0) return;
    let i = nearest(e); if (i === -1) return;
    const b = [...resolveEase(target().ease)];
    if (i === -2) {
      // a new point on the curve, split so the shape stays the same; keep dragging it
      const { ease, point } = splitEase(b, fromX(pos(e)[0]));
      live = ease; i = 6 * point - 2;
    } else live = b;
    dragging = i;
    cv.setPointerCapture(e.pointerId);
    cv.style.cursor = 'grabbing';
    showName();
    draw();
  });
  cv.addEventListener('pointermove', (e) => {
    if (dragging < 0) {
      const i = nearest(e);
      if (i !== hover) { hover = i; cv.style.cursor = cursorFor(i); draw(); }
      return;
    }
    const [x, y] = pos(e);
    moveTo(dragging, fromX(x), fromY(y), e.altKey);
    showName();
    draw();
  });
  cv.addEventListener('pointerleave', () => { if (dragging < 0 && hover !== -1) { hover = -1; draw(); } });
  cv.addEventListener('pointerup', (e) => {
    if (dragging < 0) return;
    dragging = -1;
    const b = live; live = null;
    showName();
    hover = nearest(e); cv.style.cursor = cursorFor(hover);
    finish(b);
  });
  // double-click or right-click a point to remove it
  cv.addEventListener('dblclick', (e) => { const i = nearest(e); if (i >= 0 && i % 6 === 4) removePoint(i); });
  cv.addEventListener('contextmenu', (e) => { const i = nearest(e); if (i >= 0 && i % 6 === 4) { e.preventDefault(); removePoint(i); } });

  const showName = () => {
    const tg = target();
    const current = tg ? easeName(tg.ease) : '';
    // while dragging: the bezier numbers; hovering a preset: its name; otherwise the current ease
    nameEl.classList.toggle('cc-mono', !!live);
    const pn = Array.isArray(preview) ? 'your custom' : preview;
    const points = (b) => (Array.isArray(b) && b.length > 4 ? ` · ${(b.length - 4) / 6} point${b.length === 10 ? '' : 's'}` : '');
    nameEl.textContent = live ? (live.length === 4 ? live.map((n) => n.toFixed(2)).join(', ') : `custom${points(live)}`)
      : pn && pn !== current ? pn : current + (current === 'custom' ? points(tg.ease) : '')
      + (!live && !(pn && pn !== current) && tg?.kind === 'segment' && tg.key.shudder && !isCut(tg.key) ? ' + shudder' : '');
    nameEl.classList.toggle('is-preview', !live && !!pn && pn !== current);
  };

  // the last custom curve you drew, kept for this browser so the editor offers it again next time;
  // with none saved, the first custom ease in the scene
  const CUSTOM_KEY = 'cc-custom-ease';
  function remember(b) { try { localStorage.setItem(CUSTOM_KEY, JSON.stringify(b)); } catch {} }
  function remembered() {
    try {
      const b = JSON.parse(localStorage.getItem(CUSTOM_KEY));
      if (Array.isArray(b) && Array.isArray(resolveEase(b))) return b;
    } catch {}
    for (const s of shotList(store.doc).length ? shotList(store.doc) : [{ timeline: store.doc.timeline }]) {
      for (const k of s.timeline.keys) if (Array.isArray(k.ease) && easeName(k.ease) === 'custom') return k.ease;
    }
    if (Array.isArray(store.doc.timeline.speed) && easeName(store.doc.timeline.speed) === 'custom') return store.doc.timeline.speed;
    return null;
  }

  /** The last cell: the segment's own custom curve, else your last custom curve (click to use it), else an empty slot. */
  function customCell(tg, current) {
    const own = current === 'custom';
    const b = own ? tg.ease : remembered();
    if (!b) return h('button.cc-btn.cc-btn--ghost.curve-preset.is-empty', {
      type: 'button', title: 'Drag the handles or add points for a custom curve. It stays here for next time.', 'aria-label': 'custom', disabled: true,
      html: '<svg viewBox="0 0 16 16" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.5" stroke-dasharray="2 2"><path d="M2 13C7 13 9 3 14 3"/></svg>',
    });
    return h('button.cc-btn.cc-btn--ghost.curve-preset', {
      type: 'button', 'aria-label': 'custom', html: easeSvg(b, 18),
      title: own ? 'custom (drag the handles, click the curve to add a point)' : 'Your last custom curve: click to use it here',
      class: own ? 'is-active' : 'is-custom',
      onClick: () => { if (!own) commit(b); },
      onPointerenter: () => { if (!own) { preview = b; showName(); draw(); } },
      onPointerleave: () => { if (preview === b) { preview = null; showName(); draw(); } },
    });
  }

  function refresh() {
    if (!api.open || !store.doc) return;
    const tg = target();
    title.textContent = tg ? tg.label : '';
    const current = tg ? easeName(tg.ease) : '';
    // a grid of curve thumbnails; the last cell holds a custom curve when there is one
    const names = Object.keys(EASES).filter((k) => !(mode === 'speed' && k === 'hold'));
    // rebuilding removes the hovered button without a pointerleave, so drop its preview
    const mine = current === 'custom' ? tg.ease : remembered();
    changed(presets, [mode, current, JSON.stringify(mine)], () => (preview = null, presets.replaceChildren(
      ...names.map((k) => h('button.cc-btn.cc-btn--ghost.curve-preset', {
        type: 'button', title: k, 'aria-label': k, html: easeSvg(k, 18),
        class: k === current ? 'is-active' : null,
        onClick: () => commit(k),
        onPointerenter: () => { preview = k; showName(); draw(); },
        onPointerleave: () => { if (preview === k) { preview = null; showName(); draw(); } },
      })),
      customCell(tg, current))));
    showName();
    // only worth offering when another segment would change
    const ks = keys(), cur = tg?.ease;
    const others = tg?.kind === 'segment' ? ks.slice(0, -1).filter((k) => k !== tg.key && !isCut(k)) : [];
    // every segment in every shot that the button would set (cuts stay cuts)
    const multi = (store.doc.shots?.length || 0) > 1;
    const segs = tg?.kind === 'segment' ? (multi ? shotList(store.doc).map((x) => x.timeline) : [store.doc.timeline])
      .flatMap((tl) => [...tl.keys].sort((a, b) => a.t - b.t).slice(0, -1).filter((k) => !isCut(k))) : [];
    allBtn.hidden = !others.length && !multi || !segs.length || isCut(tg.key);
    allBtn.disabled = segs.every((k) => JSON.stringify(k.ease) === JSON.stringify(cur));
    allBtn.querySelector('.cc-btn__label').textContent = multi ? 'Apply to all shots' : 'Apply to all segments';
    allCount.textContent = allBtn.disabled ? 'all match' : `${segs.length} segment${segs.length === 1 ? '' : 's'}`;
    if (allBtn.hidden || allBtn.disabled) asking = false;
    const nShots = multi ? new Set(shotList(store.doc).filter((x) => x.timeline.keys.length > 1).map((x) => x.id)).size : 1;
    allMsg.textContent = `Replace the curve on ${segs.length} segment${segs.length === 1 ? '' : 's'}${nShots > 1 ? ` in ${nShots} shots` : ''} with ${easeName(cur)}? Their own curves are overwritten. Cuts stay cuts.`;
    allConfirm.hidden = !asking;
    if (asking) allBtn.hidden = true;
    copyBtn.title = tg ? `Copy ${tg.kind === 'speed' ? 'this playback curve' : 'this curve and shudder'} (${MOD}C)` : 'Copy';
    copyBtn.disabled = !tg;
    pasteBtn.hidden = !clip;
    const pv = pasteable(tg);
    pasteBtn.disabled = !pv;
    pasteBtn.title = !clip ? '' : pv ? `Paste ${tg.kind === 'speed' ? easeName(clip.ease) : clipName(clip)}, copied from ${clip.from} (${MOD}V)`
      : tg?.kind === 'speed' && clip.ease === 'hold' ? 'A cut can not be pasted onto playback speed' : `Already ${clipName(clip)}, as copied from ${clip.from}`;
    allBtn.title = allBtn.disabled ? 'Every segment already has this ease' : `Give all ${segs.length} camera segments${multi ? ` in all ${store.doc.shots.length} shots` : ''} this ease. Cuts stay cuts.`;
    const seg = tg?.kind === 'segment' && !isCut(tg.key);
    shWrap.hidden = !seg;
    if (seg && !liveSh) { // not while a field is being scrubbed
      const cur = tg.key.shudder;
      shOn.set(!!cur); shBody.hidden = !cur;
      const v = { ...SHUDDER_DEFAULT, ...cur };
      shJerks.set(v.jerks); shAmount.set(v.amount); shShape.value = v.shape; shOver.value = v.over;
      const len = tg.next.t - tg.key.t;
      shFrom.set(+(v.from * len).toFixed(2)); shTo.set(+(v.to * len).toFixed(2));
      if (!rangeDrag) paintRange(v);
      rangeFill.dataset.over = v.over;
      rangeA.textContent = `${tg.key.id} 0 s`; rangeB.textContent = `${tg.next.id} ${+len.toFixed(2)} s`;
    }
    // never taller than the room above it (it sits on its bottom edge): the body scrolls inside instead
    const room = Math.floor(pop.getBoundingClientRect().bottom - 12);
    if (room > 0 && pop.style.maxHeight !== `${room}px`) pop.style.maxHeight = `${room}px`;
    const tip = mode === 'speed'
      ? 'Slow motion and fast forward for the camera and everything in the shot. Its length stays the same.'
      : 'Drag the orange handles. Click the curve to add a point, double-click a point to remove it. Alt breaks a point\'s handles apart.';
    if (help.textContent !== tip) help.textContent = tip;
    draw();
  }

  function toggle(on, m) {
    if (on === undefined) on = !(api.open && (!m || m === mode));
    if (m) { mode = m; tabs.value = m; }
    api.open = on; pop.hidden = !on; onToggle?.(on, mode);
    if (!on) { preview = null; asking = false; }
    if (on && anchor) {
      const a = mode === 'speed' ? null : anchor();
      const r = a && a.getClientRects().length ? a.getBoundingClientRect() : null;
      // over the key card: flush with its left edge; otherwise a little left of the ease button
      const x = a?.classList.contains('tl-keycard') ? r?.left : r && r.left - 40;
      pop.style.left = r ? `${Math.max(12, Math.min(innerWidth - 304, x))}px` : '';
    }
    refresh();
  }
  // a click anywhere else closes it; Esc too. While it is open, Cmd/Ctrl+C and V copy and paste its settings
  addEventListener('pointerdown', (e) => {
    if (api.open && !pop.contains(e.target) && !keepOpen?.(e.target) && !e.target.closest?.('.cc-toast-stack')) toggle(false);
  }, true);
  addEventListener('keydown', (e) => {
    if (!api.open) return;
    if (e.key === 'Escape') { e.stopPropagation(); if (asking) askAll(false); else toggle(false); return; }
    const typing = e.target.closest?.('input, textarea, select, [contenteditable="true"]');
    if (typing || !(e.metaKey || e.ctrlKey) || e.shiftKey || e.altKey || getSelection()?.toString()) return;
    const k = e.key.toLowerCase();
    if (k === 'c') { e.preventDefault(); copySettings(); } else if (k === 'v' && clip) { e.preventDefault(); pasteSettings(); }
  }, true);
  return api;
}


/** Popover from the "5.00 s · 24 fps" chip: duration (with retime), frame rate (any value, presets), export size, shot speed. */
function mountShotSettings(root, { anchor, keys, openSpeed }) {
  let retime = true;
  try { retime = localStorage.getItem(RETIME_KEY) !== '0'; } catch {}
  const tlOp = (patch, label) => store.op({ op: 'timeline', ...patch }, label).catch(() => {});
  const setDur = (v) => tlOp({ duration: +v.toFixed(3), retime: retime || undefined }, 'shot length');

  const durNum = number({ step: 0.1, min: 0.1, max: 600, precision: 2, width: 44, title: 'Shot length in seconds. Drag to scrub, Shift for big steps.', onChange: setDur });
  const less = button({ icon: 'minus', kind: 'ghost', title: 'Half a second shorter', onClick: () => setDur(Math.max(0.1, store.doc.timeline.duration - 0.5)) });
  const more = button({ icon: 'plus', kind: 'ghost', title: 'Half a second longer', onClick: () => setDur(Math.min(600, store.doc.timeline.duration + 0.5)) });
  const durField = h('div.cc-affix.shot-dur', {}, less, durNum, h('span.cc-affix__unit', {}, 's'), more);
  const retimeSw = onOff({ value: retime, title: 'Scale key times with the shot length so the move keeps its timing', onChange: (v) => { retime = v; try { localStorage.setItem(RETIME_KEY, v ? '1' : '0'); } catch {} } });

  const fpsNum = number({ step: 1, min: 1, max: 120, precision: 3, width: 48, title: 'Frames per second. Any value, e.g. 23.976.', onChange: (v) => tlOp({ fps: v }, 'frame rate') });

  const sizeSel = select({ options: [], title: 'Export size', onChange: (v) => { const [width, height] = v.split('x').map(Number); store.op({ op: 'meta', width, height }, 'export size').catch(() => {}); } });
  const speedBtn = h('button.cc-field.tl-ease', { type: 'button', title: 'Playback speed: slow motion and fast forward for the whole shot', onClick: () => openSpeed() });
  const foot = h('div.cc-label.cc-mono.shot-foot');

  const p = panel({ title: 'Shot', collapsible: false, actions: [button({ icon: 'close', kind: 'ghost', title: 'Close (Esc)', onClick: () => toggle(false) })] });
  p.classList.add('shot-pop');
  p.hidden = true;
  const rowEl = (label, ...c) => h('div.cc-row', {}, h('span.cc-label', {}, label), ...c);
  p.body.append(
    rowEl('Duration', durField),
    h('div.cc-row.shot-sub', {}, retimeSw, h('span.shot-sub-text', { onClick: () => retimeSw.click() }, 'Stretch keys to fit')),
    rowEl('Frame rate', affix(fpsNum, 'fps')),
    rowEl('Size', sizeSel),
    rowEl('Playback', speedBtn),
    h('div.cc-divider.cc-divider--h'),
    foot,
  );
  document.body.append(p); // outside #timeline so it can sit above the chat panel

  const api = { open: false, toggle, refresh };
  function place() {
    const r = anchor.getBoundingClientRect();
    p.style.right = `${Math.max(12, innerWidth - r.right)}px`;
  }
  function toggle(on = p.hidden) {
    api.open = on; p.hidden = !on;
    anchor.classList.toggle('is-open', on);
    anchor.replaceChild(icon(on ? 'chevronUp' : 'chevronDown'), anchor.lastElementChild);
    if (on) { place(); refresh(); }
  }
  function refresh() {
    if (!api.open || !store.doc) return;
    const tl = store.doc.timeline, m = store.doc.meta;
    durNum.set(tl.duration);
    fpsNum.set(tl.fps);
    const cur = `${m.width}x${m.height}`;
    const opts = SIZES.map(([w, hh]) => `${w}x${hh}`);
    if (!opts.includes(cur)) opts.unshift(cur);
    const ratio = (w, hh) => { const g = (a, b) => (b ? g(b, a % b) : a); const d = g(w, hh); return `${w / d}:${hh / d}`; };
    changed(sizeSel, [opts, cur], () => {
      sizeSel.replaceChildren(...opts.map((o) => { const [w, hh] = o.split('x').map(Number); return h('option', { value: o }, `${w} × ${hh} · ${ratio(w, hh)}`); }));
      sizeSel.value = cur;
    });
    const sp = tl.speed ?? 'linear';
    changed(speedBtn, sp, () => {
      speedBtn.innerHTML = easeSvg(sp);
      speedBtn.append(h('span', {}, easeName(sp)), icon('chevronDown'));
    });
    const n = keys().length;
    foot.textContent = `${Math.round(tl.duration * tl.fps)} frames · ${n} key${n === 1 ? '' : 's'}`;
  }
  addEventListener('pointerdown', (e) => { if (api.open && !p.contains(e.target) && !anchor.contains(e.target)) toggle(false); }, true);
  addEventListener('keydown', (e) => { if (e.key === 'Escape' && api.open) { e.stopPropagation(); toggle(false); } }, true);
  addEventListener('resize', () => { if (api.open) place(); });
  return api;
}
