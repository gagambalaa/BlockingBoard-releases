// Primitive geometry builders. Every shape has its pivot at the bottom centre (y = 0 is the ground).
// To add a primitive: add it to PRIMITIVES in core/doc.js, then add a builder here with the same params.

import * as THREE from 'three';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
import { mannequin } from './mannequin.js';
import { blockman } from './blockman.js';
import { PERSON_HEIGHT } from '/core/doc.js';

const up = (g, y) => g.translate(0, y, 0);

export const BUILDERS = {
  box: ({ w, h, d }) => up(new THREE.BoxGeometry(w, h, d), h / 2),
  sphere: ({ r }) => up(new THREE.SphereGeometry(r, 40, 20), r),
  cylinder: ({ r, h, rTop }) => up(new THREE.CylinderGeometry(rTop ?? r, r, h, 40), h / 2),
  cone: ({ r, h }) => up(new THREE.ConeGeometry(r, h, 40), h / 2),
  pyramid: ({ w, h, d }) => new THREE.ConeGeometry(Math.SQRT1_2, 1, 4, 1).rotateY(Math.PI / 4).translate(0, 0.5, 0).scale(w, h, d),
  capsule: ({ r, h }) => up(new THREE.CapsuleGeometry(r, Math.max(0.001, h - 2 * r), 8, 24), h / 2),
  torus: ({ r, tube }) => up(new THREE.TorusGeometry(r, tube, 16, 56).rotateX(Math.PI / 2), tube),
  plane: ({ w, d }) => up(new THREE.PlaneGeometry(w, d).rotateX(-Math.PI / 2), 0.003),
  ramp({ w, h, d }) {
    const s = new THREE.Shape([new THREE.Vector2(0, 0), new THREE.Vector2(d, 0), new THREE.Vector2(d, h)]);
    return new THREE.ExtrudeGeometry(s, { depth: w, bevelEnabled: false }).rotateY(Math.PI / 2).translate(-w / 2, 0, d / 2);
  },
  stairs({ w, h, d, steps }) {
    const n = Math.max(1, Math.round(steps));
    const parts = [];
    for (let i = 0; i < n; i++) {
      const sh = (h * (i + 1)) / n, sd = d / n;
      parts.push(new THREE.BoxGeometry(w, sh, sd).translate(0, sh / 2, d / 2 - sd * (i + 0.5)));
    }
    return mergeGeometries(parts.map((g) => g.toNonIndexed()));
  },
  arch({ w, h, d, t }) {
    const ow = Math.max(0.05, w - 2 * t), r = ow / 2;
    const spring = Math.max(0, h - t - r); // height where the curve starts
    const s = new THREE.Shape();
    s.moveTo(-w / 2, 0); s.lineTo(-ow / 2, 0); s.lineTo(-ow / 2, spring);
    s.absarc(0, spring, r, Math.PI, 0, true);
    s.lineTo(ow / 2, 0); s.lineTo(w / 2, 0); s.lineTo(w / 2, h); s.lineTo(-w / 2, h); s.closePath();
    return new THREE.ExtrudeGeometry(s, { depth: d, bevelEnabled: false, curveSegments: 24 }).translate(0, 0, -d / 2);
  },
  // A person (male, female or child), h tall standing (default: the body's usual height), facing +z. Detail
  // 'high' is the jointed artist's mannequin; 'low' is a box body with a cube head and a drawn-on face, which
  // cannot bend, so a posed person (any pose but stand, or joints set) is always the mannequin.
  person({ h, body, detail, pose, joints }) {
    const H = h ?? PERSON_HEIGHT[body] ?? PERSON_HEIGHT.male;
    const posed = (pose && pose !== 'stand') || joints;
    return (detail === 'low' && !posed ? blockman(body) : mannequin(body, pose || 'stand', joints)).clone().scale(H, H, H);
  },
  // An imported GLB: the object itself is an empty mesh (it carries the transform, gizmo and moves); the
  // viewport loads the file and puts it inside (Viewport._loadModel).
  model: () => new THREE.BufferGeometry(),

  // ----- Blocking Board -----
  // A wall run: one slab per segment between points ([x, z]), with door and window openings cut out (the slab is
  // built from pieces around each opening). Corners overlap by half the thickness so runs meet cleanly.
  wall({ points, h, t, closed, openings }) {
    const pts = closed ? [...points, points[0]] : points;
    const parts = [];
    const piece = (a, b, len, x0, x1, y0, y1) => { // part of segment a→b from x0 to x1 along it, y0 to y1 high
      if (x1 - x0 < 1e-3 || y1 - y0 < 1e-3) return;
      const g = new THREE.BoxGeometry(x1 - x0, y1 - y0, t);
      g.translate((x0 + x1) / 2 - len / 2, (y0 + y1) / 2, 0);
      g.rotateY(-Math.atan2(b[1] - a[1], b[0] - a[0]));
      g.translate((a[0] + b[0]) / 2, 0, (a[1] + b[1]) / 2);
      parts.push(g.toNonIndexed());
    };
    for (let i = 0; i < pts.length - 1; i++) {
      const a = pts[i], b = pts[i + 1], len = Math.hypot(b[0] - a[0], b[1] - a[1]);
      if (len < 1e-3) continue;
      const start = -t / 2, end = len + t / 2; // overlap the corners
      const cuts = (openings || []).filter((o) => o.seg === i)
        .map((o) => ({ x0: Math.max(0, o.at - o.w / 2), x1: Math.min(len, o.at + o.w / 2), y0: o.sill, y1: Math.min(h, o.sill + o.h) }))
        .filter((c) => c.x1 > c.x0).sort((p, q) => p.x0 - q.x0);
      let x = start;
      for (const c of cuts) {
        piece(a, b, len, x, c.x0, 0, h);   // solid wall up to the opening
        piece(a, b, len, c.x0, c.x1, 0, c.y0); // under it (a window's sill)
        piece(a, b, len, c.x0, c.x1, c.y1, h); // over it (the lintel)
        x = c.x1;
      }
      piece(a, b, len, x, end, 0, h);
    }
    return parts.length ? mergeGeometries(parts) : new THREE.BufferGeometry();
  },
  // A roof: its eaves at y = 0 (the object stands at the walls' height), covering w (x) by d (z) plus the overhang.
  roof({ kind, w, d, rise, overhang, t }) {
    const o = overhang || 0, L = d + 2 * o;
    if (kind === 'flat') return up(new THREE.BoxGeometry(w + 2 * o, t || 0.2, L), (t || 0.2) / 2);
    // a slab t thick: flat underneath across the walls (y = 0, so a ceiling below shows and wall tops stay hidden
    // inside it), its overhang sloping on down past them
    const half = w / 2, slope = rise / (kind === 'shed' ? w : half), T = t || 0.2; // slope: m up per m across
    const s = new THREE.Shape();
    if (kind === 'shed') { // high side at -x
      s.moveTo(-half - o, 0); s.lineTo(half, 0); s.lineTo(half + o, -o * slope); s.lineTo(half + o, T - o * slope); s.lineTo(-half - o, rise + T + o * slope);
    } else {
      s.moveTo(-half - o, -o * slope); s.lineTo(-half, 0); s.lineTo(half, 0); s.lineTo(half + o, -o * slope);
      s.lineTo(half + o, T - o * slope); s.lineTo(0, rise + T); s.lineTo(-half - o, T - o * slope);
    }
    s.closePath();
    return new THREE.ExtrudeGeometry(s, { depth: L, bevelEnabled: false }).translate(0, 0, -L / 2);
  },
  // A picture card: a vertical plane h tall (width from the picture's aspect), standing on its bottom edge, facing +z.
  card: ({ h, aspect }) => up(new THREE.PlaneGeometry(h * (aspect || 1), h), h / 2),
  // A lamp's marker in the set (the light itself is added by the viewport).
  light: ({ kind }) => (kind === 'spot' ? new THREE.ConeGeometry(0.14, 0.28, 16).translate(0, 0.14, 0).rotateX(Math.PI) : new THREE.SphereGeometry(0.12, 16, 10)),
};

/** The panes in a wall's windows (openings with a sill): thin slabs in the middle of the wall, each with the whole
 * picture on its faces (a window picture shows once per pane). Null when the wall has no windows. */
export function wallGlass({ points, t, closed, openings }) {
  const pts = closed ? [...points, points[0]] : points;
  const panes = [];
  for (const op of openings || []) {
    if (!(op.sill > 0)) continue;
    const a = pts[op.seg], b = pts[op.seg + 1];
    if (!a || !b) continue;
    const len = Math.hypot(b[0] - a[0], b[1] - a[1]);
    const x0 = Math.max(0, op.at - op.w / 2), x1 = Math.min(len, op.at + op.w / 2);
    if (x1 <= x0) continue;
    const g = new THREE.BoxGeometry(x1 - x0, op.h, Math.min(0.03, t / 3));
    g.translate((x0 + x1) / 2 - len / 2, op.sill + op.h / 2, 0);
    g.rotateY(-Math.atan2(b[1] - a[1], b[0] - a[0]));
    g.translate((a[0] + b[0]) / 2, 0, (a[1] + b[1]) / 2);
    panes.push(g);
  }
  return panes.length ? mergeGeometries(panes) : null;
}

/**
 * World-scale texture coordinates for a textured object: each face takes the picture from the side it faces
 * (box / "triplanar" projection), so one copy of the picture covers `scale` metres whatever the object's size.
 */
export function boxUV(geometry, scale = 1) {
  const g = geometry.index ? geometry.toNonIndexed() : geometry;
  const pos = g.attributes.position, nor = g.attributes.normal;
  if (!pos || !nor) return g;
  const uv = new Float32Array(pos.count * 2);
  for (let i = 0; i < pos.count; i++) {
    const nx = Math.abs(nor.getX(i)), ny = Math.abs(nor.getY(i)), nz = Math.abs(nor.getZ(i));
    const x = pos.getX(i), y = pos.getY(i), z = pos.getZ(i);
    const [u, v] = ny >= nx && ny >= nz ? [x, z] : nx >= nz ? [z, y] : [x, y];
    uv[i * 2] = u / scale; uv[i * 2 + 1] = v / scale;
  }
  g.setAttribute('uv', new THREE.BufferAttribute(uv, 2));
  return g;
}

export function buildGeometry(type, params) {
  const b = BUILDERS[type];
  if (!b) throw new Error(`no builder for ${type}`);
  const g = b(params);
  if (!g.attributes.position) return g; // (an empty wall)
  g.computeVertexNormals();
  g.computeBoundingBox();
  return g;
}
