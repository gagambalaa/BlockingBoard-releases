// 3D files of any common kind become GLB before they go into the set: .glb as it is; .gltf, .obj, .fbx, .dae, .stl,
// .ply, .3mf and .3ds are read here (three.js loaders), their textures put inside, and written out as one .glb
// (GLTFExporter). So the scene only ever holds GLBs (models/), whatever was dropped.
// Drop the model together with its companion files - the .mtl of an .obj, the .bin of a .gltf, the pictures its
// materials name - and they are found by file name. A picture that isn't there is reported, the model still comes in.
import * as THREE from 'three';

export const MODEL_EXT = ['glb', 'gltf', 'obj', 'fbx', 'dae', 'stl', 'ply', '3mf', '3ds'];
export const MODEL_ACCEPT = MODEL_EXT.map((e) => `.${e}`).join(',') + ',.mtl,.bin,image/png,image/jpeg,image/webp,.tga,.bmp';
const ext = (n) => (String(n || '').match(/\.([a-z0-9]+)$/i)?.[1] || '').toLowerCase();
export const isModelFile = (f) => MODEL_EXT.includes(ext(f?.name));
const base = (p) => decodeURIComponent(String(p).split(/[?#]/)[0]).split(/[\\/]/).pop().toLowerCase();

/** Converts a dropped set of files into GLB files: one per model file in it.
 *  -> { files: [File .glb], notes: [text] } (notes: what was scaled, which pictures were missing, what failed). */
export async function toGlb(files) {
  files = [...files];
  const models = files.filter(isModelFile), out = [], notes = [];
  if (!models.length) return { files: out, notes };
  // companions by file name (lower case): a material that names "Textures\\Wood.JPG" finds "wood.jpg"
  const urls = new Map(), made = [];
  for (const f of files) { const u = URL.createObjectURL(f); made.push(u); urls.set(f.name.toLowerCase(), u); }
  try {
    for (const f of models) {
      if (ext(f.name) === 'glb') { out.push(f); continue; }
      try {
        const missing = new Set();
        const manager = new THREE.LoadingManager();
        watch(manager);
        manager.setURLModifier((url) => {
          if (/^(blob|data):/i.test(url)) return url;
          const hit = urls.get(base(url));
          if (!hit) missing.add(base(url));
          return hit || url;
        });
        const root = await load(f, urls.get(f.name.toLowerCase()), manager, files);
        await settled(manager);
        const { note: scaled, height } = normalise(root);
        const glb = await exportGlb(root);
        const file = new File([glb], f.name.replace(/\.[^.]+$/, '') + '.glb', { type: 'model/gltf-binary' });
        file.realHeight = Math.round(height * 1000) / 1000;   // (as it stands in the set: the scale is on a node, not in the points)
        out.push(file);
        const miss = [...missing].filter((n) => /\.(png|jpe?g|webp|tga|bmp|gif|tiff?|dds|exr|hdr)$/i.test(n));
        if (scaled) notes.push(`${f.name}: ${scaled}`);
        if (miss.length) notes.push(`${f.name}: ${miss.length} texture${miss.length === 1 ? '' : 's'} not found (${miss.slice(0, 3).join(', ')}${miss.length > 3 ? '…' : ''}) - drop them together with the model`);
        dispose(root);
      } catch (e) { console.error(e); notes.push(`${f.name} couldn't be read: ${e.message || e}`); }
    }
  } finally { made.forEach((u) => URL.revokeObjectURL(u)); }
  return { files: out, notes };
}

// every loader, loaded only when its kind of file arrives
async function load(f, url, manager, all) {
  const kind = ext(f.name), L = (p) => import(`three/addons/loaders/${p}.js`);
  if (kind === 'gltf') { const { GLTFLoader } = await L('GLTFLoader'); const g = await new GLTFLoader(manager).loadAsync(url); g.scene.animations = g.animations || []; return g.scene; }
  if (kind === 'obj') {
    const { OBJLoader } = await L('OBJLoader'), loader = new OBJLoader(manager);
    // its materials: the .mtl the file names (mtllib), else the only .mtl dropped with it
    const text = await f.text(), named = (text.match(/^mtllib\s+(.+)$/m)?.[1] || '').trim();
    const mtl = all.find((x) => x.name.toLowerCase() === base(named)) || (all.filter((x) => ext(x.name) === 'mtl').length === 1 ? all.find((x) => ext(x.name) === 'mtl') : null);
    if (mtl) {
      const { MTLLoader } = await L('MTLLoader');
      const mats = new MTLLoader(manager).parse(await mtl.text(), ''); mats.preload(); loader.setMaterials(mats);
    }
    return loader.parse(text);
  }
  if (kind === 'fbx') { const { FBXLoader } = await L('FBXLoader'); return new FBXLoader(manager).loadAsync(url); }
  if (kind === 'dae') { const { ColladaLoader } = await L('ColladaLoader'); return (await new ColladaLoader(manager).loadAsync(url)).scene; }
  if (kind === '3mf') { const { ThreeMFLoader } = await L('3MFLoader'); return new ThreeMFLoader(manager).loadAsync(url); }
  if (kind === '3ds') { const { TDSLoader } = await L('TDSLoader'); return new TDSLoader(manager).loadAsync(url); }
  if (kind === 'stl' || kind === 'ply') {
    const { STLLoader } = kind === 'stl' ? await L('STLLoader') : {}, { PLYLoader } = kind === 'ply' ? await L('PLYLoader') : {};
    const geo = await new (STLLoader || PLYLoader)(manager).loadAsync(url);
    if (!geo.getAttribute('normal')) geo.computeVertexNormals();
    const mat = new THREE.MeshStandardMaterial({ color: 0xcfcac2, roughness: 0.8, vertexColors: !!geo.getAttribute('color') });
    const g = new THREE.Group(); g.add(new THREE.Mesh(geo, mat)); return g;
  }
  throw new Error(`.${kind} files aren't supported`);
}

// textures load after the model file is parsed: wait until the manager has nothing left to fetch (20 s at most)
function watch(manager) {
  const st = { busy: false, waiters: [] };
  manager.onStart = () => { st.busy = true; };
  manager.onLoad = () => { st.busy = false; st.waiters.splice(0).forEach((f) => f()); };
  manager.onError = () => {};
  manager.__state = st;
}
function settled(manager) {
  const st = manager.__state;
  return new Promise((ok) => setTimeout(() => { if (!st.busy) return ok(); st.waiters.push(ok); setTimeout(ok, 20000); }, 80));
}

/** Into the set's terms: metres (files made in centimetres or millimetres are scaled down), standing on the floor
 *  at the middle of its footprint, materials a GLB can carry. -> { note (when it was scaled), height in metres }. */
function normalise(root) {
  root.updateMatrixWorld(true);
  root.traverse((o) => {
    if (o.isLight || o.isCamera) o.visible = false;
    if (!o.isMesh && !o.isSkinnedMesh) return;
    const conv = (m) => {
      if (!m || m.isMeshStandardMaterial || m.isMeshBasicMaterial) return m;
      const s = new THREE.MeshStandardMaterial({ name: m.name, color: m.color ? m.color.clone() : new THREE.Color(0xcccccc), map: m.map || null, normalMap: m.normalMap || null,
        alphaMap: m.alphaMap || null, emissive: m.emissive ? m.emissive.clone() : new THREE.Color(0), emissiveMap: m.emissiveMap || null,
        transparent: !!m.transparent, opacity: m.opacity ?? 1, alphaTest: m.alphaTest || 0, side: m.side, vertexColors: !!m.vertexColors,
        roughness: m.shininess != null ? Math.max(0.15, 1 - Math.min(1, m.shininess / 100)) : 0.8, metalness: 0 });
      return s;
    };
    o.material = Array.isArray(o.material) ? o.material.map(conv) : conv(o.material);
    // a picture that never arrived can't be written into the file: the material keeps its colour instead
    for (const m of [].concat(o.material || [])) for (const k of ['map', 'normalMap', 'alphaMap', 'emissiveMap', 'roughnessMap', 'metalnessMap', 'aoMap', 'bumpMap']) {
      const t = m[k]; if (!t) continue;
      const im = t.image; if (!im || !(im.width || im.videoWidth || im.data)) m[k] = null;
    }
  });
  const box = new THREE.Box3().setFromObject(root);
  if (box.isEmpty()) throw new Error('nothing to show in it');
  const size = box.getSize(new THREE.Vector3()), big = Math.max(size.x, size.y, size.z);
  let k = 1, note = '';
  if (big > 2000) { k = 0.001; note = 'scaled from millimetres to metres'; }
  else if (big > 60) { k = 0.01; note = 'scaled from centimetres to metres'; }
  const c = box.getCenter(new THREE.Vector3());
  // (a holder carries the scale and the move, so skinned and animated models keep working inside it)
  const holder = new THREE.Group(); holder.name = root.name || 'model';
  root.parent?.remove(root);
  holder.add(root); holder.animations = root.animations || [];
  root.position.sub(new THREE.Vector3(c.x, box.min.y, c.z));
  holder.scale.setScalar(k);
  holder.updateMatrixWorld(true);
  root.userData.__holder = holder;
  return { note, height: size.y * k };
}

async function exportGlb(root) {
  const { GLTFExporter } = await import('three/addons/exporters/GLTFExporter.js');
  const holder = root.userData.__holder || root; delete root.userData.__holder;
  const scene = new THREE.Scene(); scene.add(holder);
  const buf = await new GLTFExporter().parseAsync(scene, { binary: true, animations: holder.animations || [], onlyVisible: true, maxTextureSize: 4096 });
  scene.remove(holder);
  return buf;
}

function dispose(root) {
  root.traverse((o) => {
    o.geometry?.dispose?.();
    for (const m of [].concat(o.material || [])) { for (const k of ['map', 'normalMap', 'alphaMap', 'emissiveMap']) m[k]?.dispose?.(); m.dispose?.(); }
  });
}
