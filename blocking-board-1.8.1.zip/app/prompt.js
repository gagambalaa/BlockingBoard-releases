// Chat sidebar. Prompts go to the bridge server's inbox; the user's agent (Claude Code or Codex)
// picks them up with `canvas wait` (or the Claude Code Stop hook) and answers with `canvas say`.
// The panel docks on the right; the sidebar toggle in the top-right menu opens and closes it.

import { h, icon, button } from './ui/kit.js';
import { describe } from '/core/doc.js';
import { store } from './store.js';
import { askCard } from './ask.js';
import { progressCard } from './progress.js';
import { isGlb, uploadModel } from './models.js';

const OPEN_KEY = 'cc-chat-open';

export function mountPrompt(root, { viewport, corner, beside }) {
  // ---------- header: agent status, and the selection sent with your message ----------
  const dot = h('span.cc-dot');
  const statusText = h('span.chat-status-text');
  const selEl = h('span.cc-mono.chat-sel');
  const newBtn = button({ icon: 'compose', kind: 'ghost', title: 'New chat: clear this conversation', onClick: () => newChat() });
  newBtn.classList.add('chat-new');
  const pastBtn = button({ icon: 'history', kind: 'ghost', title: 'Past chats', onClick: () => (view === 'current' ? showList() : showCurrent()) });
  pastBtn.classList.add('chat-past-btn');
  const head = h('div.chat-head', {}, dot, statusText, h('span.cc-spacer'), selEl, pastBtn, newBtn);

  // ---------- thread ----------
  const thread = h('div.chat-thread', { role: 'log', 'aria-live': 'polite' });
  // The empty thread follows the agent: how to connect it while nobody is listening, and what to ask
  // once it is. It re-renders on every status change, so it never tells a listening agent to listen.
  const empty = h('div.chat-empty');
  const STARTERS = [
    'A rainy street with a woman at a bus stop, slow push-in over 5 seconds',
    'Low orbit around a car in an empty car park at dusk',
    'Two people talking at a cafe table, over-the-shoulder, then a cut to the reverse',
  ];
  let emptyState = '';
  // A command the user copies into their agent: click to copy.
  const cmd = (text) => h('code.chat-cmd', { title: 'Click to copy', onClick: (e) => {
    navigator.clipboard?.writeText(text).then(() => { e.target.dataset.copied = ''; setTimeout(() => delete e.target.dataset.copied, 1200); }, () => {});
  } }, text);
  const say = (text) => h('b', {}, `“${text}”`);
  // What to do next depends on how the canvas was started (the server reports it) and whether an agent
  // was listening and went away.
  function offState({ launch, listenStale }) {
    const { by, plugin, checkout, dir } = launch || {};
    const inFolder = dir ? cmd(`cd ${dir} && claude "listen to the canvas"`) : null;
    const claudeStep = plugin
      ? h('li', {}, 'In Claude Code, run ', cmd('/blockout:start'), '.')
      : checkout && inFolder ? h('li', {}, 'Claude Code: in a terminal, run ', inFolder)
      : h('li', {}, 'In Claude Code, add the plugin with ', cmd('/plugin marketplace add shrimbly/blockout'), ', install it, then run ', cmd('/blockout:start'), '.');
    const codexStep = h('li', {}, 'Codex: start it in ', dir ? h('code', {}, dir) : 'this folder', ' and say ', say('listen to the canvas'), '.');
    if (listenStale) return [
      h('div.chat-empty-title', {}, 'Your agent stopped listening'),
      h('p', {}, 'The session that was listening has ended or gone quiet. To reconnect:'),
      h('ol.chat-steps', {}, by === 'codex' ? h('li', {}, 'In Codex, say ', say('listen to the canvas'), '.') : claudeStep),
    ];
    if (by === 'claude') return [
      h('div.chat-empty-title', {}, 'One step left'),
      h('p', {}, 'Claude Code started the canvas but isn’t listening to it yet. In that session:'),
      h('ol.chat-steps', {}, plugin ? h('li', {}, 'Run ', cmd('/blockout:start'), '.') : h('li', {}, 'Say ', say('listen to the canvas'), '.')),
    ];
    if (by === 'codex') return [
      h('div.chat-empty-title', {}, 'One step left'),
      h('p', {}, 'Codex started the canvas but isn’t listening to it yet. In that session:'),
      h('ol.chat-steps', {}, h('li', {}, 'Say ', say('listen to the canvas'), '.')),
    ];
    return [
      h('div.chat-empty-title', {}, 'Connect your agent'),
      h('p', {}, launch ? 'The canvas is running. Your agent builds the scene and the camera move from what you write here, once it is listening:' : 'Your agent builds the scene and the camera move from what you write here, once it is listening:'),
      h('ol.chat-steps', {}, claudeStep, codexStep),
    ];
  }
  function renderEmpty() {
    const state = agentState();
    const { launch, listenStale } = store.state;
    const key = state === 'off' ? `off:${listenStale}:${JSON.stringify(launch)}` : state;
    if (key === emptyState) return;
    emptyState = key;
    const starters = h('div.chat-starters', {}, ...STARTERS.map((text) =>
      h('button.chat-starter', { type: 'button', onClick: () => { input.value = text; input.dispatchEvent(new Event('input')); input.focus(); } }, text)));
    const off = [...offState({ launch, listenStale }), h('p.chat-empty-hint', {}, 'You can write now: messages wait here until your agent connects.')];
    const on = [
      h('div.chat-empty-title', {}, state === 'working' ? 'Your agent is busy' : 'Your agent is listening'),
      h('p', {}, state === 'working'
        ? 'It will pick up what you write here as soon as it finishes.'
        : 'Describe a scene and a camera move. Your selection, the playhead and the camera go with each message.'),
      h('div.chat-empty-label', {}, 'Try'),
      starters,
    ];
    empty.replaceChildren(...(state === 'off' ? off : on));
  }

  // ---------- composer ----------
  const input = h('textarea.chat-input', { rows: 1, placeholder: 'Ask your agent…', spellcheck: false, 'aria-label': 'Message your agent' });
  const send = h('button.cc-btn.cc-btn--primary.cc-btn--icon.chat-send', { type: 'button', title: 'Send (Enter) · new line (Shift+Enter)', disabled: true }, icon('send'));
  const fileInput = h('input', { type: 'file', accept: 'image/png,image/jpeg,image/webp,image/gif,.glb,model/gltf-binary', multiple: true, hidden: true });
  const attachBtn = h('button.cc-btn.cc-btn--ghost.cc-btn--icon.chat-attach', { type: 'button', title: 'Add images or .glb models (or paste / drop them)' }, icon('image'));
  const tray = h('div.chat-tray', { hidden: true });
  // A note above the composer when a button elsewhere started a request here (store.emit('compose', { text, hint })).
  const hint = h('div.chat-hint', { hidden: true, role: 'note' });
  const composer = h('div.chat-composer', {}, hint, h('div.chat-input-row', {}, h('div.chat-input-col', {}, tray, input), attachBtn, send), fileInput);

  // Past chats: "New chat" archives the conversation on the server; this view lists them and reads one back.
  const past = h('div.chat-past', { hidden: true });

  const panel = h('section.cc-panel.chat', { 'aria-label': 'Chat with your agent' }, head, thread, past, composer);
  root.append(panel);

  // one sidebar toggle in the top-right menu: outline when closed, filled when open.
  // While closed, its badge shows the agent: spinner = working, orange dot = new reply, hollow ring = not listening.
  const badge = h('span.chat-badge', { hidden: true });
  const toggleBtn = button({ icon: 'sidebar', kind: 'ghost', title: 'Show chat (/)', onClick: () => { setOpen(!open); if (open) input.focus(); } });
  toggleBtn.classList.add('chat-toggle');
  toggleBtn.append(badge);
  corner.append(toggleBtn);
  let unread = false;
  let peek = null;

  let open = true;
  try { open = localStorage.getItem(OPEN_KEY) !== '0'; } catch {}
  function setOpen(v, { remember = true } = {}) {
    open = v;
    if (remember) try { localStorage.setItem(OPEN_KEY, v ? '1' : '0'); } catch {}
    panel.hidden = !v;
    document.body.classList.toggle('chat-open', v);
    if (v) { unread = false; hidePeek(); scrollToEnd(); }
    toggleBtn.replaceChild(icon(v ? 'sidebarOn' : 'sidebar'), toggleBtn.firstElementChild);
    toggleBtn.classList.toggle('is-open', v);
    toggleBtn.title = v ? 'Hide chat' : 'Show chat (/)';
    toggleBtn.setAttribute('aria-expanded', v);
    store.set({ chat: v });
    refreshBadge();
  }

  // ---------- state ----------
  const prompts = new Map(); // id -> prompt
  const items = new Map();   // prompt id -> element
  const asks = new Map();    // question card id -> card (see ask.js)
  const jobs = new Map();    // progress card id -> card (see progress.js)

  function context() {
    const sel = store.state.selection && store.object(store.state.selection);
    return {
      selection: sel ? [describe(sel)] : [],
      time: +store.state.time.toFixed(3),
      duration: store.doc?.timeline.duration,
      shot: store.doc?.shots?.length > 1 ? (() => { const i = store.doc.shots.findIndex((x) => x.id === store.doc.shot); return `${store.doc.shot} (${i + 1} of ${store.doc.shots.length})`; })() : undefined,
      view: store.state.view,
      key: store.state.key || undefined,
      camera: viewport.getPose(),
    };
  }

  // ---------- attachments: uploaded as soon as they are added, sent with the next message ----------
  // Images go to the chat's uploads; .glb models go to the scene's models/ but are not added to the scene:
  // the agent gets their paths and adds one only if the message asks (dropped on the canvas, a model is added).
  let attachments = []; // { id, kind: 'image'|'model', preview?, name?, file?, pending, error? }
  const MAX_SIDE = 2000;
  async function toDataUrl(blob) {
    const url = URL.createObjectURL(blob);
    try {
      const img = await new Promise((ok, bad) => { const i = new Image(); i.onload = () => ok(i); i.onerror = bad; i.src = url; });
      const scale = Math.min(1, MAX_SIDE / Math.max(img.naturalWidth, img.naturalHeight));
      if (scale === 1 && /^image\/(png|jpeg|webp|gif)$/.test(blob.type)) {
        return await new Promise((ok) => { const r = new FileReader(); r.onload = () => ok(r.result); r.readAsDataURL(blob); });
      }
      const c = document.createElement('canvas');
      c.width = Math.round(img.naturalWidth * scale); c.height = Math.round(img.naturalHeight * scale);
      c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
      return c.toDataURL(blob.type === 'image/jpeg' ? 'image/jpeg' : 'image/png', 0.9);
    } finally { URL.revokeObjectURL(url); }
  }
  async function uploadImage(f) {
    const res = await store.post('/api/chat/image', { data: await toDataUrl(f), name: f.name || 'pasted' });
    if (!res.ok) throw new Error(res.error || 'upload failed');
    return res.file;
  }
  async function addFiles(files) {
    const ok = [...files].filter((x) => x.type?.startsWith('image/') || isGlb(x)).slice(0, 8 - attachments.length);
    for (const f of ok) {
      const model = isGlb(f);
      const a = model ? { id: Math.random().toString(36).slice(2), kind: 'model', name: f.name, pending: true }
        : { id: Math.random().toString(36).slice(2), kind: 'image', preview: URL.createObjectURL(f), pending: true };
      attachments.push(a); renderTray();
      try { a.file = model ? (await uploadModel(f)).file : await uploadImage(f); } catch (e) { a.error = e.message || true; console.warn('upload failed', e); }
      a.pending = false; renderTray();
    }
  }
  function removeAttachment(id) {
    const a = attachments.find((x) => x.id === id);
    if (a?.preview) URL.revokeObjectURL(a.preview);
    attachments = attachments.filter((x) => x.id !== id); renderTray();
  }
  const modelChip = (name) => h('span.chat-model-chip', { title: `${name}: sent to your agent, not added to the scene` }, icon('cube'), h('span.chat-model-name', {}, name));
  function renderTray() {
    tray.hidden = !attachments.length;
    tray.replaceChildren(...attachments.map((a) => {
      const x = h('button.chat-thumb-x', { type: 'button', title: 'Remove', 'aria-label': a.kind === 'model' ? 'Remove model' : 'Remove image', onClick: () => removeAttachment(a.id) }, icon('close'));
      const cls = `${a.pending ? '.is-pending' : ''}${a.error ? '.is-error' : ''}`;
      const title = a.error ? `Upload failed${typeof a.error === 'string' ? `: ${a.error}` : ''}` : '';
      if (a.kind === 'model') return h(`div.chat-thumb.chat-thumb--model${cls}`, { title: title || `${a.name}: goes to your agent with this message, not added to the scene` },
        icon('cube'), h('span.chat-thumb-name', {}, a.name.replace(/\.glb$/i, '')), a.pending ? h('span.cc-spin') : null, x);
      return h(`div.chat-thumb${cls}`, { title }, h('img', { src: a.preview, alt: '' }), a.pending ? h('span.cc-spin') : null, x);
    }));
    autosize();
  }
  attachBtn.addEventListener('click', () => fileInput.click());
  fileInput.addEventListener('change', () => { addFiles(fileInput.files); fileInput.value = ''; input.focus(); });
  input.addEventListener('paste', (e) => {
    const files = [...(e.clipboardData?.files || [])].filter((f) => f.type.startsWith('image/'));
    if (files.length) { e.preventDefault(); addFiles(files); }
  });
  panel.addEventListener('dragover', (e) => { if ([...(e.dataTransfer?.types || [])].includes('Files')) { e.preventDefault(); panel.classList.add('is-drop'); } });
  panel.addEventListener('dragleave', (e) => { if (!panel.contains(e.relatedTarget)) panel.classList.remove('is-drop'); });
  panel.addEventListener('drop', (e) => { if (!e.dataTransfer?.files?.length) return; e.preventDefault(); panel.classList.remove('is-drop'); addFiles(e.dataTransfer.files); input.focus(); });

  const readyFiles = () => attachments.filter((a) => a.file);
  async function submit() {
    const text = input.value.trim();
    if (attachments.some((a) => a.pending)) return;
    const ready = readyFiles();
    if (!text && !ready.length) return;
    if (view !== 'current') showCurrent();
    const sent = attachments;
    input.value = ''; attachments = []; renderTray();
    hint.hidden = true;
    const res = await store.post('/api/prompt', {
      text, context: context(),
      images: ready.filter((a) => a.kind !== 'model').map((a) => a.file),
      models: ready.filter((a) => a.kind === 'model').map((a) => ({ file: a.file, name: a.name })),
    });
    if (!res.ok) { input.value = text; attachments = sent; renderTray(); return; }
    for (const a of sent) if (a.preview) URL.revokeObjectURL(a.preview);
  }
  // Start a request for the user: open the chat, put the text in the composer (in front of a draft) and show
  // what to add. Nothing is sent until they press send.
  store.on('compose', ({ text = '', hint: note = '' } = {}) => {
    if (!open) setOpen(true);
    if (view !== 'current') showCurrent();
    if (!input.value.startsWith(text.trim())) input.value = text + input.value;
    hint.textContent = note; hint.hidden = !note;
    input.dispatchEvent(new Event('input'));
    input.focus();
    input.setSelectionRange(input.value.length, input.value.length);
  });
  function autosize() {
    const MAX = 160; // about 8 lines, then it scrolls
    input.style.height = 'auto';
    const h_ = input.scrollHeight;
    input.style.height = `${Math.min(MAX, h_)}px`;
    input.classList.toggle('is-capped', h_ > MAX);
    send.disabled = attachments.some((a) => a.pending) || (!input.value.trim() && !readyFiles().length);
  }
  input.addEventListener('input', autosize);
  input.addEventListener('input', () => { if (!input.value) hint.hidden = true; });
  new ResizeObserver(() => { if (input.value) autosize(); }).observe(composer); // rewrap when the panel width changes
  input.addEventListener('keydown', (e) => {
    e.stopPropagation();
    if (e.key === 'Enter' && !e.shiftKey && !e.isComposing) { e.preventDefault(); submit(); }
    if (e.key === 'Escape') input.blur();
  });
  send.addEventListener('click', submit);

  const nearEnd = () => thread.scrollHeight - thread.scrollTop - thread.clientHeight < 60;
  const scrollToEnd = () => requestAnimationFrame(() => { thread.scrollTop = thread.scrollHeight; });
  const time = (at) => new Date(at).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });

  function ctxLine(c = {}) {
    const bits = [];
    if (c.selection?.length) bits.push(`@${c.selection[0].split(' ')[0]}`);
    if (c.time != null) bits.push(`${Number(c.time).toFixed(1)}s`);
    if (c.view) bits.push(c.view);
    return bits.join(' · ');
  }

  function statusEl(p) {
    const busy = p.status === 'taken' && (store.state.working || store.state.agent);
    if (p.status === 'done') return null; // done shows nothing
    if (p.status === 'pending') return h('span.chat-meta', {}, icon('clock'), 'queued');
    if (busy) return h('span.chat-meta.is-busy', {}, h('span.cc-spin'), 'working');
    return h('span.chat-meta.is-stale', {}, 'no reply yet');
  }

  // One of your messages: its images, its text and (in the open chat) its status.
  function fillPrompt(el, p, st = null) {
    el.title = [p.at ? time(p.at) : '', ctxLine(p.context)].filter(Boolean).join(' · ');
    const imgs = (p.images || []).map((im) => h('a.chat-img', { href: im.url, target: '_blank', rel: 'noopener', title: 'Open image' }, h('img', { src: im.url, alt: '', loading: 'lazy' })));
    const models = (p.models || []).map((m) => modelChip(m.name || m.file));
    el.replaceChildren(
      ...(imgs.length ? [h('div.chat-imgs', {}, ...imgs)] : []),
      ...(models.length ? [h('div.chat-models', {}, ...models)] : []),
      ...(p.text ? [h('div.chat-bubble', {}, p.text)] : []),
      ...(st ? [h('div.chat-foot', {}, st)] : []));
    return el;
  }
  const newCard = (m, answered) => askCard(m, { answered, upload: uploadImage, post: (route, body) => store.post(route, body), context, onChange: () => { if (nearEnd()) scrollToEnd(); } });
  function agentEl(m, answered) {
    if (m.kind === 'progress' && m.progress) return h('div.chat-msg.chat-msg--agent.chat-msg--ask', {}, progressCard(m.progress.state === 'running' ? { ...m, progress: { ...m.progress, state: 'failed', note: 'Not finished', endedAt: m.at } } : m).el);
    if (m.kind === 'ask' && m.ask) {
      // in a past chat a card that was never answered shows as closed
      const card = newCard(m, answered || { cancelled: true });
      return h('div.chat-msg.chat-msg--agent.chat-msg--ask', {}, card.el);
    }
    const cls = ['chat-msg', 'chat-msg--agent'];
    if (m.kind === 'error') cls.push('is-error');
    if (m.kind === 'working') cls.push('is-working');
    return h(`div.${cls.join('.')}`, { title: `${m.from === 'system' ? 'Canvas' : 'Agent'} · ${time(m.at)}` },
      ...(m.text ? [h('div.chat-text', {}, m.text)] : []),
      ...(m.files?.length ? [h('div.chat-files', {}, ...m.files.map(fileEl))] : []));
  }
  // "Beside shot": the video in the viewport next to the shot frame, following the timeline (beside.js).
  function besideBtn(f, v) {
    const b = button({ icon: 'columns', label: 'Beside shot', kind: 'ghost', title: 'Show this video beside the shot frame, in step with the timeline', onClick: () => { v.pause(); beside.show(f); } });
    b.classList.add('chat-beside');
    return b;
  }
  // The chat hides while a video is beside the shot and comes back when it closes (not remembered across reloads).
  store.on('state', (c) => { if (c.chat && store.state.chat !== open) setOpen(store.state.chat, { remember: false }); });
  // A file on a reply: a video plays in place, an image opens in a new tab.
  function fileEl(f) {
    if (f.type === 'video') {
      const v = h('video', { src: f.url, controls: true, loop: true, playsInline: true, preload: 'metadata', 'aria-label': f.name });
      return h('figure.chat-video', {}, v,
        h('figcaption', {}, h('a', { href: f.url, target: '_blank', rel: 'noopener', title: f.path || 'Open video' }, f.name),
          ...(beside ? [besideBtn(f, v)] : [])));
    }
    return h('a.chat-img', { href: f.url, target: '_blank', rel: 'noopener', title: f.name }, h('img', { src: f.url, alt: f.name, loading: 'lazy' }));
  }
  const peekText = (m) => m.kind === 'ask' ? `Has a question: ${m.ask?.questions?.[0]?.q || m.text}` : m.text || (m.files?.length ? `Sent ${m.files.length === 1 ? `a ${m.files[0].type === 'video' ? 'video' : 'file'}` : `${m.files.length} files`}` : '');
  // Prompts and replies in the order they happened.
  const merge = (ps = [], ms = []) => [...ps.map((p) => ({ at: p.at, p })), ...ms.map((m) => ({ at: m.at, m }))].sort((a, b) => a.at - b.at);

  function renderPrompt(p) {
    // the answers to a question card show in the card, not as a message of yours
    if (p.ask && asks.has(p.ask)) { if (!items.has(p.id)) { items.set(p.id, asks.get(p.ask).el); asks.get(p.ask).done(p); } return; }
    let el = items.get(p.id);
    const stick = nearEnd();
    if (!el) {
      el = h('div.chat-msg.chat-msg--user');
      items.set(p.id, el);
      thread.append(el);
    }
    el.dataset.status = p.status;
    fillPrompt(el, p, statusEl(p));
    empty.remove();
    if (stick) scrollToEnd();
  }

  function hidePeek() { if (peek) { clearTimeout(peek.timer); peek.el.remove(); peek = null; } }
  function showPeek(m) {
    hidePeek();
    const el = h('div.cc-panel.chat-peek', { role: 'status', title: 'Open chat', onClick: () => { setOpen(true); input.focus(); } },
      h('div.chat-peek-who', {}, h('span.cc-dot.cc-dot--ok'), m.from === 'system' ? 'Canvas' : 'Agent replied'),
      h('div.chat-peek-text', {}, peekText(m)));
    document.body.append(el);
    const timer = setTimeout(() => { if (!peek) return; el.classList.add('is-leaving'); peek.timer = setTimeout(hidePeek, 450); }, 4000);
    peek = { el, timer };
    el.addEventListener('pointerenter', () => { clearTimeout(peek?.timer); el.classList.remove('is-leaving'); });
    el.addEventListener('pointerleave', () => { if (peek) peek.timer = setTimeout(hidePeek, 1500); });
  }

  function renderMessage(m, live = true) {
    if (m.kind === 'progress' && m.progress) {
      // one card per job: later messages for the same job update it where it stands
      const had = jobs.get(m.progress.id);
      if (had) { had.update(m); return; }
      const stickNow = nearEnd();
      const card = progressCard(m);
      jobs.set(m.progress.id, card);
      thread.append(h('div.chat-msg.chat-msg--agent.chat-msg--ask', {}, card.el));
      empty.remove();
      if (!open && live) { unread = true; refreshBadge(); }
      if (stickNow) scrollToEnd();
      return;
    }
    const stick = nearEnd();
    if (m.kind === 'ask' && m.ask) {
      const card = newCard(m, null);
      asks.set(m.ask.id, card);
      thread.append(h('div.chat-msg.chat-msg--agent.chat-msg--ask', {}, card.el));
      // a question needs an answer: bring the chat up rather than leave it behind a badge
      if (live && !open) setOpen(true);
      if (live) requestAnimationFrame(() => card.focus());
      empty.remove();
      scrollToEnd();
      return;
    }
    thread.append(agentEl(m));
    empty.remove();
    if (!open && live) {
      unread = true; refreshBadge();
      if (m.kind !== 'working') showPeek(m);
    }
    if (stick) scrollToEnd();
  }

  store.on('prompt', (p) => { prompts.set(p.id, p); renderPrompt(p); });
  store.on('say', (m) => renderMessage(m));
  store.on('history', ({ prompts: ps = [], messages: ms = [] }) => {
    thread.replaceChildren(); items.clear(); prompts.clear(); asks.clear(); jobs.clear();
    for (const p of ps) prompts.set(p.id, p);
    const all = merge(ps, ms).slice(-200);
    if (!all.length) thread.append(empty);
    for (const x of all) x.p ? renderPrompt(x.p) : renderMessage(x.m, false);
    unread = false; refreshBadge();
    scrollToEnd();
  });

  // ---------- past chats ----------
  let view = 'current'; // current | list | chat
  function setView(v) {
    view = v;
    thread.hidden = v !== 'current';
    past.hidden = v === 'current';
    pastBtn.classList.toggle('is-active', v !== 'current');
    pastBtn.title = v === 'current' ? 'Past chats' : 'Back to the current chat';
  }
  function showCurrent() { setView('current'); scrollToEnd(); }
  const when = (at) => {
    const d = new Date(at), today = new Date();
    if (d.toDateString() === today.toDateString()) return `Today ${time(at)}`;
    const opts = d.getFullYear() === today.getFullYear() ? { month: 'short', day: 'numeric' } : { year: 'numeric', month: 'short', day: 'numeric' };
    return `${d.toLocaleDateString([], opts)}, ${time(at)}`;
  };
  const pastBar = (title, onBack, backLabel) => h('div.chat-past-bar', {},
    h('button.cc-btn.cc-btn--ghost.chat-past-back', { type: 'button', onClick: onBack }, icon('chevronLeft'), backLabel),
    h('span.chat-past-title', { title }, title));
  async function showList() {
    setView('list');
    past.replaceChildren(pastBar('Past chats', showCurrent, 'Current chat'), h('div.chat-past-note', {}, h('span.cc-spin')));
    let chats = [];
    try { chats = (await (await fetch('/api/chats')).json()).chats || []; } catch (e) { console.warn('past chats failed', e); }
    if (view !== 'list') return;
    past.replaceChildren(pastBar('Past chats', showCurrent, 'Current chat'), chats.length
      ? h('div.chat-past-list', { role: 'list' }, ...chats.map((c) => h('button.chat-past-item', { type: 'button', role: 'listitem', onClick: () => showChat(c.id) },
        h('span.chat-past-item-title', {}, c.title),
        h('span.chat-past-item-meta', {}, `${when(c.endedAt)} · ${c.count} message${c.count === 1 ? '' : 's'}`))))
      : h('div.chat-past-note', {}, 'No past chats yet. When you start a new chat, this one is kept here.'));
  }
  async function showChat(id) {
    setView('chat');
    let chat;
    try { chat = (await (await fetch(`/api/chats/get?id=${encodeURIComponent(id)}`)).json()).chat; } catch (e) { console.warn('past chat failed', e); }
    if (view !== 'chat') return;
    if (!chat) { past.replaceChildren(pastBar('Past chats', showList, 'All chats'), h('div.chat-past-note', {}, 'This chat could not be loaded.')); return; }
    const log = h('div.chat-past-log', { role: 'log' },
      h('div.chat-past-date', {}, when(chat.startedAt)),
      ...merge(chat.prompts, chat.messages.filter((m, i, all) => m.kind !== 'progress' || !all.slice(i + 1).some((n) => n.progress?.id === m.progress?.id))).filter((x) => !(x.p?.ask && chat.messages.some((m) => m.ask?.id === x.p.ask))).map((x) => x.p ? fillPrompt(h('div.chat-msg.chat-msg--user'), x.p) : agentEl(x.m, chat.prompts.find((p) => p.ask && p.ask === x.m.ask?.id))));
    past.replaceChildren(pastBar(chat.title, showList, 'All chats'), log);
    past.scrollTop = 0;
  }

  async function newChat() {
    showCurrent();
    try {
      const r = await fetch('/api/chat/new', { method: 'POST' });
      if (!r.ok) throw new Error(`HTTP ${r.status}`);
      input.focus();
    } catch (e) { console.warn('new chat failed', e); }
  }

  // One reading of the agent for the header, the badge and the empty thread. Listen mode on counts as
  // listening even between waits (for example while the agent finishes the turn that turned it on):
  // its hooks deliver the next prompt as soon as that turn ends.
  function agentState() {
    const { agent, working, listen } = store.state;
    return agent ? 'listening' : working ? 'working' : listen ? 'listening' : 'off';
  }

  function refresh() {
    const { agent } = store.state;
    const state = agentState();
    // three shapes, not just colours: solid dot, spinner, hollow ring
    dot.className = state === 'listening' ? 'cc-dot cc-dot--ok' : state === 'working' ? 'cc-spin' : 'chat-ring';
    statusText.textContent = { listening: 'Listening', working: 'Working…', off: 'Not listening' }[state];
    refreshBadge();
    head.title = agent ? 'Your agent is waiting for prompts from this canvas.'
      : state === 'listening' ? 'Your agent is in listen mode. It picks up prompts from this canvas as soon as its current turn ends.'
      : state === 'working' ? 'Your agent is working on a prompt. New prompts queue until it is done.'
      : store.state.listenStale ? 'Your agent stopped listening. Prompts queue until it reconnects.'
      : 'Prompts queue until your agent listens. Run /blockout:start in Claude Code, or ask your agent to "listen to the canvas".';
    renderEmpty();
    const sel = store.state.selection;
    selEl.textContent = sel ? `@${sel}` : '';
    selEl.title = 'The selected object, the playhead and the camera are sent with your message';
  }
  store.on('state', (c) => {
    if (c.agent || c.working || c.listen || c.listenStale || c.launch || c.selection || c.time || c.view) refresh();
    if (c.agent || c.working) for (const p of prompts.values()) if (p.status === 'taken') renderPrompt(p);
  });
  function refreshBadge() {
    const s = agentState();
    const state = open ? null : s === 'working' ? 'working' : unread ? 'unread' : s === 'off' ? 'off' : null;
    badge.hidden = !state;
    badge.className = `chat-badge${state ? ` is-${state}` : ''}`;
    toggleBtn.classList.toggle('is-off', !open && s === 'off');
    const why = { working: ' · agent working', unread: ' · new reply', off: ' · agent not listening' }[state] || '';
    toggleBtn.title = open ? 'Hide chat' : `Show chat (/)${why}`;
  }

  thread.append(empty);
  refresh();
  setOpen(open);

  return { focus: () => { if (!open) setOpen(true); input.focus(); }, input, setOpen, toggleBtn };
}
