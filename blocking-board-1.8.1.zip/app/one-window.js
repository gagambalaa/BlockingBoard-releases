/* One KAI app window and one KAI browser tab at a time (the same for each plugin's page - plugins carry a copy).
   The newest one wins: opening KAI again takes over, and the older window of the same kind shows "Open in another
   window" (its work stopped, nothing left running) with a button to use it there instead. Kind: "app" = KAI's own
   window (no address bar; a plugin shown inside it gets ?kaiwin=app from KAI), "browser" = a normal tab.
   Loaded first, before anything else on the page. */
(function(){
  if (!window.BroadcastChannel) return;
  const q = new URLSearchParams(location.search);
  let kind = q.get("kaiwin");
  if (!kind) try { kind = sessionStorage.getItem("kz.win"); } catch {}
  if (!kind) kind = window.top === window && (window.toolbar?.visible === false || matchMedia("(display-mode: standalone)").matches) ? "app" : "browser";
  if (kind !== "app") kind = "browser";
  try { sessionStorage.setItem("kz.win", kind); } catch {}
  window.KZ_WIN = kind;

  if (q.has("kai_closed")){   // the page left behind: nothing of it runs
    window.stop();
    const back = () => { const u = new URL(location.href); u.searchParams.delete("kai_closed"); location.replace(u.href); };
    const paint = () => {
      document.title = (document.title || "KAI") + " (open elsewhere)";
      document.documentElement.innerHTML = `<head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${document.title}</title></head>
<body style="margin:0;font:15px system-ui,sans-serif;background:#111;color:#eee;display:grid;place-items:center;min-height:100vh;text-align:center">
<div><h2 style="font-weight:600;margin:0 0 8px">Open in another window</h2>
<p style="color:#999;margin:0 0 18px">Only one ${kind === "app" ? "app window" : "browser tab"} at a time.</p>
<button id="kzUseHere" style="font:inherit;padding:9px 18px;border-radius:8px;border:0;background:#7c5cff;color:#fff;cursor:pointer">Use here</button></div></body>`;
      document.getElementById("kzUseHere").onclick = back;
    };
    document.readyState === "loading" ? setTimeout(paint, 0) : paint();
    return;
  }

  const bc = new BroadcastChannel("kai-one-window"), me = Date.now() + Math.random();
  bc.onmessage = e => {
    const m = e.data || {};
    if (m.kind !== kind || m.t === me || m.t < me) return;   // (an older page's "hello" never closes a newer one)
    bc.close();
    const u = new URL(location.href); u.searchParams.set("kai_closed", "1");
    location.replace(u.href);
  };
  bc.postMessage({kind, t: me});
})();
