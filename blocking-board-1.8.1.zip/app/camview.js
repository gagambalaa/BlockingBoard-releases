// Cam view: what the shot camera sees, always on screen beside the main view (as on the first Blocking Board, where
// the floor plan and the camera sat side by side). It shows while the main view is Plan or 3D; with the main view on
// Cam it steps aside (the main view is the camera then). Drawn live by its own renderer: scrubbing, playing and
// moving things all show here at once. The Cam button in the top bar hides it (remembered per PC).
//
// Blocking Board: dragging in the picture moves the shot camera, as on the first Blocking Board. Look (the default)
// pans and tilts where it stands; Orbit circles the aim person (Aim: auto = the nearest person in frame) keeping
// them centred; Move slides it sideways and up / down without turning. Scrolling dollies in or out; right-drag always
// moves, Shift-drag always orbits. Letting go keys the camera at the playhead (the key there, or a new one). Lock
// (per shot, saved: shots[].lock) keeps the camera from being changed at all.
import * as THREE from 'three';
import { h, icon, toast, segmented, select } from './ui/kit.js';
import { store } from './store.js';
import { shotList, objectHeight } from '/core/doc.js';
import { fovToLens, sampleCamera, sampleObject } from '/core/curves.js';

const DEG = Math.PI / 180, UP = new THREE.Vector3(0, 1, 0);
const read = (k) => { try { return localStorage.getItem(k); } catch { return null; } };
const write = (k, v) => { try { localStorage.setItem(k, v); } catch {} };

export function mountCamView(hud, { viewport }) {
  let on = localStorage.getItem('bb.cam') !== 'off';
  const btn = h('button.cc-btn.st-add', { type: 'button', title: 'Show or hide the Cam view (what the shot camera sees)', onClick: () => toggle() }, icon('camera'), 'Cam');
  hud.append(btn);
  const title = h('span.cv-title');
  const big = h('button.cc-btn.cc-btn--ghost', { type: 'button', title: 'Make the camera the main view (C)', onClick: () => store.set({ view: 'shot' }) }, icon('frame'));
  const hide = h('button.cc-btn.cc-btn--ghost', { type: 'button', title: 'Hide the Cam view', onClick: () => toggle(false) }, icon('close'));
  // the film's frame - every scene's camera, and the frames KAI shows on its cards (one for the whole project)
  const fmt = h('select.cc-select.cv-fmt', { title: "The film's frame: every scene's camera, and the pictures on KAI's cards", onChange: () => setFormat(fmt.value) });
  async function readFormat() {
    try {
      const r = await fetch('/api/format').then((x) => x.json()); if (!r.ok) return;
      fmt.replaceChildren(...r.choices.map((c) => h('option', { value: c }, c)));
      fmt.value = r.aspect;
      fmt.title = r.from === 'slate' ? `${r.aspect} - from Scene Slate's show` : r.from === 'board' ? `${r.aspect} - picked for this film` : `${r.aspect} (no format set)`;
    } catch {}
  }
  async function setFormat(aspect) {
    const r = await store.post('/api/format', { aspect }); if (!r.ok) return toast(r.error, { kind: 'error' });
    await readFormat();
    try { const n = await window.canvas.library.frames(true); toast(`Frame ${r.aspect}${n ? ' - KAI frames updated' : ''}. Other scenes follow when they're opened.`); }
    catch { toast(`Frame ${r.aspect}`); }
  }
  readFormat();
  const body = h('div.cv-body', { title: 'Drag to move the camera (Look / Orbit / Move above), scroll to go closer or farther. Double-click: make the camera the main view', onDblclick: () => store.set({ view: 'shot' }) });
  const label = h('div.cv-label.cc-mono');
  // the camera tools: who Orbit circles, Lock, and what a drag does
  let nav = ['look', 'orbit', 'move'].includes(read('bb.nav')) ? read('bb.nav') : 'look', aimId = '';
  const navSeg = segmented({
    title: 'What dragging in the camera picture does',
    options: [
      { value: 'look', label: 'Look', title: 'Look: the camera turns where it stands (pan and tilt)' },
      { value: 'orbit', label: 'Orbit', title: 'Orbit: the camera circles the aim person, keeping them in the middle' },
      { value: 'move', label: 'Move', title: 'Move: the camera slides sideways and up / down without turning' },
    ],
    value: nav, onChange: (v) => { nav = v; write('bb.nav', v); },
  });
  const lockBtn = h('button.cc-btn.cv-lock', { type: 'button', onClick: () => toggleLock() }, icon('lock'), h('span', {}, 'Lock'));
  let aimSel = h('select.cc-select');
  const aimBox = h('span.cv-aim', {}, h('span.cv-aim-l', {}, 'Aim'), aimSel);
  const tools = h('div.cv-tools', {}, aimBox, lockBtn, navSeg);
  const panel = h('div.cc-panel.cv-panel', { hidden: true }, h('div.cv-head', {}, icon('camera'), title, fmt, big, hide), tools, body);
  document.body.append(panel);

  function toggle(v = !on) { on = v; localStorage.setItem('bb.cam', on ? 'on' : 'off'); place(); }
  // (in the board layout - app/board-layout.js - it is the right-hand column, there whatever the main view is)
  const board = () => document.body.classList.contains('bb-board');
  const showing = () => !!store.doc && (board() || (on && store.state.view !== 'shot'));
  function place() {
    panel.hidden = !showing(); btn.classList.toggle('is-open', on);
    for (const b of [btn, hide]) b.style.display = board() ? 'none' : '';   // (the column is the camera: nothing to show or hide)
    const tl = document.getElementById('timeline')?.getBoundingClientRect();
    if (board()) {
      panel.style.bottom = '';
      // the picture as big as the column allows, keeping room under it for the settings
      const d = store.doc, A = d ? d.meta.width / d.meta.height : 16 / 9, cs = getComputedStyle(document.documentElement);
      const cw = parseFloat(cs.getPropertyValue('--bb-col-w')) - 12, chh = parseFloat(cs.getPropertyValue('--bb-col-h'));
      const w = Math.max(120, Math.min(cw, chh * 0.62 * A));
      body.style.width = `${Math.round(w)}px`;
      if (d) body.style.aspectRatio = `${d.meta.width} / ${d.meta.height}`;
    } else {
      body.style.width = '';
      if (tl) panel.style.bottom = `${Math.round(innerHeight - tl.top + 10)}px`;   // sits just above the timeline
    }
  }
  addEventListener('resize', place);
  new ResizeObserver(place).observe(document.getElementById('timeline'));
  store.on('state', (c) => { if (c.view) place(); });

  // ---------- the camera tools ----------
  const shotNow = () => store.doc?.shots.find((s) => s.id === store.doc.shot);
  const locked = () => !!shotNow()?.lock;
  const isCast = (o) => o.type === 'person' || (o.type === 'card' && o.params.lit !== false && (o.params.h || 0) * (o.scale?.[1] || 1) >= 1);
  const people = () => { const off = shotNow()?.off || []; return store.doc.objects.filter((o) => isCast(o) && !off.includes(o.id)); };
  const eyeOf = (o, t) => { const s = sampleObject(o, store.doc.timeline, t); return new THREE.Vector3(...s.position).add(new THREE.Vector3(0, objectHeight(o) * (s.scale?.[1] || 1) * 0.93, 0)); };
  let toolsSig = '';
  function syncTools() {
    const ps = people(), sig = JSON.stringify([ps.map((o) => [o.id, o.name]), aimId, locked()]);
    if (sig === toolsSig) return; toolsSig = sig;
    if (aimId && !ps.some((o) => o.id === aimId)) aimId = '';
    const next = select({
      title: 'Aim person: who Orbit circles (Auto: the nearest person in frame)',
      options: [{ value: '', label: 'Auto' }, ...ps.map((o) => ({ value: o.id, label: o.name }))],
      value: aimId, onChange: (v) => { aimId = v; toolsSig = ''; syncTools(); },
    });
    aimSel.replaceWith(next); aimSel = next;
    lockBtn.classList.toggle('is-open', locked());
    lockBtn.lastChild.textContent = locked() ? 'Locked' : 'Lock';
    lockBtn.title = locked() ? 'The camera of this shot is locked: click to unlock it' : 'Lock this shot\'s camera, so nothing can move it by accident';
    body.classList.toggle('is-locked', locked());
  }
  async function toggleLock() {
    const sh = shotNow(); if (!sh) return;
    try { await store.op({ op: 'shot.update', lock: !sh.lock }, sh.lock ? 'unlock camera' : 'lock camera'); toast(shotNow()?.lock ? `Camera locked for ${sh.name}` : `Camera unlocked for ${sh.name}`); }
    catch (e) { toast(e.message, { kind: 'error' }); }
  }

  // the shot camera as keyed at the playhead, as vectors
  function poseNow() {
    const p = sampleCamera(store.doc.timeline, store.state.time);
    return p && { position: new THREE.Vector3(...p.position), target: new THREE.Vector3(...p.target), fov: p.fov, roll: p.roll || 0 };
  }
  const aspect = () => store.doc.meta.width / store.doc.meta.height;
  const hfov = (fov) => 2 * Math.atan(Math.tan((fov * DEG) / 2) * aspect());
  // what Orbit circles: the aim person (or the nearest person in frame), else the point the camera looks at
  function pivotOf(p) {
    const t = store.state.time, ps = people();
    const pick = aimId && ps.find((o) => o.id === aimId);
    if (pick) return eyeOf(pick, t);
    const cam = new THREE.PerspectiveCamera(p.fov, aspect(), 0.05, 2000);
    cam.position.copy(p.position); cam.lookAt(p.target); cam.updateMatrixWorld(true);
    let best = null, bd = Infinity;
    for (const o of ps) {
      const e = eyeOf(o, t), q = e.clone().project(cam), d = e.distanceTo(p.position);
      if (q.z < 1 && Math.abs(q.x) <= 1 && Math.abs(q.y) <= 1 && d < bd) { best = e; bd = d; }
    }
    return best || p.target.clone();
  }

  let dragPose = null, dragRev = 0, drag = null, wheelTimer = null;
  const show = (p) => { dragPose = p; dragRev++; };
  function posed(p0, mode, dx, dy, pv) {
    const W = Math.max(1, body.clientWidth), p = { position: p0.position.clone(), target: p0.target.clone(), fov: p0.fov, roll: p0.roll };
    const dir = p0.target.clone().sub(p0.position), dist = Math.max(0.05, dir.length()); dir.normalize();
    if (mode === 'look') {   // pan and tilt where it stands (drag right: look right; drag up: look up)
      const k = hfov(p0.fov) / W;
      const yaw = Math.atan2(dir.x, dir.z) - dx * k, pitch = Math.max(-89 * DEG, Math.min(60 * DEG, Math.asin(dir.y) - dy * k));
      p.target = p0.position.clone().add(new THREE.Vector3(Math.sin(yaw) * Math.cos(pitch), Math.sin(pitch), Math.cos(yaw) * Math.cos(pitch)).multiplyScalar(dist));
    } else if (mode === 'orbit') {   // round the pivot, keeping it in the middle (drag up: higher, looking down)
      const v = p0.position.clone().sub(pv), R = Math.max(0.3, v.length());
      const az = Math.atan2(v.x, v.z) - dx * 0.008, el = Math.max(-1.2, Math.min(1.45, Math.asin(Math.max(-1, Math.min(1, v.y / R))) - dy * 0.006));
      p.position = pv.clone().add(new THREE.Vector3(Math.cos(el) * Math.sin(az), Math.sin(el), Math.cos(el) * Math.cos(az)).multiplyScalar(R));
      p.position.y = Math.max(0.05, p.position.y);
      p.target = pv.clone();
    } else {   // move: slide without turning (drag right: right; drag up: up)
      const m = (2 * dist * Math.tan(hfov(p0.fov) / 2)) / W, right = dir.clone().cross(UP).normalize();
      const d = right.multiplyScalar(dx * m).add(UP.clone().multiplyScalar(-dy * m));
      if (p0.position.y + d.y < 0.05) d.y = 0.05 - p0.position.y;
      p.position.add(d); p.target.add(d);
    }
    return p;
  }
  // keys the camera at the playhead: the key there (within a frame), or a new one
  async function commit(p, label) {
    const tl = store.doc.timeline, t0 = store.state.time, near = tl.keys.find((k) => Math.abs(k.t - t0) <= 0.5 / (tl.fps || 24));
    const t = near ? near.t : +t0.toFixed(3), r = (v) => v.toArray().map((x) => Math.round(x * 1000) / 1000);
    try {
      await store.op({ op: 'key.add', t, position: r(p.position), target: r(p.target), fov: Math.round(p.fov * 1000) / 1000, roll: p.roll }, label);
      if (!near) toast(`Camera key added at ${t.toFixed(2)} s`);
    } catch (e) { toast(e.message, { kind: 'error' }); }
    finally { show(null); }
  }
  let notedAt = 0;   // (once every 2 s: a scroll fires many times)
  const lockedNote = () => { if (Date.now() - notedAt < 2000) return; notedAt = Date.now(); toast(`The camera of ${shotNow()?.name || 'this shot'} is locked: click Locked to unlock it`); };
  body.addEventListener('contextmenu', (e) => e.preventDefault());
  body.addEventListener('pointerdown', (e) => {
    if (e.button > 2 || !store.doc) return;
    if (locked()) { if (e.button === 0) lockedNote(); return; }
    const p0 = poseNow(); if (!p0) return toast('This shot has no camera key yet: press K to key the view first');
    if (store.state.playing) store.set({ playing: false });
    const mode = e.button === 2 ? 'move' : (e.button === 1 || e.shiftKey) ? 'orbit' : nav;
    drag = { mode, x: e.clientX, y: e.clientY, p0, pv: pivotOf(p0), moved: false };
    body.setPointerCapture(e.pointerId); body.classList.add('is-drag'); e.preventDefault();
  });
  body.addEventListener('pointermove', (e) => {
    if (!drag) return;
    const dx = e.clientX - drag.x, dy = e.clientY - drag.y;
    if (!drag.moved && Math.hypot(dx, dy) < 3) return;
    drag.moved = true; show(posed(drag.p0, drag.mode, dx, dy, drag.pv));
  });
  const endDrag = () => {
    if (!drag) return; const d = drag; drag = null; body.classList.remove('is-drag');
    if (d.moved && dragPose) commit(dragPose, `camera ${d.mode}`); else show(null);
  };
  body.addEventListener('pointerup', endDrag);
  body.addEventListener('pointercancel', endDrag);
  // scroll: dolly in (up) or out (down), keyed a moment after the wheel stops
  body.addEventListener('wheel', (e) => {
    if (!store.doc) return;
    e.preventDefault();
    if (locked()) return lockedNote();
    const p0 = dragPose || poseNow(); if (!p0) return;
    const dir = p0.target.clone().sub(p0.position), dist = dir.length(); dir.normalize();
    const step = Math.max(0.05, Math.min(2, dist * 0.08)) * (e.deltaY < 0 ? 1 : -1) * Math.min(3, Math.max(1, Math.abs(e.deltaY) / 50));
    const d = dir.multiplyScalar(step), p = { position: p0.position.clone().add(d), target: p0.target.clone().add(d), fov: p0.fov, roll: p0.roll };
    p.position.y = Math.max(0.05, p.position.y);
    show(p);
    clearTimeout(wheelTimer); wheelTimer = setTimeout(() => { if (dragPose) commit(dragPose, 'camera dolly'); }, 350);
  }, { passive: false });

  // the live picture: up to 30 a second while playing or when something changed, never when hidden
  let last = '', lastT = 0, canvas = null;
  function frame(now) {
    requestAnimationFrame(frame);
    if (!showing() || document.visibilityState !== 'visible') return;
    if (panel.hidden) place();
    const d = store.doc, s = store.state, sh = shotList(d).find((x) => x.active);
    const w = Math.min(960, Math.round(body.clientWidth * Math.min(2, devicePixelRatio || 1))), hgt = Math.round(w * d.meta.height / d.meta.width);
    if (!w) return;
    syncTools();
    const key = `${store.rev}|${s.time}|${w}|${viewport.loading?.size || 0}|${s.selection || ''}|${dragRev}`;
    if (key === last && now - lastT < 1000) return;   // (once a second anyway: pictures and models that just finished loading)
    if (now - lastT < 33) return;
    last = key; lastT = now;
    try {
      const c = viewport.renderShot(s.time, w, hgt, { view: 'shot', grid: false, slot: 'pip', ...(dragPose ? { pose: { position: dragPose.position.toArray(), target: dragPose.target.toArray(), fov: dragPose.fov, roll: dragPose.roll } } : {}) });
      if (c !== canvas) { canvas = c; body.replaceChildren(c, label); }
    } catch (e) { console.warn('cam view', e); }
    title.textContent = `${board() ? 'Camera' : 'Cam view'} · ${sh?.name || ''}`;
    // the shot label on the picture: shot · slate type · lens · start / end / time
    if (sh) {
      const type = d.slate?.shots?.[sh.id]?.type, fov = viewport.pip?.cam?.fov, dur = sh.timeline.duration;
      const when = s.time <= 1e-3 ? 'START' : s.time >= dur - 1e-3 ? 'END' : `${s.time.toFixed(1)} s`;
      label.textContent = [sh.name, type && !sh.name.toUpperCase().includes(type.toUpperCase()) ? type.toUpperCase() : '', fov ? `${Math.round(fovToLens(fov))} mm` : '', when].filter(Boolean).join(' · ');
    }
    body.style.aspectRatio = `${d.meta.width} / ${d.meta.height}`;
    panel.classList.toggle('is-tall', d.meta.height > d.meta.width);
  }
  requestAnimationFrame(frame);
  store.on('doc', place);
  // (the floor plan's camera drag shows here live: { position, target, fov, roll } as arrays, or null)
  const preview = (p) => show(p && { position: new THREE.Vector3(...p.position), target: new THREE.Vector3(...p.target), fov: p.fov, roll: p.roll || 0 });
  return { toggle, place, panel, preview, get on() { return on; } };
}
