# Blocking Board's data for other plugins

Other KAI plugins (the Scene Slate plugin, for one) and agents read Blocking Board's work from files it keeps in each
project. Nothing here needs Blocking Board to be running.

## Where

Each KAI project has one Blocking Board folder: `<project>\KAI\Blocking Board\`.

| What | File |
| --- | --- |
| Every episode and scene, their frames, a pointer to each scene's prompt data | `kai-index.json` |
| A scene's shots, slates and prompt blocks | `prompts\<Episode>\<Scene>.json` |
| The same prompts as a document for people | `prompts\<Episode>\PROMPTS - <Scene>.md` |
| Frames of a scene (PNG) | `frames\<Episode>\<Scene>\main.png`, `<nn>_<shot>_start.png`, `<nn>_<shot>_end.png` |

## How to read it

- **From a plugin's panel in KAI** (`mount(el, kz)`): `await kz.plugin.index('blocking-board')` → `{index}`; each scene
  in `index.groups[].items[]` has `key` (`"EP01/SC03"`), `open` (`{ep, sc}`), `frames` and, once it has prompts,
  `prompts.data` (a path). Then `await kz.plugin.data('blocking-board', item.prompts.data)` → the scene's prompt data.
- **Over HTTP** (agents, a plugin's own server): `GET <KAI>/api/plugin/blocking-board/index?project=<canvas key>` and
  `GET <KAI>/api/plugin/blocking-board/data?project=<canvas key>&file=prompts/EP01/SC03.json`. A plugin's server gets
  KAI's address in the `KAI_URL` environment variable.
- **From disk** (a plugin's own server): KAI starts every plugin with `KAI_PROJECT_DIR` = the project's `KAI\` folder,
  so Blocking Board's files are in `<KAI_PROJECT_DIR>\Blocking Board\`. Read only - never write in another plugin's folder.

## A scene's prompt data (`prompts\<Episode>\<Scene>.json`)

```json
{
  "plugin": "blocking-board", "format": 1,
  "ep": "EP01", "sc": "SC03", "title": "INT. KITCHEN - NIGHT", "location": "Kitchen",
  "width": 1280, "height": 720, "updated": "2026-11-26T12:48:36.322Z",
  "shots": [
    {
      "id": "shot-1", "n": 1, "name": "3-1 WIDE", "type": "WIDE", "sec": 4.5,
      "slate": { "frame": "", "action": "", "acting": "", "camera": "", "light": "", "dialogue": "" },
      "frames": { "start": "01_3-1-WIDE_start", "end": "01_3-1-WIDE_end" },
      "blocks": {
        "keyframe_start": "…", "keyframe_end": "…",
        "flare_start": "…", "flare_end": "…",
        "seedance": "…", "blocking": "…"
      }
    }
  ]
}
```

- `blocks` are the prompt blocks shown in Blocking Board's **Prompts** tab: `keyframe_start` / `keyframe_end` (the
  full keyframe prompt for the first / last frame), `flare_start` / `flare_end` (blocking for a still), `seedance`
  (blocking for motion), `blocking` (the one-line blocking). `keyframe_end` and `flare_end` are there only when the
  camera moves in that shot.
- `frames.start` / `frames.end` are file names (without `.png`) in `frames\<Episode>\<Scene>\`; empty while the shot
  has no camera key. `sec` is the shot's length in seconds; sizes are pixels.
- The file is rewritten a few seconds after the scene changes and when the scene is left. `format` goes up only if a
  field changes meaning; new fields may be added.

## Sending a slate to Blocking Board

A slate (scene title, location and per-shot type, seconds, frame, action, acting, camera, light, dialogue) fills a
scene's shots: in the app, Slate → Import slate… (a slate `.json`); for a running Blocking Board, the `slate` op
(`POST /api/op`, see AGENTS.md). A file-based hand-over for plugins isn't defined yet - ask before inventing one.
